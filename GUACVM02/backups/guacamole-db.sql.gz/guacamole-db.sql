--
-- PostgreSQL database dump
--

-- Dumped from database version 15.2
-- Dumped by pg_dump version 15.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: guacamole_connection_group_type; Type: TYPE; Schema: public; Owner: guacamole_user
--

CREATE TYPE public.guacamole_connection_group_type AS ENUM (
    'ORGANIZATIONAL',
    'BALANCING'
);


ALTER TYPE public.guacamole_connection_group_type OWNER TO guacamole_user;

--
-- Name: guacamole_entity_type; Type: TYPE; Schema: public; Owner: guacamole_user
--

CREATE TYPE public.guacamole_entity_type AS ENUM (
    'USER',
    'USER_GROUP'
);


ALTER TYPE public.guacamole_entity_type OWNER TO guacamole_user;

--
-- Name: guacamole_object_permission_type; Type: TYPE; Schema: public; Owner: guacamole_user
--

CREATE TYPE public.guacamole_object_permission_type AS ENUM (
    'READ',
    'UPDATE',
    'DELETE',
    'ADMINISTER'
);


ALTER TYPE public.guacamole_object_permission_type OWNER TO guacamole_user;

--
-- Name: guacamole_proxy_encryption_method; Type: TYPE; Schema: public; Owner: guacamole_user
--

CREATE TYPE public.guacamole_proxy_encryption_method AS ENUM (
    'NONE',
    'SSL'
);


ALTER TYPE public.guacamole_proxy_encryption_method OWNER TO guacamole_user;

--
-- Name: guacamole_system_permission_type; Type: TYPE; Schema: public; Owner: guacamole_user
--

CREATE TYPE public.guacamole_system_permission_type AS ENUM (
    'CREATE_CONNECTION',
    'CREATE_CONNECTION_GROUP',
    'CREATE_SHARING_PROFILE',
    'CREATE_USER',
    'CREATE_USER_GROUP',
    'AUDIT',
    'ADMINISTER'
);


ALTER TYPE public.guacamole_system_permission_type OWNER TO guacamole_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: guacamole_connection; Type: TABLE; Schema: public; Owner: guacamole_user
--

CREATE TABLE public.guacamole_connection (
    connection_id integer NOT NULL,
    connection_name character varying(128) NOT NULL,
    parent_id integer,
    protocol character varying(32) NOT NULL,
    max_connections integer,
    max_connections_per_user integer,
    connection_weight integer,
    failover_only boolean DEFAULT false NOT NULL,
    proxy_port integer,
    proxy_hostname character varying(512),
    proxy_encryption_method public.guacamole_proxy_encryption_method
);


ALTER TABLE public.guacamole_connection OWNER TO guacamole_user;

--
-- Name: guacamole_connection_attribute; Type: TABLE; Schema: public; Owner: guacamole_user
--

CREATE TABLE public.guacamole_connection_attribute (
    connection_id integer NOT NULL,
    attribute_name character varying(128) NOT NULL,
    attribute_value character varying(4096) NOT NULL
);


ALTER TABLE public.guacamole_connection_attribute OWNER TO guacamole_user;

--
-- Name: guacamole_connection_connection_id_seq; Type: SEQUENCE; Schema: public; Owner: guacamole_user
--

CREATE SEQUENCE public.guacamole_connection_connection_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.guacamole_connection_connection_id_seq OWNER TO guacamole_user;

--
-- Name: guacamole_connection_connection_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: guacamole_user
--

ALTER SEQUENCE public.guacamole_connection_connection_id_seq OWNED BY public.guacamole_connection.connection_id;


--
-- Name: guacamole_connection_group; Type: TABLE; Schema: public; Owner: guacamole_user
--

CREATE TABLE public.guacamole_connection_group (
    connection_group_id integer NOT NULL,
    parent_id integer,
    connection_group_name character varying(128) NOT NULL,
    type public.guacamole_connection_group_type DEFAULT 'ORGANIZATIONAL'::public.guacamole_connection_group_type NOT NULL,
    max_connections integer,
    max_connections_per_user integer,
    enable_session_affinity boolean DEFAULT false NOT NULL
);


ALTER TABLE public.guacamole_connection_group OWNER TO guacamole_user;

--
-- Name: guacamole_connection_group_attribute; Type: TABLE; Schema: public; Owner: guacamole_user
--

CREATE TABLE public.guacamole_connection_group_attribute (
    connection_group_id integer NOT NULL,
    attribute_name character varying(128) NOT NULL,
    attribute_value character varying(4096) NOT NULL
);


ALTER TABLE public.guacamole_connection_group_attribute OWNER TO guacamole_user;

--
-- Name: guacamole_connection_group_connection_group_id_seq; Type: SEQUENCE; Schema: public; Owner: guacamole_user
--

CREATE SEQUENCE public.guacamole_connection_group_connection_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.guacamole_connection_group_connection_group_id_seq OWNER TO guacamole_user;

--
-- Name: guacamole_connection_group_connection_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: guacamole_user
--

ALTER SEQUENCE public.guacamole_connection_group_connection_group_id_seq OWNED BY public.guacamole_connection_group.connection_group_id;


--
-- Name: guacamole_connection_group_permission; Type: TABLE; Schema: public; Owner: guacamole_user
--

CREATE TABLE public.guacamole_connection_group_permission (
    entity_id integer NOT NULL,
    connection_group_id integer NOT NULL,
    permission public.guacamole_object_permission_type NOT NULL
);


ALTER TABLE public.guacamole_connection_group_permission OWNER TO guacamole_user;

--
-- Name: guacamole_connection_history; Type: TABLE; Schema: public; Owner: guacamole_user
--

CREATE TABLE public.guacamole_connection_history (
    history_id integer NOT NULL,
    user_id integer,
    username character varying(128) NOT NULL,
    remote_host character varying(256) DEFAULT NULL::character varying,
    connection_id integer,
    connection_name character varying(128) NOT NULL,
    sharing_profile_id integer,
    sharing_profile_name character varying(128) DEFAULT NULL::character varying,
    start_date timestamp with time zone NOT NULL,
    end_date timestamp with time zone
);


ALTER TABLE public.guacamole_connection_history OWNER TO guacamole_user;

--
-- Name: guacamole_connection_history_history_id_seq; Type: SEQUENCE; Schema: public; Owner: guacamole_user
--

CREATE SEQUENCE public.guacamole_connection_history_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.guacamole_connection_history_history_id_seq OWNER TO guacamole_user;

--
-- Name: guacamole_connection_history_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: guacamole_user
--

ALTER SEQUENCE public.guacamole_connection_history_history_id_seq OWNED BY public.guacamole_connection_history.history_id;


--
-- Name: guacamole_connection_parameter; Type: TABLE; Schema: public; Owner: guacamole_user
--

CREATE TABLE public.guacamole_connection_parameter (
    connection_id integer NOT NULL,
    parameter_name character varying(128) NOT NULL,
    parameter_value character varying(4096) NOT NULL
);


ALTER TABLE public.guacamole_connection_parameter OWNER TO guacamole_user;

--
-- Name: guacamole_connection_permission; Type: TABLE; Schema: public; Owner: guacamole_user
--

CREATE TABLE public.guacamole_connection_permission (
    entity_id integer NOT NULL,
    connection_id integer NOT NULL,
    permission public.guacamole_object_permission_type NOT NULL
);


ALTER TABLE public.guacamole_connection_permission OWNER TO guacamole_user;

--
-- Name: guacamole_entity; Type: TABLE; Schema: public; Owner: guacamole_user
--

CREATE TABLE public.guacamole_entity (
    entity_id integer NOT NULL,
    name character varying(128) NOT NULL,
    type public.guacamole_entity_type NOT NULL
);


ALTER TABLE public.guacamole_entity OWNER TO guacamole_user;

--
-- Name: guacamole_entity_entity_id_seq; Type: SEQUENCE; Schema: public; Owner: guacamole_user
--

CREATE SEQUENCE public.guacamole_entity_entity_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.guacamole_entity_entity_id_seq OWNER TO guacamole_user;

--
-- Name: guacamole_entity_entity_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: guacamole_user
--

ALTER SEQUENCE public.guacamole_entity_entity_id_seq OWNED BY public.guacamole_entity.entity_id;


--
-- Name: guacamole_sharing_profile; Type: TABLE; Schema: public; Owner: guacamole_user
--

CREATE TABLE public.guacamole_sharing_profile (
    sharing_profile_id integer NOT NULL,
    sharing_profile_name character varying(128) NOT NULL,
    primary_connection_id integer NOT NULL
);


ALTER TABLE public.guacamole_sharing_profile OWNER TO guacamole_user;

--
-- Name: guacamole_sharing_profile_attribute; Type: TABLE; Schema: public; Owner: guacamole_user
--

CREATE TABLE public.guacamole_sharing_profile_attribute (
    sharing_profile_id integer NOT NULL,
    attribute_name character varying(128) NOT NULL,
    attribute_value character varying(4096) NOT NULL
);


ALTER TABLE public.guacamole_sharing_profile_attribute OWNER TO guacamole_user;

--
-- Name: guacamole_sharing_profile_parameter; Type: TABLE; Schema: public; Owner: guacamole_user
--

CREATE TABLE public.guacamole_sharing_profile_parameter (
    sharing_profile_id integer NOT NULL,
    parameter_name character varying(128) NOT NULL,
    parameter_value character varying(4096) NOT NULL
);


ALTER TABLE public.guacamole_sharing_profile_parameter OWNER TO guacamole_user;

--
-- Name: guacamole_sharing_profile_permission; Type: TABLE; Schema: public; Owner: guacamole_user
--

CREATE TABLE public.guacamole_sharing_profile_permission (
    entity_id integer NOT NULL,
    sharing_profile_id integer NOT NULL,
    permission public.guacamole_object_permission_type NOT NULL
);


ALTER TABLE public.guacamole_sharing_profile_permission OWNER TO guacamole_user;

--
-- Name: guacamole_sharing_profile_sharing_profile_id_seq; Type: SEQUENCE; Schema: public; Owner: guacamole_user
--

CREATE SEQUENCE public.guacamole_sharing_profile_sharing_profile_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.guacamole_sharing_profile_sharing_profile_id_seq OWNER TO guacamole_user;

--
-- Name: guacamole_sharing_profile_sharing_profile_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: guacamole_user
--

ALTER SEQUENCE public.guacamole_sharing_profile_sharing_profile_id_seq OWNED BY public.guacamole_sharing_profile.sharing_profile_id;


--
-- Name: guacamole_system_permission; Type: TABLE; Schema: public; Owner: guacamole_user
--

CREATE TABLE public.guacamole_system_permission (
    entity_id integer NOT NULL,
    permission public.guacamole_system_permission_type NOT NULL
);


ALTER TABLE public.guacamole_system_permission OWNER TO guacamole_user;

--
-- Name: guacamole_user; Type: TABLE; Schema: public; Owner: guacamole_user
--

CREATE TABLE public.guacamole_user (
    user_id integer NOT NULL,
    entity_id integer NOT NULL,
    password_hash bytea NOT NULL,
    password_salt bytea,
    password_date timestamp with time zone NOT NULL,
    disabled boolean DEFAULT false NOT NULL,
    expired boolean DEFAULT false NOT NULL,
    access_window_start time without time zone,
    access_window_end time without time zone,
    valid_from date,
    valid_until date,
    timezone character varying(64),
    full_name character varying(256),
    email_address character varying(256),
    organization character varying(256),
    organizational_role character varying(256)
);


ALTER TABLE public.guacamole_user OWNER TO guacamole_user;

--
-- Name: guacamole_user_attribute; Type: TABLE; Schema: public; Owner: guacamole_user
--

CREATE TABLE public.guacamole_user_attribute (
    user_id integer NOT NULL,
    attribute_name character varying(128) NOT NULL,
    attribute_value character varying(4096) NOT NULL
);


ALTER TABLE public.guacamole_user_attribute OWNER TO guacamole_user;

--
-- Name: guacamole_user_group; Type: TABLE; Schema: public; Owner: guacamole_user
--

CREATE TABLE public.guacamole_user_group (
    user_group_id integer NOT NULL,
    entity_id integer NOT NULL,
    disabled boolean DEFAULT false NOT NULL
);


ALTER TABLE public.guacamole_user_group OWNER TO guacamole_user;

--
-- Name: guacamole_user_group_attribute; Type: TABLE; Schema: public; Owner: guacamole_user
--

CREATE TABLE public.guacamole_user_group_attribute (
    user_group_id integer NOT NULL,
    attribute_name character varying(128) NOT NULL,
    attribute_value character varying(4096) NOT NULL
);


ALTER TABLE public.guacamole_user_group_attribute OWNER TO guacamole_user;

--
-- Name: guacamole_user_group_member; Type: TABLE; Schema: public; Owner: guacamole_user
--

CREATE TABLE public.guacamole_user_group_member (
    user_group_id integer NOT NULL,
    member_entity_id integer NOT NULL
);


ALTER TABLE public.guacamole_user_group_member OWNER TO guacamole_user;

--
-- Name: guacamole_user_group_permission; Type: TABLE; Schema: public; Owner: guacamole_user
--

CREATE TABLE public.guacamole_user_group_permission (
    entity_id integer NOT NULL,
    affected_user_group_id integer NOT NULL,
    permission public.guacamole_object_permission_type NOT NULL
);


ALTER TABLE public.guacamole_user_group_permission OWNER TO guacamole_user;

--
-- Name: guacamole_user_group_user_group_id_seq; Type: SEQUENCE; Schema: public; Owner: guacamole_user
--

CREATE SEQUENCE public.guacamole_user_group_user_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.guacamole_user_group_user_group_id_seq OWNER TO guacamole_user;

--
-- Name: guacamole_user_group_user_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: guacamole_user
--

ALTER SEQUENCE public.guacamole_user_group_user_group_id_seq OWNED BY public.guacamole_user_group.user_group_id;


--
-- Name: guacamole_user_history; Type: TABLE; Schema: public; Owner: guacamole_user
--

CREATE TABLE public.guacamole_user_history (
    history_id integer NOT NULL,
    user_id integer,
    username character varying(128) NOT NULL,
    remote_host character varying(256) DEFAULT NULL::character varying,
    start_date timestamp with time zone NOT NULL,
    end_date timestamp with time zone
);


ALTER TABLE public.guacamole_user_history OWNER TO guacamole_user;

--
-- Name: guacamole_user_history_history_id_seq; Type: SEQUENCE; Schema: public; Owner: guacamole_user
--

CREATE SEQUENCE public.guacamole_user_history_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.guacamole_user_history_history_id_seq OWNER TO guacamole_user;

--
-- Name: guacamole_user_history_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: guacamole_user
--

ALTER SEQUENCE public.guacamole_user_history_history_id_seq OWNED BY public.guacamole_user_history.history_id;


--
-- Name: guacamole_user_password_history; Type: TABLE; Schema: public; Owner: guacamole_user
--

CREATE TABLE public.guacamole_user_password_history (
    password_history_id integer NOT NULL,
    user_id integer NOT NULL,
    password_hash bytea NOT NULL,
    password_salt bytea,
    password_date timestamp with time zone NOT NULL
);


ALTER TABLE public.guacamole_user_password_history OWNER TO guacamole_user;

--
-- Name: guacamole_user_password_history_password_history_id_seq; Type: SEQUENCE; Schema: public; Owner: guacamole_user
--

CREATE SEQUENCE public.guacamole_user_password_history_password_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.guacamole_user_password_history_password_history_id_seq OWNER TO guacamole_user;

--
-- Name: guacamole_user_password_history_password_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: guacamole_user
--

ALTER SEQUENCE public.guacamole_user_password_history_password_history_id_seq OWNED BY public.guacamole_user_password_history.password_history_id;


--
-- Name: guacamole_user_permission; Type: TABLE; Schema: public; Owner: guacamole_user
--

CREATE TABLE public.guacamole_user_permission (
    entity_id integer NOT NULL,
    affected_user_id integer NOT NULL,
    permission public.guacamole_object_permission_type NOT NULL
);


ALTER TABLE public.guacamole_user_permission OWNER TO guacamole_user;

--
-- Name: guacamole_user_user_id_seq; Type: SEQUENCE; Schema: public; Owner: guacamole_user
--

CREATE SEQUENCE public.guacamole_user_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.guacamole_user_user_id_seq OWNER TO guacamole_user;

--
-- Name: guacamole_user_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: guacamole_user
--

ALTER SEQUENCE public.guacamole_user_user_id_seq OWNED BY public.guacamole_user.user_id;


--
-- Name: guacamole_connection connection_id; Type: DEFAULT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_connection ALTER COLUMN connection_id SET DEFAULT nextval('public.guacamole_connection_connection_id_seq'::regclass);


--
-- Name: guacamole_connection_group connection_group_id; Type: DEFAULT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_connection_group ALTER COLUMN connection_group_id SET DEFAULT nextval('public.guacamole_connection_group_connection_group_id_seq'::regclass);


--
-- Name: guacamole_connection_history history_id; Type: DEFAULT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_connection_history ALTER COLUMN history_id SET DEFAULT nextval('public.guacamole_connection_history_history_id_seq'::regclass);


--
-- Name: guacamole_entity entity_id; Type: DEFAULT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_entity ALTER COLUMN entity_id SET DEFAULT nextval('public.guacamole_entity_entity_id_seq'::regclass);


--
-- Name: guacamole_sharing_profile sharing_profile_id; Type: DEFAULT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_sharing_profile ALTER COLUMN sharing_profile_id SET DEFAULT nextval('public.guacamole_sharing_profile_sharing_profile_id_seq'::regclass);


--
-- Name: guacamole_user user_id; Type: DEFAULT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_user ALTER COLUMN user_id SET DEFAULT nextval('public.guacamole_user_user_id_seq'::regclass);


--
-- Name: guacamole_user_group user_group_id; Type: DEFAULT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_user_group ALTER COLUMN user_group_id SET DEFAULT nextval('public.guacamole_user_group_user_group_id_seq'::regclass);


--
-- Name: guacamole_user_history history_id; Type: DEFAULT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_user_history ALTER COLUMN history_id SET DEFAULT nextval('public.guacamole_user_history_history_id_seq'::regclass);


--
-- Name: guacamole_user_password_history password_history_id; Type: DEFAULT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_user_password_history ALTER COLUMN password_history_id SET DEFAULT nextval('public.guacamole_user_password_history_password_history_id_seq'::regclass);


--
-- Data for Name: guacamole_connection; Type: TABLE DATA; Schema: public; Owner: guacamole_user
--

COPY public.guacamole_connection (connection_id, connection_name, parent_id, protocol, max_connections, max_connections_per_user, connection_weight, failover_only, proxy_port, proxy_hostname, proxy_encryption_method) FROM stdin;
5	VULNSRV02	\N	ssh	\N	\N	\N	f	\N	\N	\N
7	WIN2025	\N	rdp	\N	\N	\N	f	\N	\N	\N
8	OPNSENSE	\N	ssh	\N	\N	\N	f	\N	\N	\N
9	CLIENT01	\N	ssh	\N	\N	\N	f	\N	\N	\N
1	APPSRV01	\N	ssh	\N	\N	\N	f	\N	\N	\N
11	PROXMOX	\N	ssh	\N	\N	\N	f	\N	\N	\N
12	VULNSRV01	\N	ssh	\N	\N	\N	f	\N	\N	\N
2	KALI01	\N	ssh	\N	\N	\N	f	\N	\N	\N
13	KALI01-VNC-2	\N	vnc	\N	\N	\N	f	\N	\N	\N
6	KALI01-VNC-1	\N	vnc	\N	\N	\N	f	\N	\N	\N
14	KALI01-VNC-3	\N	vnc	\N	\N	\N	f	\N	\N	\N
15	KALI01-VNC-4	\N	vnc	\N	\N	\N	f	\N	\N	\N
10	CLIENT01-RDP-1	\N	rdp	\N	\N	\N	f	\N	\N	\N
16	CLIENT01-RDP-2	\N	rdp	\N	\N	\N	f	\N	\N	\N
17	CLIENT01-RDP-3	\N	rdp	\N	\N	\N	f	\N	\N	\N
18	CLIENT01-RDP-4	\N	rdp	\N	\N	\N	f	\N	\N	\N
4	WAZUH	\N	ssh	\N	\N	\N	f	\N	\N	\N
19	TPOT01	\N	ssh	\N	\N	\N	f	\N	\N	\N
20	KALI02	\N	ssh	\N	\N	\N	f	\N	\N	\N
21	KALI02-VNC-1	\N	vnc	\N	\N	\N	f	\N	\N	\N
22	KALI02-VNC-2	\N	vnc	\N	\N	\N	f	\N	\N	\N
23	KALI02-VNC-3	\N	vnc	\N	\N	\N	f	\N	\N	\N
24	KALI02-VNC-4	\N	vnc	\N	\N	\N	f	\N	\N	\N
\.


--
-- Data for Name: guacamole_connection_attribute; Type: TABLE DATA; Schema: public; Owner: guacamole_user
--

COPY public.guacamole_connection_attribute (connection_id, attribute_name, attribute_value) FROM stdin;
\.


--
-- Data for Name: guacamole_connection_group; Type: TABLE DATA; Schema: public; Owner: guacamole_user
--

COPY public.guacamole_connection_group (connection_group_id, parent_id, connection_group_name, type, max_connections, max_connections_per_user, enable_session_affinity) FROM stdin;
\.


--
-- Data for Name: guacamole_connection_group_attribute; Type: TABLE DATA; Schema: public; Owner: guacamole_user
--

COPY public.guacamole_connection_group_attribute (connection_group_id, attribute_name, attribute_value) FROM stdin;
\.


--
-- Data for Name: guacamole_connection_group_permission; Type: TABLE DATA; Schema: public; Owner: guacamole_user
--

COPY public.guacamole_connection_group_permission (entity_id, connection_group_id, permission) FROM stdin;
\.


--
-- Data for Name: guacamole_connection_history; Type: TABLE DATA; Schema: public; Owner: guacamole_user
--

COPY public.guacamole_connection_history (history_id, user_id, username, remote_host, connection_id, connection_name, sharing_profile_id, sharing_profile_name, start_date, end_date) FROM stdin;
1	1	guacadmin	10.10.100.1	1	VULNSRV01	\N	\N	2025-12-23 09:54:37.943+00	2025-12-23 09:54:38.095+00
2	1	guacadmin	10.10.100.1	1	VULNSRV01	\N	\N	2025-12-23 09:54:39.987+00	2025-12-23 09:54:40.031+00
3	1	guacadmin	10.10.100.1	1	VULNSRV01	\N	\N	2025-12-23 09:58:27.989+00	2025-12-23 09:58:28.402+00
4	1	guacadmin	10.10.100.1	1	VULNSRV01	\N	\N	2025-12-23 09:58:29.801+00	2025-12-23 09:58:29.943+00
5	1	guacadmin	10.10.100.1	1	VULNSRV01	\N	\N	2025-12-23 09:58:31.674+00	2025-12-23 09:58:31.808+00
6	1	guacadmin	10.10.100.1	1	VULNSRV01	\N	\N	2025-12-23 10:03:07.655+00	2025-12-23 10:03:07.837+00
7	1	guacadmin	10.10.100.1	1	VULNSRV01	\N	\N	2025-12-23 10:03:10.087+00	2025-12-23 10:03:10.214+00
8	1	guacadmin	10.10.100.1	1	VULNSRV01	\N	\N	2025-12-23 10:07:31.083+00	2025-12-23 10:07:31.309+00
9	1	guacadmin	10.10.100.1	1	VULNSRV01	\N	\N	2025-12-23 10:07:33.035+00	2025-12-23 10:07:33.168+00
10	1	guacadmin	10.10.100.1	1	VULNSRV01	\N	\N	2025-12-23 10:08:58.922+00	2025-12-23 10:12:06.647+00
11	1	guacadmin	10.10.100.1	2	KALI01	\N	\N	2025-12-23 10:14:52.55+00	2025-12-23 10:14:59.079+00
14	1	guacadmin	10.10.100.1	2	KALI01	\N	\N	2025-12-23 10:15:51.479+00	2025-12-23 10:21:18.361+00
15	1	guacadmin	10.10.100.1	2	KALI01	\N	\N	2025-12-23 11:57:08.172+00	2025-12-23 11:57:21.62+00
16	1	guacadmin	10.10.100.1	1	VULNSRV01	\N	\N	2025-12-23 11:57:23.939+00	2025-12-23 11:57:30.424+00
17	1	guacadmin	10.10.100.1	4	WAZUH	\N	\N	2025-12-23 12:27:03.127+00	2025-12-23 12:30:32.764+00
12	1	guacadmin	10.10.100.1	\N	KALI01_VNC	\N	\N	2025-12-23 10:15:46.761+00	2025-12-23 10:15:46.842+00
13	1	guacadmin	10.10.100.1	\N	KALI01_VNC	\N	\N	2025-12-23 10:15:48.121+00	2025-12-23 10:15:48.151+00
18	1	guacadmin	10.10.100.1	2	KALI01	\N	\N	2025-12-23 12:35:30.41+00	2025-12-23 12:36:38.142+00
19	1	guacadmin	10.10.100.1	2	KALI01	\N	\N	2025-12-23 12:37:45.155+00	2025-12-23 12:41:29.815+00
20	1	guacadmin	10.10.100.1	2	KALI01	\N	\N	2025-12-23 12:42:32.707+00	2025-12-23 12:44:08.313+00
21	1	guacadmin	10.10.100.1	2	KALI01	\N	\N	2025-12-23 12:44:31.614+00	2025-12-23 12:48:12.895+00
22	1	guacadmin	10.10.100.1	2	KALI01	\N	\N	2025-12-23 12:48:27.201+00	2025-12-23 12:48:29.355+00
23	1	guacadmin	10.10.100.1	2	KALI01	\N	\N	2025-12-23 12:48:32.914+00	2025-12-23 12:51:44.848+00
24	1	guacadmin	10.10.100.1	2	KALI01	\N	\N	2025-12-23 12:56:40.734+00	2025-12-23 13:02:50.466+00
25	1	guacadmin	10.10.100.1	2	KALI01	\N	\N	2025-12-23 13:04:38.66+00	2025-12-23 13:09:51.153+00
26	1	guacadmin	10.10.100.1	2	KALI01	\N	\N	2025-12-23 19:01:27.308+00	2025-12-23 19:01:37.392+00
27	1	guacadmin	10.10.100.1	2	KALI01	\N	\N	2025-12-23 19:01:40.415+00	2025-12-23 19:28:53.316+00
28	1	guacadmin	10.10.100.1	4	WAZUH	\N	\N	2025-12-23 19:34:14.965+00	2025-12-23 19:37:50.38+00
29	1	guacadmin	10.10.100.1	4	WAZUH	\N	\N	2025-12-23 19:37:54.863+00	2025-12-23 19:38:06.537+00
30	1	guacadmin	10.10.100.1	2	KALI01	\N	\N	2025-12-23 19:38:09.952+00	2025-12-23 19:46:46.285+00
31	1	guacadmin	10.10.100.1	6	KALI01-VNC	\N	\N	2025-12-23 19:47:47.3+00	2025-12-23 19:49:11.136+00
32	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-01-07 09:52:45.401+00	2026-01-07 10:03:15.203+00
33	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-01-07 10:04:49.929+00	2026-01-07 10:07:45.555+00
34	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-01-08 07:39:48.239+00	2026-01-08 07:39:54.65+00
36	1	guacadmin	172.18.0.5	2	KALI01	\N	\N	2026-01-08 09:39:25.243+00	2026-01-08 09:39:26.774+00
41	1	guacadmin	172.18.0.5	4	WAZUH	\N	\N	2026-01-08 09:39:59.806+00	2026-01-08 09:40:06.343+00
40	1	guacadmin	172.18.0.5	5	VULNSRV02	\N	\N	2026-01-08 09:39:55.398+00	2026-01-08 09:40:07.364+00
39	1	guacadmin	172.18.0.5	1	VULNSRV01	\N	\N	2026-01-08 09:39:50.694+00	2026-01-08 09:40:08.187+00
35	1	guacadmin	172.18.0.5	7	WIN2025	\N	\N	2026-01-08 09:11:11.755+00	2026-01-08 09:40:08.874+00
38	1	guacadmin	172.18.0.5	8	OPNSENSE	\N	\N	2026-01-08 09:39:46.079+00	2026-01-08 09:40:08.961+00
37	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-01-08 09:39:38.431+00	2026-01-08 09:40:09.771+00
42	1	guacadmin	172.18.0.5	7	WIN2025	\N	\N	2026-01-08 09:40:04.672+00	2026-01-08 09:40:21.013+00
43	1	guacadmin	172.18.0.5	8	OPNSENSE	\N	\N	2026-01-14 11:18:57.269+00	2026-01-14 11:27:25.698+00
44	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-01-14 11:20:34.855+00	2026-01-14 11:27:26.644+00
45	1	guacadmin	172.18.0.5	1	VULNSRV01	\N	\N	2026-01-14 11:21:32.848+00	2026-01-14 11:27:27.593+00
47	1	guacadmin	172.18.0.5	8	OPNSENSE	\N	\N	2026-01-14 11:43:33.225+00	2026-01-14 11:57:44.402+00
48	1	guacadmin	172.18.0.5	8	OPNSENSE	\N	\N	2026-01-14 12:07:55.255+00	2026-01-14 12:18:58.81+00
46	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-01-14 11:30:20.775+00	2026-01-14 13:17:59.532+00
49	1	guacadmin	172.18.0.5	8	OPNSENSE	\N	\N	2026-01-14 13:17:49.384+00	2026-01-14 13:25:22.002+00
50	1	guacadmin	172.18.0.5	8	OPNSENSE	\N	\N	2026-01-14 13:26:13.126+00	2026-01-14 13:38:24.9+00
51	1	guacadmin	172.18.0.5	8	OPNSENSE	\N	\N	2026-01-14 13:39:38.295+00	2026-01-14 13:50:25.377+00
52	1	guacadmin	172.18.0.5	8	OPNSENSE	\N	\N	2026-01-14 13:51:08.616+00	2026-01-14 13:53:02.856+00
53	1	guacadmin	172.18.0.5	8	OPNSENSE	\N	\N	2026-01-14 13:53:35.351+00	2026-01-14 14:07:58.94+00
54	1	guacadmin	172.18.0.5	8	OPNSENSE	\N	\N	2026-01-14 14:27:54.465+00	2026-01-14 14:31:10.103+00
55	1	guacadmin	172.18.0.5	8	OPNSENSE	\N	\N	2026-01-14 14:53:36.724+00	2026-01-14 15:09:24.19+00
57	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-01-14 15:27:09.835+00	2026-01-14 15:29:31.375+00
56	1	guacadmin	172.18.0.5	8	OPNSENSE	\N	\N	2026-01-14 15:09:56.396+00	2026-01-14 15:29:31.375+00
58	1	guacadmin	172.18.0.5	1	VULNSRV01	\N	\N	2026-01-15 07:13:56.824+00	2026-01-15 07:14:51.9+00
59	1	guacadmin	172.18.0.5	1	VULNSRV01	\N	\N	2026-01-15 07:15:07.942+00	2026-01-15 07:16:20.597+00
60	1	guacadmin	172.18.0.5	8	OPNSENSE	\N	\N	2026-01-15 07:16:45.264+00	2026-01-15 08:19:37.232+00
62	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-01-15 07:37:04.857+00	2026-01-15 08:27:07.538+00
61	1	guacadmin	172.18.0.5	4	WAZUH	\N	\N	2026-01-15 07:34:04.523+00	2026-01-15 08:31:17.778+00
63	1	guacadmin	172.18.0.5	8	OPNSENSE	\N	\N	2026-01-15 08:38:50.348+00	2026-01-15 08:38:50.44+00
64	1	guacadmin	172.18.0.5	8	OPNSENSE	\N	\N	2026-01-15 08:38:51.672+00	2026-01-15 08:38:51.748+00
65	1	guacadmin	172.18.0.5	8	OPNSENSE	\N	\N	2026-01-15 08:39:03.911+00	2026-01-15 08:39:04.008+00
66	1	guacadmin	172.18.0.5	8	OPNSENSE	\N	\N	2026-01-15 08:43:51.845+00	2026-01-15 08:51:27.055+00
68	1	guacadmin	172.18.0.5	8	OPNSENSE	\N	\N	2026-01-15 08:53:52.842+00	2026-01-15 09:59:11.901+00
67	1	guacadmin	172.18.0.5	2	KALI01	\N	\N	2026-01-15 08:49:33.14+00	2026-01-15 10:37:56.729+00
71	1	guacadmin	172.18.0.5	8	OPNSENSE	\N	\N	2026-01-15 10:00:06.442+00	2026-01-15 10:37:56.729+00
70	1	guacadmin	172.18.0.5	4	WAZUH	\N	\N	2026-01-15 09:44:44.797+00	2026-01-15 10:37:56.728+00
69	1	guacadmin	172.18.0.5	8	OPNSENSE	\N	\N	2026-01-15 09:42:41.914+00	2026-01-15 10:37:56.728+00
75	1	guacadmin	172.18.0.5	4	WAZUH	\N	\N	2026-01-15 10:48:51.296+00	2026-01-15 10:55:52.668+00
73	1	guacadmin	172.18.0.5	8	OPNSENSE	\N	\N	2026-01-15 10:48:51.244+00	2026-01-15 10:57:31.896+00
76	1	guacadmin	172.18.0.5	8	OPNSENSE	\N	\N	2026-01-15 11:01:14.523+00	2026-01-15 11:01:14.61+00
72	1	guacadmin	172.18.0.5	8	OPNSENSE	\N	\N	2026-01-15 10:48:51.222+00	2026-01-15 11:03:12.939+00
77	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-01-15 11:01:28.976+00	2026-01-15 11:06:44.768+00
74	1	guacadmin	172.18.0.5	2	KALI01	\N	\N	2026-01-15 10:48:51.259+00	2026-01-15 11:14:01.089+00
78	1	guacadmin	172.18.0.5	4	WAZUH	\N	\N	2026-01-15 11:01:43.138+00	2026-01-15 11:14:01.089+00
84	1	guacadmin	172.18.0.5	8	OPNSENSE	\N	\N	2026-01-16 06:13:13.444+00	2026-01-16 06:53:20.333+00
80	1	guacadmin	172.18.0.5	4	WAZUH	\N	\N	2026-01-15 11:16:19.257+00	2026-01-15 11:27:00.085+00
117	1	guacadmin	172.18.0.5	10	CLIENT01-VNC	\N	\N	2026-01-18 20:11:56.844+00	2026-01-18 20:12:02.406+00
81	1	guacadmin	172.18.0.5	8	OPNSENSE	\N	\N	2026-01-15 11:32:14.491+00	2026-01-15 11:34:29.976+00
82	1	guacadmin	172.18.0.5	8	OPNSENSE	\N	\N	2026-01-15 11:36:49.355+00	2026-01-15 11:39:22.63+00
93	1	guacadmin	172.18.0.5	8	OPNSENSE	\N	\N	2026-01-16 17:24:15.65+00	2026-01-16 17:24:15.764+00
119	1	guacadmin	172.18.0.5	10	CLIENT01-VNC	\N	\N	2026-01-18 20:12:04.175+00	2026-01-18 20:12:04.208+00
95	1	guacadmin	172.18.0.5	8	OPNSENSE	\N	\N	2026-01-16 17:24:33.465+00	2026-01-16 17:25:06.418+00
97	1	guacadmin	172.18.0.5	8	OPNSENSE	\N	\N	2026-01-16 17:25:38.462+00	2026-01-16 17:42:54.808+00
123	1	guacadmin	172.18.0.5	10	CLIENT01-VNC	\N	\N	2026-01-18 20:12:05.851+00	2026-01-18 20:12:05.88+00
128	1	guacadmin	172.18.0.5	10	CLIENT01-VNC	\N	\N	2026-01-18 20:29:47.632+00	2026-01-18 20:29:47.673+00
132	1	guacadmin	172.18.0.5	11	PROXMOX	\N	\N	2026-01-20 07:17:52.214+00	2026-01-20 07:17:52.333+00
134	1	guacadmin	172.18.0.5	11	PROXMOX	\N	\N	2026-01-20 07:18:34.679+00	2026-01-20 07:18:34.806+00
136	1	guacadmin	172.18.0.5	11	PROXMOX	\N	\N	2026-01-20 07:18:50.972+00	2026-01-20 07:18:51.098+00
144	1	guacadmin	172.18.0.5	10	CLIENT01-VNC	\N	\N	2026-01-20 07:21:27.136+00	2026-01-20 07:21:27.439+00
146	1	guacadmin	172.18.0.5	10	CLIENT01-VNC	\N	\N	2026-01-20 07:21:58.871+00	2026-01-20 07:21:58.894+00
142	1	guacadmin	172.18.0.5	9	CLIENT01	\N	\N	2026-01-20 07:21:06.784+00	2026-01-20 07:22:04.423+00
155	1	guacadmin	172.18.0.5	7	WIN2025	\N	\N	2026-01-20 09:45:54.311+00	2026-01-20 09:46:00.806+00
151	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-01-20 08:43:55.744+00	2026-01-20 09:46:44.51+00
152	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-01-20 09:44:55.577+00	2026-01-20 09:46:44.51+00
162	1	guacadmin	172.18.0.5	10	CLIENT01-VNC	\N	\N	2026-01-20 14:02:56.549+00	2026-01-20 14:02:56.737+00
165	1	guacadmin	172.18.0.5	9	CLIENT01	\N	\N	2026-01-20 14:05:50.572+00	2026-01-20 14:05:53.701+00
167	1	guacadmin	172.18.0.5	9	CLIENT01	\N	\N	2026-01-20 14:06:28.568+00	2026-01-20 14:06:31.716+00
168	1	guacadmin	172.18.0.5	9	CLIENT01	\N	\N	2026-01-20 14:14:55.587+00	2026-01-20 14:21:48.13+00
170	1	guacadmin	172.18.0.5	10	CLIENT01-VNC	\N	\N	2026-01-20 14:22:05.816+00	2026-01-20 14:22:05.948+00
172	1	guacadmin	172.18.0.5	10	CLIENT01-VNC	\N	\N	2026-01-20 14:22:48.743+00	2026-01-20 14:22:48.863+00
175	1	guacadmin	172.18.0.5	9	CLIENT01	\N	\N	2026-01-20 14:45:59.687+00	2026-01-20 14:52:05.01+00
176	1	guacadmin	172.18.0.5	9	CLIENT01	\N	\N	2026-01-20 14:52:27.988+00	2026-01-20 14:59:11.317+00
178	1	guacadmin	172.18.0.5	10	CLIENT01-VNC	\N	\N	2026-01-20 18:17:00.454+00	2026-01-20 18:17:00.507+00
181	1	guacadmin	172.18.0.5	10	CLIENT01-VNC	\N	\N	2026-01-20 18:18:29.66+00	2026-01-20 18:18:29.772+00
183	1	guacadmin	172.18.0.5	10	CLIENT01-VNC	\N	\N	2026-01-20 18:18:31.32+00	2026-01-20 18:18:31.389+00
177	1	guacadmin	172.18.0.5	9	CLIENT01	\N	\N	2026-01-20 18:15:46.354+00	2026-01-20 18:18:47.988+00
185	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-01-20 18:26:04.794+00	2026-01-20 19:10:09.927+00
79	1	guacadmin	172.18.0.5	2	KALI01	\N	\N	2026-01-15 11:16:02.33+00	2026-01-15 11:39:22.63+00
118	1	guacadmin	172.18.0.5	10	CLIENT01-VNC	\N	\N	2026-01-18 20:12:03.545+00	2026-01-18 20:12:03.576+00
86	1	guacadmin	172.18.0.5	8	OPNSENSE	\N	\N	2026-01-16 07:27:16.442+00	2026-01-16 08:35:14.885+00
83	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-01-16 05:59:05.553+00	2026-01-16 13:22:45.966+00
89	1	guacadmin	172.18.0.5	4	WAZUH	\N	\N	2026-01-16 17:07:47.762+00	2026-01-16 17:12:58.505+00
87	1	guacadmin	172.18.0.5	2	KALI01	\N	\N	2026-01-16 15:44:28.578+00	2026-01-16 17:12:58.506+00
121	1	guacadmin	172.18.0.5	10	CLIENT01-VNC	\N	\N	2026-01-18 20:12:04.693+00	2026-01-18 20:12:04.716+00
124	1	guacadmin	172.18.0.5	10	CLIENT01-VNC	\N	\N	2026-01-18 20:12:06.231+00	2026-01-18 20:12:06.259+00
94	1	guacadmin	172.18.0.5	8	OPNSENSE	\N	\N	2026-01-16 17:24:17.719+00	2026-01-16 17:24:17.804+00
99	1	guacadmin	172.18.0.5	8	OPNSENSE	\N	\N	2026-01-16 17:32:44.475+00	2026-01-16 17:41:05.48+00
91	1	guacadmin	172.18.0.5	4	WAZUH	\N	\N	2026-01-16 17:15:24.166+00	2026-01-16 17:42:54.81+00
126	1	guacadmin	172.18.0.5	9	CLIENT01	\N	\N	2026-01-18 20:23:16.72+00	2026-01-18 20:29:05.549+00
101	1	guacadmin	172.18.0.5	4	WAZUH	\N	\N	2026-01-16 20:13:10.578+00	2026-01-16 20:44:16.178+00
135	1	guacadmin	172.18.0.5	11	PROXMOX	\N	\N	2026-01-20 07:18:35.796+00	2026-01-20 07:18:35.921+00
143	1	guacadmin	172.18.0.5	10	CLIENT01-VNC	\N	\N	2026-01-20 07:21:11.361+00	2026-01-20 07:21:11.405+00
154	1	guacadmin	172.18.0.5	7	WIN2025	\N	\N	2026-01-20 09:45:32.431+00	2026-01-20 09:45:38.911+00
156	1	guacadmin	172.18.0.5	7	WIN2025	\N	\N	2026-01-20 09:46:16.303+00	2026-01-20 09:46:25.889+00
171	1	guacadmin	172.18.0.5	10	CLIENT01-VNC	\N	\N	2026-01-20 14:22:07.113+00	2026-01-20 14:22:07.18+00
174	1	guacadmin	172.18.0.5	10	CLIENT01-VNC	\N	\N	2026-01-20 14:23:05.579+00	2026-01-20 14:23:05.891+00
169	1	guacadmin	172.18.0.5	9	CLIENT01	\N	\N	2026-01-20 14:21:49.555+00	2026-01-20 14:45:58.444+00
191	1	guacadmin	172.18.0.5	10	CLIENT01-VNC	\N	\N	2026-01-20 18:35:55.077+00	2026-01-20 18:35:55.127+00
187	1	guacadmin	172.18.0.5	9	CLIENT01	\N	\N	2026-01-20 18:35:20.27+00	2026-01-20 18:44:37.132+00
197	1	guacadmin	172.18.0.5	9	CLIENT01	\N	\N	2026-01-20 19:16:37.34+00	2026-01-20 19:21:36.692+00
85	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-01-16 06:59:39.818+00	2026-01-16 13:22:45.966+00
120	1	guacadmin	172.18.0.5	10	CLIENT01-VNC	\N	\N	2026-01-18 20:12:04.408+00	2026-01-18 20:12:04.434+00
90	1	guacadmin	172.18.0.5	8	OPNSENSE	\N	\N	2026-01-16 17:10:44.527+00	2026-01-16 17:12:58.507+00
98	1	guacadmin	172.18.0.5	2	KALI01	\N	\N	2026-01-16 17:30:57.454+00	2026-01-16 17:42:54.808+00
122	1	guacadmin	172.18.0.5	10	CLIENT01-VNC	\N	\N	2026-01-18 20:12:05.455+00	2026-01-18 20:12:05.483+00
100	1	guacadmin	172.18.0.5	2	KALI01	\N	\N	2026-01-16 20:08:30.678+00	2026-01-16 20:12:58.576+00
125	1	guacadmin	172.18.0.5	10	CLIENT01-VNC	\N	\N	2026-01-18 20:12:34.79+00	2026-01-18 20:29:46.406+00
137	1	guacadmin	172.18.0.5	11	PROXMOX	\N	\N	2026-01-20 07:19:06.151+00	2026-01-20 07:19:06.275+00
139	1	guacadmin	172.18.0.5	11	PROXMOX	\N	\N	2026-01-20 07:19:36.506+00	2026-01-20 07:19:36.631+00
148	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-01-20 07:39:42.481+00	2026-01-20 08:27:05.545+00
153	1	guacadmin	172.18.0.5	7	WIN2025	\N	\N	2026-01-20 09:45:15.052+00	2026-01-20 09:45:21.571+00
157	1	guacadmin	172.18.0.5	8	OPNSENSE	\N	\N	2026-01-20 12:30:43.546+00	2026-01-20 13:10:35.402+00
160	1	guacadmin	172.18.0.5	10	CLIENT01-VNC	\N	\N	2026-01-20 14:02:24.555+00	2026-01-20 14:02:24.728+00
163	1	guacadmin	172.18.0.5	9	CLIENT01	\N	\N	2026-01-20 14:03:03.176+00	2026-01-20 14:04:39.745+00
173	1	guacadmin	172.18.0.5	10	CLIENT01-VNC	\N	\N	2026-01-20 14:22:49.815+00	2026-01-20 14:22:49.893+00
179	1	guacadmin	172.18.0.5	10	CLIENT01-VNC	\N	\N	2026-01-20 18:17:31.631+00	2026-01-20 18:17:31.754+00
188	1	guacadmin	172.18.0.5	10	CLIENT01-VNC	\N	\N	2026-01-20 18:35:53.131+00	2026-01-20 18:35:53.242+00
190	1	guacadmin	172.18.0.5	10	CLIENT01-VNC	\N	\N	2026-01-20 18:35:54.661+00	2026-01-20 18:35:54.709+00
194	1	guacadmin	172.18.0.5	9	CLIENT01	\N	\N	2026-01-20 18:45:58.13+00	2026-01-20 18:46:01.253+00
198	1	guacadmin	172.18.0.5	10	CLIENT01-RDP	\N	\N	2026-01-20 19:24:26.251+00	2026-01-20 19:24:52.089+00
110	1	guacadmin	172.18.0.5	9	CLIENT01	\N	\N	2026-01-18 20:08:00.871+00	2026-01-18 20:23:14.903+00
88	1	guacadmin	172.18.0.5	8	OPNSENSE	\N	\N	2026-01-16 16:23:28.887+00	2026-01-16 17:08:34.88+00
92	1	guacadmin	172.18.0.5	8	OPNSENSE	\N	\N	2026-01-16 17:23:44.541+00	2026-01-16 17:23:44.904+00
96	1	guacadmin	172.18.0.5	8	OPNSENSE	\N	\N	2026-01-16 17:25:13.057+00	2026-01-16 17:25:23.116+00
129	1	guacadmin	172.18.0.5	10	CLIENT01-VNC	\N	\N	2026-01-18 20:29:48.864+00	2026-01-18 20:29:48.887+00
127	1	guacadmin	172.18.0.5	9	CLIENT01	\N	\N	2026-01-18 20:29:07.631+00	2026-01-18 20:31:41.496+00
102	1	guacadmin	172.18.0.5	1	VULNSRV01	\N	\N	2026-01-16 20:14:20.564+00	2026-01-16 20:49:49.603+00
103	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-01-16 20:14:54.8+00	2026-01-16 20:50:14.905+00
104	1	guacadmin	172.18.0.5	8	OPNSENSE	\N	\N	2026-01-16 20:37:04.392+00	2026-01-16 21:05:09.145+00
131	1	guacadmin	172.18.0.5	11	PROXMOX	\N	\N	2026-01-20 07:17:50.744+00	2026-01-20 07:17:50.919+00
106	1	guacadmin	172.18.0.5	10	CLIENT01-VNC	\N	\N	2026-01-18 20:02:36.276+00	2026-01-18 20:02:36.312+00
107	1	guacadmin	172.18.0.5	10	CLIENT01-VNC	\N	\N	2026-01-18 20:06:25.08+00	2026-01-18 20:06:25.218+00
133	1	guacadmin	172.18.0.5	11	PROXMOX	\N	\N	2026-01-20 07:18:07.388+00	2026-01-20 07:18:07.512+00
108	1	guacadmin	172.18.0.5	10	CLIENT01-VNC	\N	\N	2026-01-18 20:06:26.29+00	2026-01-18 20:06:26.42+00
109	1	guacadmin	172.18.0.5	10	CLIENT01-VNC	\N	\N	2026-01-18 20:06:26.866+00	2026-01-18 20:06:26.995+00
105	1	guacadmin	172.18.0.5	9	CLIENT01	\N	\N	2026-01-18 20:02:24.482+00	2026-01-18 20:07:41.952+00
138	1	guacadmin	172.18.0.5	11	PROXMOX	\N	\N	2026-01-20 07:19:21.319+00	2026-01-20 07:19:21.444+00
111	1	guacadmin	172.18.0.5	10	CLIENT01-VNC	\N	\N	2026-01-18 20:10:30.009+00	2026-01-18 20:10:30.143+00
112	1	guacadmin	172.18.0.5	10	CLIENT01-VNC	\N	\N	2026-01-18 20:10:31.456+00	2026-01-18 20:10:31.585+00
140	1	guacadmin	172.18.0.5	11	PROXMOX	\N	\N	2026-01-20 07:19:51.687+00	2026-01-20 07:19:51.813+00
113	1	guacadmin	172.18.0.5	10	CLIENT01-VNC	\N	\N	2026-01-18 20:10:31.99+00	2026-01-18 20:10:32.116+00
114	1	guacadmin	172.18.0.5	10	CLIENT01-VNC	\N	\N	2026-01-18 20:11:09.863+00	2026-01-18 20:11:09.992+00
141	1	guacadmin	172.18.0.5	11	PROXMOX	\N	\N	2026-01-20 07:20:50.112+00	2026-01-20 07:20:55.186+00
115	1	guacadmin	172.18.0.5	10	CLIENT01-VNC	\N	\N	2026-01-18 20:11:11.26+00	2026-01-18 20:11:11.387+00
130	1	guacadmin	172.18.0.5	9	CLIENT01	\N	\N	2026-01-20 07:15:57.068+00	2026-01-20 07:21:02.145+00
116	1	guacadmin	172.18.0.5	10	CLIENT01-VNC	\N	\N	2026-01-18 20:11:11.721+00	2026-01-18 20:11:11.748+00
145	1	guacadmin	172.18.0.5	10	CLIENT01-VNC	\N	\N	2026-01-20 07:21:43.195+00	2026-01-20 07:21:43.555+00
147	1	guacadmin	172.18.0.5	8	OPNSENSE	\N	\N	2026-01-20 07:21:59.63+00	2026-01-20 07:22:04.423+00
149	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-01-20 08:09:08.977+00	2026-01-20 08:27:05.545+00
150	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-01-20 08:43:52.431+00	2026-01-20 08:43:55.627+00
159	1	guacadmin	172.18.0.5	10	CLIENT01-VNC	\N	\N	2026-01-20 14:02:08.351+00	2026-01-20 14:02:08.611+00
161	1	guacadmin	172.18.0.5	10	CLIENT01-VNC	\N	\N	2026-01-20 14:02:40.56+00	2026-01-20 14:02:40.717+00
164	1	guacadmin	172.18.0.5	9	CLIENT01	\N	\N	2026-01-20 14:05:24.589+00	2026-01-20 14:05:34.654+00
166	1	guacadmin	172.18.0.5	9	CLIENT01	\N	\N	2026-01-20 14:06:09.593+00	2026-01-20 14:06:12.711+00
158	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-01-20 12:33:52.303+00	2026-01-20 14:52:05.01+00
180	1	guacadmin	172.18.0.5	10	CLIENT01-VNC	\N	\N	2026-01-20 18:17:33.036+00	2026-01-20 18:17:33.11+00
182	1	guacadmin	172.18.0.5	10	CLIENT01-VNC	\N	\N	2026-01-20 18:18:30.794+00	2026-01-20 18:18:30.868+00
184	1	guacadmin	172.18.0.5	9	CLIENT01	\N	\N	2026-01-20 18:18:53.054+00	2026-01-20 18:35:18.786+00
189	1	guacadmin	172.18.0.5	10	CLIENT01-VNC	\N	\N	2026-01-20 18:35:54.18+00	2026-01-20 18:35:54.225+00
192	1	guacadmin	172.18.0.5	9	CLIENT01	\N	\N	2026-01-20 18:45:07.773+00	2026-01-20 18:45:17.84+00
193	1	guacadmin	172.18.0.5	9	CLIENT01	\N	\N	2026-01-20 18:45:26.701+00	2026-01-20 18:45:29.832+00
186	1	guacadmin	172.18.0.5	8	OPNSENSE	\N	\N	2026-01-20 18:28:44.308+00	2026-01-20 19:16:11.588+00
195	1	guacadmin	172.18.0.5	9	CLIENT01	\N	\N	2026-01-20 18:47:13.7+00	2026-01-20 19:16:35.157+00
196	1	guacadmin	172.18.0.5	10	CLIENT01-RDP	\N	\N	2026-01-20 19:16:00.911+00	2026-01-20 19:21:35.798+00
199	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-01-23 11:20:11.704+00	2026-01-23 11:24:45.896+00
200	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-01-23 11:25:00.977+00	2026-01-23 11:25:06.151+00
201	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-01-23 11:25:11.598+00	2026-01-23 11:25:11.627+00
202	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-01-23 11:25:12.188+00	2026-01-23 11:25:12.217+00
203	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-01-23 11:25:12.752+00	2026-01-23 11:25:12.78+00
204	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-01-23 11:25:21.903+00	2026-01-23 11:25:21.932+00
205	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-01-23 11:25:22.549+00	2026-01-23 11:25:22.575+00
206	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-01-23 11:25:24.594+00	2026-01-23 11:25:24.62+00
207	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-01-23 11:25:40.387+00	2026-01-23 11:25:40.434+00
208	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-01-23 11:25:56.111+00	2026-01-23 11:25:56.14+00
209	1	guacadmin	172.18.0.5	1	APPSRV01	\N	\N	2026-01-23 11:26:01.696+00	2026-01-23 11:26:04.92+00
210	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-01-23 11:26:11.389+00	\N
211	1	guacadmin	172.18.0.5	5	VULNSRV02	\N	\N	2026-01-23 11:28:39.559+00	\N
212	1	guacadmin	172.18.0.5	12	VULNSRV01	\N	\N	2026-01-23 11:29:04.776+00	\N
213	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-02-19 12:35:47.648+00	2026-02-19 12:35:47.738+00
214	1	guacadmin	172.18.0.5	2	KALI01	\N	\N	2026-02-19 12:35:59.141+00	2026-02-19 12:36:07.606+00
215	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-02-19 12:42:58.915+00	2026-02-19 12:42:58.949+00
216	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-02-19 12:43:01.22+00	2026-02-19 12:43:01.245+00
217	1	guacadmin	172.18.0.5	2	KALI01	\N	\N	2026-02-19 12:43:05.291+00	2026-02-19 12:43:05.775+00
218	1	guacadmin	172.18.0.5	9	CLIENT01	\N	\N	2026-02-19 12:43:16.601+00	2026-02-19 12:43:21.026+00
219	1	guacadmin	172.18.0.5	2	KALI01	\N	\N	2026-02-19 12:43:21.08+00	2026-02-19 12:43:21.216+00
220	1	guacadmin	172.18.0.5	2	KALI01	\N	\N	2026-02-19 12:44:16.725+00	2026-02-19 12:44:16.859+00
221	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-02-19 12:44:21.708+00	2026-02-19 12:44:21.73+00
222	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-02-19 12:44:22.722+00	2026-02-19 12:44:22.745+00
223	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-02-19 12:44:22.893+00	2026-02-19 12:44:22.924+00
224	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-02-19 12:44:23.043+00	2026-02-19 12:44:23.066+00
225	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-02-19 12:44:39.068+00	2026-02-19 12:44:39.201+00
226	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-02-19 12:44:55.068+00	2026-02-19 12:44:55.319+00
227	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-02-19 12:45:11.075+00	2026-02-19 12:45:11.299+00
228	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-02-19 12:45:40.028+00	2026-02-19 12:45:40.098+00
229	1	guacadmin	172.18.0.5	2	KALI01	\N	\N	2026-02-19 12:46:17.06+00	2026-02-19 12:55:51.231+00
232	1	guacadmin	172.18.0.5	10	CLIENT01-RDP	\N	\N	2026-02-19 13:06:38.278+00	2026-02-19 13:06:38.63+00
233	1	guacadmin	172.18.0.5	10	CLIENT01-RDP	\N	\N	2026-02-19 13:06:39.861+00	2026-02-19 13:06:40.206+00
235	1	guacadmin	172.18.0.5	10	CLIENT01-RDP	\N	\N	2026-02-19 13:06:56.073+00	2026-02-19 13:06:56.438+00
236	1	guacadmin	172.18.0.5	10	CLIENT01-RDP	\N	\N	2026-02-19 13:07:12.08+00	2026-02-19 13:07:12.423+00
237	1	guacadmin	172.18.0.5	10	CLIENT01-RDP	\N	\N	2026-02-19 13:07:28.086+00	2026-02-19 13:07:28.428+00
230	1	guacadmin	172.18.0.5	2	KALI01	\N	\N	2026-02-19 13:02:30.739+00	2026-02-19 13:07:44.807+00
238	1	guacadmin	172.18.0.5	10	CLIENT01-RDP	\N	\N	2026-02-19 13:10:14.088+00	2026-02-19 13:10:14.715+00
231	1	guacadmin	172.18.0.5	12	VULNSRV01	\N	\N	2026-02-19 13:05:30.941+00	2026-02-19 13:20:38.316+00
239	1	guacadmin	172.18.0.5	2	KALI01	\N	\N	2026-02-19 13:18:38.874+00	2026-02-19 13:26:42.038+00
240	1	guacadmin	172.18.0.5	10	CLIENT01-RDP	\N	\N	2026-02-19 13:18:47.329+00	2026-02-19 13:18:47.673+00
242	1	guacadmin	172.18.0.5	10	CLIENT01-RDP	\N	\N	2026-02-19 13:19:19.101+00	2026-02-19 13:19:19.458+00
245	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-02-19 13:31:02.33+00	2026-02-19 13:31:02.378+00
247	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-02-19 13:31:03.893+00	2026-02-19 13:31:03.914+00
241	1	guacadmin	172.18.0.5	10	CLIENT01-RDP	\N	\N	2026-02-19 13:19:03.1+00	2026-02-19 13:19:03.463+00
243	1	guacadmin	172.18.0.5	10	CLIENT01-RDP	\N	\N	2026-02-19 13:19:35.105+00	2026-02-19 13:19:35.456+00
246	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-02-19 13:31:03.74+00	2026-02-19 13:31:03.764+00
248	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-02-19 13:31:04.035+00	2026-02-19 13:31:04.056+00
250	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-02-19 13:31:45.449+00	2026-02-19 13:31:45.474+00
252	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-02-19 13:31:45.806+00	2026-02-19 13:31:45.826+00
244	1	guacadmin	172.18.0.5	2	KALI01	\N	\N	2026-02-19 13:26:44.278+00	2026-02-19 13:39:50.101+00
234	1	guacadmin	172.18.0.5	9	CLIENT01	\N	\N	2026-02-19 13:06:48.266+00	2026-02-19 13:20:36.353+00
249	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-02-19 13:31:44.6+00	2026-02-19 13:31:44.65+00
251	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-02-19 13:31:45.609+00	2026-02-19 13:31:45.629+00
253	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-02-19 13:32:54.324+00	2026-02-19 13:32:54.361+00
254	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-02-19 13:32:55.236+00	2026-02-19 13:32:55.257+00
255	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-02-19 13:32:55.39+00	2026-02-19 13:32:55.413+00
256	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-02-19 13:33:11.097+00	2026-02-19 13:33:11.38+00
257	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-02-19 13:33:27.124+00	2026-02-19 13:33:27.376+00
258	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-02-19 13:33:43.103+00	2026-02-19 13:33:58.133+00
259	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-02-19 13:35:04.539+00	2026-02-19 13:35:04.596+00
260	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-02-19 13:35:05.469+00	2026-02-19 13:35:05.488+00
261	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-02-19 13:35:21.103+00	2026-02-19 13:35:21.385+00
262	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-02-19 13:35:37.108+00	2026-02-19 13:35:37.371+00
263	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-02-19 13:35:53.104+00	2026-02-19 13:35:53.305+00
264	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-02-19 13:38:14.116+00	2026-02-19 13:38:14.701+00
265	1	guacadmin	172.18.0.5	2	KALI01	\N	\N	2026-02-19 13:45:35.753+00	2026-02-19 13:45:45.805+00
267	1	guacadmin	172.18.0.5	9	CLIENT01	\N	\N	2026-02-19 13:51:02.583+00	2026-02-19 13:51:19.601+00
268	1	guacadmin	172.18.0.5	10	CLIENT01-RDP	\N	\N	2026-02-19 13:51:13.495+00	2026-02-19 13:51:28.972+00
266	1	guacadmin	172.18.0.5	2	KALI01	\N	\N	2026-02-19 13:45:48.882+00	2026-02-19 13:56:18.758+00
270	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-02-19 14:04:05.787+00	2026-02-19 14:04:05.836+00
271	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-02-19 14:04:21.125+00	2026-02-19 14:04:21.299+00
272	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-02-19 14:04:37.126+00	2026-02-19 14:04:37.381+00
273	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-02-19 14:04:53.133+00	2026-02-19 14:04:53.374+00
274	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-02-19 14:07:14.152+00	2026-02-19 14:07:14.659+00
275	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-02-19 14:08:54.143+00	2026-02-19 14:08:54.379+00
276	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-02-19 14:09:10.155+00	2026-02-19 14:09:10.393+00
277	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-02-19 14:09:26.15+00	2026-02-19 14:09:26.415+00
278	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-02-19 14:09:42.145+00	2026-02-19 14:09:42.415+00
269	1	guacadmin	172.18.0.5	2	KALI01	\N	\N	2026-02-19 13:57:44.259+00	2026-02-19 14:13:27.189+00
279	1	guacadmin	172.18.0.5	2	KALI01	\N	\N	2026-02-20 05:58:02.191+00	2026-02-20 05:58:02.354+00
280	1	guacadmin	172.18.0.5	2	KALI01	\N	\N	2026-02-20 05:58:11.585+00	2026-02-20 05:58:11.722+00
281	1	guacadmin	172.18.0.5	2	KALI01	\N	\N	2026-02-20 05:58:27.188+00	2026-02-20 05:58:27.323+00
282	1	guacadmin	172.18.0.5	2	KALI01	\N	\N	2026-02-20 05:58:29.218+00	2026-02-20 05:58:29.35+00
283	1	guacadmin	172.18.0.5	2	KALI01	\N	\N	2026-02-20 05:58:37.334+00	2026-02-20 05:58:37.466+00
284	1	guacadmin	172.18.0.5	2	KALI01	\N	\N	2026-02-20 05:58:52.678+00	2026-02-20 05:58:52.81+00
285	1	guacadmin	172.18.0.5	2	KALI01	\N	\N	2026-02-20 05:59:07.433+00	2026-02-20 05:59:07.569+00
286	1	guacadmin	172.18.0.5	2	KALI01	\N	\N	2026-02-20 05:59:08.635+00	2026-02-20 05:59:08.769+00
287	1	guacadmin	172.18.0.5	2	KALI01	\N	\N	2026-02-20 05:59:24.189+00	2026-02-20 05:59:24.328+00
288	1	guacadmin	172.18.0.5	2	KALI01	\N	\N	2026-02-20 05:59:56.984+00	2026-02-20 05:59:57.111+00
289	1	guacadmin	172.18.0.5	2	KALI01	\N	\N	2026-02-20 05:59:58.122+00	2026-02-20 05:59:58.247+00
290	1	guacadmin	172.18.0.5	2	KALI01	\N	\N	2026-02-20 06:00:58.986+00	2026-02-20 06:00:59.119+00
291	1	guacadmin	172.18.0.5	2	KALI01	\N	\N	2026-02-20 06:01:00.075+00	2026-02-20 06:01:00.199+00
292	1	guacadmin	172.18.0.5	2	KALI01	\N	\N	2026-02-20 06:01:16.184+00	2026-02-20 06:01:16.311+00
293	1	guacadmin	172.18.0.5	2	KALI01	\N	\N	2026-02-20 06:01:32.188+00	2026-02-20 06:01:32.324+00
294	1	guacadmin	172.18.0.5	2	KALI01	\N	\N	2026-02-20 06:01:48.195+00	2026-02-20 06:01:48.324+00
295	1	guacadmin	172.18.0.5	2	KALI01	\N	\N	2026-02-20 06:02:04.188+00	2026-02-20 06:02:04.324+00
296	1	guacadmin	172.18.0.5	2	KALI01	\N	\N	2026-02-20 06:02:51.187+00	2026-02-20 06:02:51.32+00
297	1	guacadmin	172.18.0.5	2	KALI01	\N	\N	2026-02-20 06:03:07.186+00	2026-02-20 06:03:17.248+00
298	1	guacadmin	172.18.0.5	2	KALI01	\N	\N	2026-02-20 06:03:33.193+00	2026-02-20 06:03:43.261+00
299	1	guacadmin	172.18.0.5	2	KALI01	\N	\N	2026-02-20 06:11:29.194+00	2026-02-20 06:11:39.259+00
300	1	guacadmin	172.18.0.5	2	KALI01	\N	\N	2026-02-20 06:11:56.209+00	2026-02-20 06:11:56.362+00
301	1	guacadmin	172.18.0.5	2	KALI01	\N	\N	2026-02-20 06:12:12.191+00	2026-02-20 06:12:12.319+00
302	1	guacadmin	172.18.0.5	2	KALI01	\N	\N	2026-02-20 06:12:28.191+00	2026-02-20 06:12:28.319+00
303	1	guacadmin	172.18.0.5	2	KALI01	\N	\N	2026-02-20 06:12:59.099+00	2026-02-20 06:12:59.231+00
304	1	guacadmin	172.18.0.5	12	VULNSRV01	\N	\N	2026-02-20 06:13:04.696+00	2026-02-20 06:13:13.469+00
305	1	guacadmin	172.18.0.5	2	KALI01	\N	\N	2026-02-20 06:25:20.555+00	2026-02-20 06:55:37.954+00
306	1	guacadmin	172.18.0.5	2	KALI01	\N	\N	2026-02-20 07:23:55.133+00	\N
307	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-02-20 07:24:49.027+00	\N
308	1	guacadmin	172.18.0.5	13	KALI01-VNC-2	\N	\N	2026-02-20 07:25:32.075+00	\N
309	1	guacadmin	172.18.0.5	15	KALI01-VNC-4	\N	\N	2026-02-20 07:27:48.353+00	\N
310	1	guacadmin	172.18.0.4	10	CLIENT01-RDP	\N	\N	2026-03-17 07:42:34.422+00	2026-03-17 07:42:35.817+00
311	1	guacadmin	172.18.0.5	10	CLIENT01-RDP-1	\N	\N	2026-03-17 08:15:00.963+00	2026-03-17 08:16:39.756+00
312	1	guacadmin	172.18.0.5	16	CLIENT01-RDP-2	\N	\N	2026-03-17 08:15:13.991+00	2026-03-17 08:16:39.756+00
314	1	guacadmin	172.18.0.5	9	CLIENT01	\N	\N	2026-03-17 08:17:57.338+00	2026-03-17 08:17:57.99+00
315	1	guacadmin	172.18.0.5	9	CLIENT01	\N	\N	2026-03-17 08:18:01.364+00	2026-03-17 08:18:01.523+00
316	1	guacadmin	172.18.0.5	9	CLIENT01	\N	\N	2026-03-17 08:18:19.403+00	2026-03-17 08:18:19.549+00
317	1	guacadmin	172.18.0.5	9	CLIENT01	\N	\N	2026-03-17 08:18:37.402+00	2026-03-17 08:18:37.552+00
318	1	guacadmin	172.18.0.5	9	CLIENT01	\N	\N	2026-03-17 08:18:55.4+00	2026-03-17 08:18:55.548+00
319	1	guacadmin	172.18.0.5	10	CLIENT01-RDP-1	\N	\N	2026-03-17 08:19:20.66+00	2026-03-17 08:21:08.661+00
321	1	guacadmin	172.18.0.5	17	CLIENT01-RDP-3	\N	\N	2026-03-17 08:20:13.845+00	2026-03-17 08:21:06.963+00
320	1	guacadmin	172.18.0.5	16	CLIENT01-RDP-2	\N	\N	2026-03-17 08:19:54.866+00	2026-03-17 08:21:07.895+00
313	1	guacadmin	172.18.0.5	18	CLIENT01-RDP-4	\N	\N	2026-03-17 08:16:44.144+00	2026-03-17 08:21:05.995+00
322	1	guacadmin	172.18.0.2	17	CLIENT01-RDP-3	\N	\N	2026-03-17 11:12:41.82+00	2026-03-17 11:12:46.48+00
323	1	guacadmin	172.18.0.2	4	WAZUH	\N	\N	2026-03-17 11:41:58.857+00	2026-03-17 11:42:02.719+00
326	1	guacadmin	172.18.0.2	4	WAZUH	\N	\N	2026-03-17 12:03:37.72+00	2026-03-17 12:03:37.943+00
327	1	guacadmin	172.18.0.2	4	WAZUH	\N	\N	2026-03-17 12:03:55.664+00	2026-03-17 12:03:55.81+00
325	1	guacadmin	172.18.0.2	6	KALI01-VNC-1	\N	\N	2026-03-17 11:53:37.319+00	2026-03-17 12:05:01.016+00
324	1	guacadmin	172.18.0.2	4	WAZUH	\N	\N	2026-03-17 11:42:47.459+00	2026-03-17 12:06:29.109+00
328	1	guacadmin	172.18.0.2	4	WAZUH	\N	\N	2026-03-17 12:04:21.27+00	2026-03-17 12:21:26.171+00
330	1	guacadmin	172.18.0.2	4	WAZUH	\N	\N	2026-03-17 12:21:31.818+00	2026-03-17 12:27:29.76+00
329	1	guacadmin	172.18.0.2	6	KALI01-VNC-1	\N	\N	2026-03-17 12:05:11.765+00	2026-03-17 12:27:29.76+00
332	1	guacadmin	172.18.0.2	6	KALI01-VNC-1	\N	\N	2026-03-17 12:30:42.349+00	2026-03-17 12:39:22.311+00
331	1	guacadmin	172.18.0.2	4	WAZUH	\N	\N	2026-03-17 12:29:44.656+00	2026-03-17 12:40:41.206+00
333	1	guacadmin	172.18.0.2	4	WAZUH	\N	\N	2026-03-17 12:40:48.793+00	2026-03-17 12:52:28.811+00
334	1	guacadmin	172.18.0.2	4	WAZUH	\N	\N	2026-03-17 12:53:19.91+00	2026-03-17 13:13:30.261+00
336	1	guacadmin	172.18.0.2	4	WAZUH	\N	\N	2026-03-17 13:14:14.141+00	2026-03-17 13:26:54.102+00
337	1	guacadmin	172.18.0.2	4	WAZUH	\N	\N	2026-03-17 13:27:02.571+00	2026-03-17 13:27:22.902+00
335	1	guacadmin	172.18.0.2	6	KALI01-VNC-1	\N	\N	2026-03-17 13:10:21.238+00	2026-03-17 13:27:49.083+00
339	1	guacadmin	172.18.0.2	6	KALI01-VNC-1	\N	\N	2026-03-17 13:28:07.749+00	2026-03-17 13:28:46.592+00
340	1	guacadmin	172.18.0.2	6	KALI01-VNC-1	\N	\N	2026-03-17 13:29:04.76+00	2026-03-17 13:29:07.9+00
341	1	guacadmin	172.18.0.2	6	KALI01-VNC-1	\N	\N	2026-03-17 13:29:25.754+00	2026-03-17 13:29:28.894+00
342	1	guacadmin	172.18.0.2	6	KALI01-VNC-1	\N	\N	2026-03-17 13:29:46.737+00	2026-03-17 13:29:49.885+00
343	1	guacadmin	172.18.0.2	6	KALI01-VNC-1	\N	\N	2026-03-17 13:30:07.729+00	2026-03-17 13:30:10.876+00
344	1	guacadmin	172.18.0.2	6	KALI01-VNC-1	\N	\N	2026-03-17 13:30:28.743+00	2026-03-17 13:30:31.868+00
345	1	guacadmin	172.18.0.2	6	KALI01-VNC-1	\N	\N	2026-03-17 13:30:49.722+00	2026-03-17 13:30:50.166+00
346	1	guacadmin	172.18.0.2	6	KALI01-VNC-1	\N	\N	2026-03-17 13:31:08.728+00	2026-03-17 13:31:09.115+00
347	1	guacadmin	172.18.0.2	6	KALI01-VNC-1	\N	\N	2026-03-17 13:31:26.746+00	2026-03-17 13:31:26.8+00
348	1	guacadmin	172.18.0.2	6	KALI01-VNC-1	\N	\N	2026-03-17 13:31:44.737+00	2026-03-17 13:31:59.791+00
338	1	guacadmin	172.18.0.2	4	WAZUH	\N	\N	2026-03-17 13:27:30.785+00	2026-03-17 13:34:53.114+00
349	1	guacadmin	172.18.0.2	6	KALI01-VNC-1	\N	\N	2026-03-17 13:32:17.74+00	2026-03-17 13:52:39.644+00
350	1	guacadmin	172.18.0.2	4	WAZUH	\N	\N	2026-03-17 13:35:54.031+00	2026-03-17 14:14:17.305+00
352	1	guacadmin	172.18.0.2	6	KALI01-VNC-1	\N	\N	2026-03-17 14:22:16.097+00	2026-03-17 14:22:38.419+00
351	1	guacadmin	172.18.0.2	4	WAZUH	\N	\N	2026-03-17 14:14:23.474+00	2026-03-17 14:25:18.451+00
354	1	guacadmin	172.18.0.2	4	WAZUH	\N	\N	2026-03-17 14:26:29.142+00	2026-03-17 14:40:18.942+00
353	1	guacadmin	172.18.0.2	6	KALI01-VNC-1	\N	\N	2026-03-17 14:22:40.926+00	2026-03-17 14:40:21.354+00
355	1	guacadmin	172.18.0.2	4	WAZUH	\N	\N	2026-03-17 14:40:28.086+00	2026-03-17 14:41:15.357+00
356	1	guacadmin	172.18.0.2	4	WAZUH	\N	\N	2026-03-18 08:08:42.65+00	2026-03-18 08:08:52.738+00
357	1	guacadmin	172.18.0.2	4	WAZUH	\N	\N	2026-03-18 08:09:08.468+00	2026-03-18 08:09:11.612+00
358	1	guacadmin	172.18.0.2	4	WAZUH	\N	\N	2026-03-18 08:09:27.449+00	2026-03-18 08:15:09.774+00
359	1	guacadmin	172.18.0.2	4	WAZUH	\N	\N	2026-03-18 08:26:11.606+00	2026-03-18 08:37:05.834+00
360	1	guacadmin	172.18.0.2	4	WAZUH	\N	\N	2026-03-18 08:49:49.893+00	2026-03-18 08:58:07.447+00
361	1	guacadmin	172.18.0.2	4	WAZUH	\N	\N	2026-03-18 09:02:05.239+00	2026-03-18 09:02:07.728+00
362	1	guacadmin	172.18.0.5	19	TPOT01	\N	\N	2026-04-18 11:07:57.787+00	2026-04-18 11:08:12.761+00
363	1	guacadmin	172.18.0.5	19	TPOT01	\N	\N	2026-04-18 11:08:16.155+00	\N
364	1	guacadmin	172.18.0.2	6	KALI01-VNC-1	\N	\N	2026-05-08 06:09:27.301+00	2026-05-08 06:09:27.402+00
365	1	guacadmin	172.18.0.2	6	KALI01-VNC-1	\N	\N	2026-05-08 06:09:28.489+00	2026-05-08 06:09:28.521+00
366	1	guacadmin	172.18.0.2	13	KALI01-VNC-2	\N	\N	2026-05-08 06:09:30.101+00	2026-05-08 06:09:30.128+00
367	1	guacadmin	172.18.0.2	19	TPOT01	\N	\N	2026-05-08 06:09:34.02+00	2026-05-08 06:09:39.129+00
368	1	guacadmin	172.18.0.2	6	KALI01-VNC-1	\N	\N	2026-05-08 06:09:43.854+00	2026-05-08 06:09:43.887+00
369	1	guacadmin	172.18.0.2	13	KALI01-VNC-2	\N	\N	2026-05-08 06:09:45.845+00	2026-05-08 06:09:45.878+00
370	1	guacadmin	172.18.0.2	6	KALI01-VNC-1	\N	\N	2026-05-08 06:09:52.144+00	2026-05-08 06:09:52.169+00
371	1	guacadmin	172.18.0.2	6	KALI01-VNC-1	\N	\N	2026-05-08 06:09:53.219+00	2026-05-08 06:09:53.244+00
372	1	guacadmin	172.18.0.2	6	KALI01-VNC-1	\N	\N	2026-05-08 06:09:53.479+00	2026-05-08 06:09:53.502+00
373	1	guacadmin	172.18.0.2	6	KALI01-VNC-1	\N	\N	2026-05-08 06:09:59.839+00	2026-05-08 06:09:59.872+00
374	1	guacadmin	172.18.0.2	13	KALI01-VNC-2	\N	\N	2026-05-08 06:10:01.851+00	2026-05-08 06:10:01.872+00
375	1	guacadmin	172.18.0.2	6	KALI01-VNC-1	\N	\N	2026-05-08 06:10:08.847+00	2026-05-08 06:10:08.87+00
376	1	guacadmin	172.18.0.2	6	KALI01-VNC-1	\N	\N	2026-05-08 06:10:15.836+00	2026-05-08 06:10:15.864+00
377	1	guacadmin	172.18.0.2	13	KALI01-VNC-2	\N	\N	2026-05-08 06:10:17.836+00	2026-05-08 06:10:17.864+00
378	1	guacadmin	172.18.0.2	6	KALI01-VNC-1	\N	\N	2026-05-08 06:10:24.836+00	2026-05-08 06:10:24.871+00
379	1	guacadmin	172.18.0.2	6	KALI01-VNC-1	\N	\N	2026-05-08 06:10:32.84+00	2026-05-08 06:10:32.876+00
380	1	guacadmin	172.18.0.2	13	KALI01-VNC-2	\N	\N	2026-05-08 06:10:33.837+00	2026-05-08 06:10:33.879+00
381	1	guacadmin	172.18.0.2	9	CLIENT01	\N	\N	2026-05-08 06:34:30.485+00	2026-05-08 06:34:32.487+00
382	1	guacadmin	172.18.0.2	2	KALI01	\N	\N	2026-05-08 06:36:27.295+00	2026-05-08 06:36:29.706+00
383	1	guacadmin	172.18.0.2	20	KALI02	\N	\N	2026-05-08 06:36:57.072+00	2026-05-08 06:36:59.702+00
384	1	guacadmin	172.18.0.2	6	KALI01-VNC-1	\N	\N	2026-05-08 06:37:03.513+00	2026-05-08 06:37:03.538+00
\.


--
-- Data for Name: guacamole_connection_parameter; Type: TABLE DATA; Schema: public; Owner: guacamole_user
--

COPY public.guacamole_connection_parameter (connection_id, parameter_name, parameter_value) FROM stdin;
5	hostname	172.20.0.21
5	password	Password1!
5	private-key	-----BEGIN OPENSSH PRIVATE KEY-----\nb3BlbnNzaC1rZXktdjEAAAAABG5vbmUAAAAEbm9uZQAAAAAAAAABAAAAMwAAAAtzc2gtZW\nQyNTUxOQAAACCvYBMYLqeFDQN70YggSnQivfiHVSm6LL1xA6U646hlVgAAAJjTsP1107D9\ndQAAAAtzc2gtZWQyNTUxOQAAACCvYBMYLqeFDQN70YggSnQivfiHVSm6LL1xA6U646hlVg\nAAAEDyK1objn0FHhfvALav18559QQ/3wxDxl/T4B3x5E+w2K9gExgup4UNA3vRiCBKdCK9\n+IdVKbosvXEDpTrjqGVWAAAAEHNoYXJlZC1hZG1pbi1rZXkBAgMEBQ==\n-----END OPENSSH PRIVATE KEY-----
5	port	22
5	username	ubuntu
7	hostname	172.20.0.22
7	password	Password1!
7	port	3389
7	ignore-cert	true
7	username	administrator
8	hostname	172.20.0.2
8	password	opnsense
8	port	22
8	username	root
9	hostname	172.20.0.15
9	password	Password1!
9	private-key	-----BEGIN OPENSSH PRIVATE KEY-----\nb3BlbnNzaC1rZXktdjEAAAAABG5vbmUAAAAEbm9uZQAAAAAAAAABAAAAMwAAAAtzc2gtZW\nQyNTUxOQAAACCvYBMYLqeFDQN70YggSnQivfiHVSm6LL1xA6U646hlVgAAAJjTsP1107D9\ndQAAAAtzc2gtZWQyNTUxOQAAACCvYBMYLqeFDQN70YggSnQivfiHVSm6LL1xA6U646hlVg\nAAAEDyK1objn0FHhfvALav18559QQ/3wxDxl/T4B3x5E+w2K9gExgup4UNA3vRiCBKdCK9\n+IdVKbosvXEDpTrjqGVWAAAAEHNoYXJlZC1hZG1pbi1rZXkBAgMEBQ==\n-----END OPENSSH PRIVATE KEY-----
9	port	22
9	username	ubuntu
1	hostname	172.20.0.25
1	password	Password1!
1	private-key	-----BEGIN OPENSSH PRIVATE KEY-----\nb3BlbnNzaC1rZXktdjEAAAAABG5vbmUAAAAEbm9uZQAAAAAAAAABAAAAMwAAAAtzc2gtZW\nQyNTUxOQAAACCvYBMYLqeFDQN70YggSnQivfiHVSm6LL1xA6U646hlVgAAAJjTsP1107D9\ndQAAAAtzc2gtZWQyNTUxOQAAACCvYBMYLqeFDQN70YggSnQivfiHVSm6LL1xA6U646hlVg\nAAAEDyK1objn0FHhfvALav18559QQ/3wxDxl/T4B3x5E+w2K9gExgup4UNA3vRiCBKdCK9\n+IdVKbosvXEDpTrjqGVWAAAAEHNoYXJlZC1hZG1pbi1rZXkBAgMEBQ==\n-----END OPENSSH PRIVATE KEY-----
1	port	22
1	username	ubuntu
11	hostname	172.20.0.100
11	password	Password1!
11	port	22
11	username	root
12	hostname	172.20.0.10
12	password	Password1!
12	private-key	-----BEGIN OPENSSH PRIVATE KEY-----\nb3BlbnNzaC1rZXktdjEAAAAABG5vbmUAAAAEbm9uZQAAAAAAAAABAAAAMwAAAAtzc2gtZW\nQyNTUxOQAAACCvYBMYLqeFDQN70YggSnQivfiHVSm6LL1xA6U646hlVgAAAJjTsP1107D9\ndQAAAAtzc2gtZWQyNTUxOQAAACCvYBMYLqeFDQN70YggSnQivfiHVSm6LL1xA6U646hlVg\nAAAEDyK1objn0FHhfvALav18559QQ/3wxDxl/T4B3x5E+w2K9gExgup4UNA3vRiCBKdCK9\n+IdVKbosvXEDpTrjqGVWAAAAEHNoYXJlZC1hZG1pbi1rZXkBAgMEBQ==\n-----END OPENSSH PRIVATE KEY-----
12	port	22
12	username	ubuntu
2	hostname	172.20.0.11
2	private-key	-----BEGIN OPENSSH PRIVATE KEY-----\nb3BlbnNzaC1rZXktdjEAAAAABG5vbmUAAAAEbm9uZQAAAAAAAAABAAAAMwAAAAtzc2gtZW\nQyNTUxOQAAACCvYBMYLqeFDQN70YggSnQivfiHVSm6LL1xA6U646hlVgAAAJjTsP1107D9\ndQAAAAtzc2gtZWQyNTUxOQAAACCvYBMYLqeFDQN70YggSnQivfiHVSm6LL1xA6U646hlVg\nAAAEDyK1objn0FHhfvALav18559QQ/3wxDxl/T4B3x5E+w2K9gExgup4UNA3vRiCBKdCK9\n+IdVKbosvXEDpTrjqGVWAAAAEHNoYXJlZC1hZG1pbi1rZXkBAgMEBQ==\n-----END OPENSSH PRIVATE KEY-----
2	port	22
2	username	kali
13	hostname	172.20.0.11
13	password	password
13	port	5902
13	username	kali2
6	hostname	172.20.0.11
6	password	password
6	port	5901
6	username	kali1
14	hostname	172.20.0.11
14	password	password
14	port	5903
14	username	kali3
15	hostname	172.20.0.11
15	password	password
15	port	5904
15	username	kali4
10	hostname	172.20.0.15
10	password	Password1!
10	port	3389
10	ignore-cert	true
10	username	ubuntu1
16	hostname	172.20.0.15
16	password	Password1!
16	port	3389
16	ignore-cert	true
16	username	ubuntu2
17	hostname	172.20.0.15
17	password	Password1!
17	port	3389
17	ignore-cert	true
17	username	ubuntu3
18	hostname	172.20.0.15
18	password	Password1!
18	port	3389
18	ignore-cert	true
18	username	ubuntu4
4	hostname	172.20.0.20
4	password	Password1!
4	private-key	-----BEGIN OPENSSH PRIVATE KEY-----\nb3BlbnNzaC1rZXktdjEAAAAABG5vbmUAAAAEbm9uZQAAAAAAAAABAAAAMwAAAAtzc2gtZW\nQyNTUxOQAAACCvYBMYLqeFDQN70YggSnQivfiHVSm6LL1xA6U646hlVgAAAJjTsP1107D9\ndQAAAAtzc2gtZWQyNTUxOQAAACCvYBMYLqeFDQN70YggSnQivfiHVSm6LL1xA6U646hlVg\nAAAEDyK1objn0FHhfvALav18559QQ/3wxDxl/T4B3x5E+w2K9gExgup4UNA3vRiCBKdCK9\n+IdVKbosvXEDpTrjqGVWAAAAEHNoYXJlZC1hZG1pbi1rZXkBAgMEBQ==\n-----END OPENSSH PRIVATE KEY-----
4	port	22
4	username	wazuh
19	hostname	172.20.0.210
19	password	Password1!
19	private-key	-----BEGIN OPENSSH PRIVATE KEY-----\nb3BlbnNzaC1rZXktdjEAAAAABG5vbmUAAAAEbm9uZQAAAAAAAAABAAAAMwAAAAtzc2gtZW\nQyNTUxOQAAACCvYBMYLqeFDQN70YggSnQivfiHVSm6LL1xA6U646hlVgAAAJjTsP1107D9\ndQAAAAtzc2gtZWQyNTUxOQAAACCvYBMYLqeFDQN70YggSnQivfiHVSm6LL1xA6U646hlVg\nAAAEDyK1objn0FHhfvALav18559QQ/3wxDxl/T4B3x5E+w2K9gExgup4UNA3vRiCBKdCK9\n+IdVKbosvXEDpTrjqGVWAAAAEHNoYXJlZC1hZG1pbi1rZXkBAgMEBQ==\n-----END OPENSSH PRIVATE KEY-----
19	port	64295
19	username	ubuntu
20	hostname	172.20.0.150
20	private-key	-----BEGIN OPENSSH PRIVATE KEY-----\nb3BlbnNzaC1rZXktdjEAAAAABG5vbmUAAAAEbm9uZQAAAAAAAAABAAAAMwAAAAtzc2gtZW\nQyNTUxOQAAACCvYBMYLqeFDQN70YggSnQivfiHVSm6LL1xA6U646hlVgAAAJjTsP1107D9\ndQAAAAtzc2gtZWQyNTUxOQAAACCvYBMYLqeFDQN70YggSnQivfiHVSm6LL1xA6U646hlVg\nAAAEDyK1objn0FHhfvALav18559QQ/3wxDxl/T4B3x5E+w2K9gExgup4UNA3vRiCBKdCK9\n+IdVKbosvXEDpTrjqGVWAAAAEHNoYXJlZC1hZG1pbi1rZXkBAgMEBQ==\n-----END OPENSSH PRIVATE KEY-----
20	port	22
20	username	kali
21	hostname	172.20.0.150
21	password	password
21	port	5901
21	username	kali1
22	hostname	172.20.0.150
22	password	password
22	port	5902
22	username	kali2
23	hostname	172.20.0.150
23	password	password
23	port	5903
23	username	kali3
24	hostname	172.20.0.150
24	password	password
24	port	5904
24	username	kali4
\.


--
-- Data for Name: guacamole_connection_permission; Type: TABLE DATA; Schema: public; Owner: guacamole_user
--

COPY public.guacamole_connection_permission (entity_id, connection_id, permission) FROM stdin;
1	1	READ
1	1	UPDATE
1	1	DELETE
1	1	ADMINISTER
1	2	READ
1	2	UPDATE
1	2	DELETE
1	2	ADMINISTER
1	4	READ
1	4	UPDATE
1	4	DELETE
1	4	ADMINISTER
1	5	READ
1	5	UPDATE
1	5	DELETE
1	5	ADMINISTER
1	6	READ
1	6	UPDATE
1	6	DELETE
1	6	ADMINISTER
1	7	READ
1	7	UPDATE
1	7	DELETE
1	7	ADMINISTER
1	8	READ
1	8	UPDATE
1	8	DELETE
1	8	ADMINISTER
1	9	READ
1	9	UPDATE
1	9	DELETE
1	9	ADMINISTER
1	10	READ
1	10	UPDATE
1	10	DELETE
1	10	ADMINISTER
1	11	READ
1	11	UPDATE
1	11	DELETE
1	11	ADMINISTER
1	12	READ
1	12	UPDATE
1	12	DELETE
1	12	ADMINISTER
1	13	READ
1	13	UPDATE
1	13	DELETE
1	13	ADMINISTER
1	14	READ
1	14	UPDATE
1	14	DELETE
1	14	ADMINISTER
1	15	READ
1	15	UPDATE
1	15	DELETE
1	15	ADMINISTER
1	16	READ
1	16	UPDATE
1	16	DELETE
1	16	ADMINISTER
1	17	READ
1	17	UPDATE
1	17	DELETE
1	17	ADMINISTER
1	18	READ
1	18	UPDATE
1	18	DELETE
1	18	ADMINISTER
1	19	READ
1	19	UPDATE
1	19	DELETE
1	19	ADMINISTER
1	20	READ
1	20	UPDATE
1	20	DELETE
1	20	ADMINISTER
1	21	READ
1	21	UPDATE
1	21	DELETE
1	21	ADMINISTER
1	22	READ
1	22	UPDATE
1	22	DELETE
1	22	ADMINISTER
1	23	READ
1	23	UPDATE
1	23	DELETE
1	23	ADMINISTER
1	24	READ
1	24	UPDATE
1	24	DELETE
1	24	ADMINISTER
\.


--
-- Data for Name: guacamole_entity; Type: TABLE DATA; Schema: public; Owner: guacamole_user
--

COPY public.guacamole_entity (entity_id, name, type) FROM stdin;
1	guacadmin	USER
\.


--
-- Data for Name: guacamole_sharing_profile; Type: TABLE DATA; Schema: public; Owner: guacamole_user
--

COPY public.guacamole_sharing_profile (sharing_profile_id, sharing_profile_name, primary_connection_id) FROM stdin;
\.


--
-- Data for Name: guacamole_sharing_profile_attribute; Type: TABLE DATA; Schema: public; Owner: guacamole_user
--

COPY public.guacamole_sharing_profile_attribute (sharing_profile_id, attribute_name, attribute_value) FROM stdin;
\.


--
-- Data for Name: guacamole_sharing_profile_parameter; Type: TABLE DATA; Schema: public; Owner: guacamole_user
--

COPY public.guacamole_sharing_profile_parameter (sharing_profile_id, parameter_name, parameter_value) FROM stdin;
\.


--
-- Data for Name: guacamole_sharing_profile_permission; Type: TABLE DATA; Schema: public; Owner: guacamole_user
--

COPY public.guacamole_sharing_profile_permission (entity_id, sharing_profile_id, permission) FROM stdin;
\.


--
-- Data for Name: guacamole_system_permission; Type: TABLE DATA; Schema: public; Owner: guacamole_user
--

COPY public.guacamole_system_permission (entity_id, permission) FROM stdin;
1	CREATE_CONNECTION
1	CREATE_CONNECTION_GROUP
1	CREATE_SHARING_PROFILE
1	CREATE_USER
1	CREATE_USER_GROUP
1	ADMINISTER
\.


--
-- Data for Name: guacamole_user; Type: TABLE DATA; Schema: public; Owner: guacamole_user
--

COPY public.guacamole_user (user_id, entity_id, password_hash, password_salt, password_date, disabled, expired, access_window_start, access_window_end, valid_from, valid_until, timezone, full_name, email_address, organization, organizational_role) FROM stdin;
1	1	\\xca458a7d494e3be824f5e1e175a1556c0f8eef2c2d7df3633bec4a29c4411960	\\xfe24adc5e11e2b25288d1704abe67a79e342ecc26064ce69c5b3177795a82264	2025-12-23 09:40:40.909986+00	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: guacamole_user_attribute; Type: TABLE DATA; Schema: public; Owner: guacamole_user
--

COPY public.guacamole_user_attribute (user_id, attribute_name, attribute_value) FROM stdin;
\.


--
-- Data for Name: guacamole_user_group; Type: TABLE DATA; Schema: public; Owner: guacamole_user
--

COPY public.guacamole_user_group (user_group_id, entity_id, disabled) FROM stdin;
\.


--
-- Data for Name: guacamole_user_group_attribute; Type: TABLE DATA; Schema: public; Owner: guacamole_user
--

COPY public.guacamole_user_group_attribute (user_group_id, attribute_name, attribute_value) FROM stdin;
\.


--
-- Data for Name: guacamole_user_group_member; Type: TABLE DATA; Schema: public; Owner: guacamole_user
--

COPY public.guacamole_user_group_member (user_group_id, member_entity_id) FROM stdin;
\.


--
-- Data for Name: guacamole_user_group_permission; Type: TABLE DATA; Schema: public; Owner: guacamole_user
--

COPY public.guacamole_user_group_permission (entity_id, affected_user_group_id, permission) FROM stdin;
\.


--
-- Data for Name: guacamole_user_history; Type: TABLE DATA; Schema: public; Owner: guacamole_user
--

COPY public.guacamole_user_history (history_id, user_id, username, remote_host, start_date, end_date) FROM stdin;
1	1	guacadmin	10.10.100.1	2025-12-23 09:42:42.644+00	\N
2	1	guacadmin	10.10.100.1	2025-12-23 09:42:42.719+00	2025-12-23 09:42:48.208+00
3	1	guacadmin	10.10.100.1	2025-12-23 09:42:55.805+00	\N
4	1	guacadmin	10.10.100.1	2025-12-23 09:42:55.846+00	\N
5	1	guacadmin	10.10.100.1	2025-12-23 09:43:00.175+00	\N
6	1	guacadmin	10.10.100.1	2025-12-23 09:43:05.269+00	\N
7	1	guacadmin	10.10.100.1	2025-12-23 09:53:06.255+00	\N
8	1	guacadmin	10.10.100.1	2025-12-23 09:54:29.854+00	\N
9	1	guacadmin	10.10.100.1	2025-12-23 09:54:33.077+00	\N
10	1	guacadmin	10.10.100.1	2025-12-23 09:54:36.476+00	\N
11	1	guacadmin	10.10.100.1	2025-12-23 09:54:37.799+00	\N
12	1	guacadmin	10.10.100.1	2025-12-23 09:54:38.102+00	\N
13	1	guacadmin	10.10.100.1	2025-12-23 09:54:38.138+00	\N
14	1	guacadmin	10.10.100.1	2025-12-23 09:54:40.046+00	\N
15	1	guacadmin	10.10.100.1	2025-12-23 09:54:41.591+00	\N
16	1	guacadmin	10.10.100.1	2025-12-23 09:54:44.967+00	\N
17	1	guacadmin	10.10.100.1	2025-12-23 09:56:48.434+00	\N
18	1	guacadmin	10.10.100.1	2025-12-23 09:56:49.395+00	\N
19	1	guacadmin	10.10.100.1	2025-12-23 09:56:56.957+00	\N
20	1	guacadmin	10.10.100.1	2025-12-23 09:56:58.039+00	\N
21	1	guacadmin	10.10.100.1	2025-12-23 09:56:58.892+00	\N
22	1	guacadmin	10.10.100.1	2025-12-23 09:57:00.106+00	\N
23	1	guacadmin	10.10.100.1	2025-12-23 09:57:01.4+00	\N
24	1	guacadmin	10.10.100.1	2025-12-23 09:57:01.925+00	\N
25	1	guacadmin	10.10.100.1	2025-12-23 09:57:02.844+00	\N
26	1	guacadmin	10.10.100.1	2025-12-23 09:58:22.936+00	\N
27	1	guacadmin	10.10.100.1	2025-12-23 09:58:26.452+00	\N
28	1	guacadmin	10.10.100.1	2025-12-23 09:58:27.893+00	\N
29	1	guacadmin	10.10.100.1	2025-12-23 09:58:28.413+00	\N
30	1	guacadmin	10.10.100.1	2025-12-23 09:58:29.954+00	\N
31	1	guacadmin	10.10.100.1	2025-12-23 09:58:31.819+00	2025-12-23 09:58:33.432+00
32	1	guacadmin	10.10.100.1	2025-12-23 09:58:40.92+00	\N
33	1	guacadmin	10.10.100.1	2025-12-23 09:58:40.955+00	\N
34	1	guacadmin	10.10.100.1	2025-12-23 09:58:55.262+00	\N
35	1	guacadmin	10.10.100.1	2025-12-23 10:03:06.402+00	\N
36	1	guacadmin	10.10.100.1	2025-12-23 10:03:07.586+00	\N
37	1	guacadmin	10.10.100.1	2025-12-23 10:03:07.848+00	\N
38	1	guacadmin	10.10.100.1	2025-12-23 10:03:10.222+00	\N
39	1	guacadmin	10.10.100.1	2025-12-23 10:03:10.743+00	\N
40	1	guacadmin	10.10.100.1	2025-12-23 10:07:31.028+00	\N
41	1	guacadmin	10.10.100.1	2025-12-23 10:07:31.319+00	\N
42	1	guacadmin	10.10.100.1	2025-12-23 10:07:33.18+00	\N
43	1	guacadmin	10.10.100.1	2025-12-23 10:07:34.468+00	\N
44	1	guacadmin	10.10.100.1	2025-12-23 10:08:35.672+00	\N
45	1	guacadmin	10.10.100.1	2025-12-23 10:08:38.017+00	\N
46	1	guacadmin	10.10.100.1	2025-12-23 10:08:39.023+00	\N
47	1	guacadmin	10.10.100.1	2025-12-23 10:08:53.248+00	\N
48	1	guacadmin	10.10.100.1	2025-12-23 10:08:57.745+00	\N
49	1	guacadmin	10.10.100.1	2025-12-23 10:08:58.868+00	\N
50	1	guacadmin	10.10.100.1	2025-12-23 10:12:00.27+00	\N
51	1	guacadmin	10.10.100.1	2025-12-23 10:12:03.523+00	\N
52	1	guacadmin	10.10.100.1	2025-12-23 10:12:04.77+00	\N
53	1	guacadmin	10.10.100.1	2025-12-23 10:12:08.184+00	\N
54	1	guacadmin	10.10.100.1	2025-12-23 10:13:59.365+00	\N
55	1	guacadmin	10.10.100.1	2025-12-23 10:14:01.373+00	\N
56	1	guacadmin	10.10.100.1	2025-12-23 10:14:04.605+00	\N
57	1	guacadmin	10.10.100.1	2025-12-23 10:14:06.968+00	\N
58	1	guacadmin	10.10.100.1	2025-12-23 10:14:48.799+00	\N
59	1	guacadmin	10.10.100.1	2025-12-23 10:14:51.35+00	\N
60	1	guacadmin	10.10.100.1	2025-12-23 10:14:52.495+00	\N
61	1	guacadmin	10.10.100.1	2025-12-23 10:14:57.051+00	\N
62	1	guacadmin	10.10.100.1	2025-12-23 10:15:01.69+00	\N
63	1	guacadmin	10.10.100.1	2025-12-23 10:15:03.16+00	\N
64	1	guacadmin	10.10.100.1	2025-12-23 10:15:04.604+00	\N
65	1	guacadmin	10.10.100.1	2025-12-23 10:15:07.271+00	\N
66	1	guacadmin	10.10.100.1	2025-12-23 10:15:42.561+00	\N
67	1	guacadmin	10.10.100.1	2025-12-23 10:15:45.368+00	\N
68	1	guacadmin	10.10.100.1	2025-12-23 10:15:46.703+00	\N
69	1	guacadmin	10.10.100.1	2025-12-23 10:15:46.849+00	\N
70	1	guacadmin	10.10.100.1	2025-12-23 10:15:48.158+00	\N
71	1	guacadmin	10.10.100.1	2025-12-23 10:15:48.633+00	\N
72	1	guacadmin	10.10.100.1	2025-12-23 10:15:51.428+00	\N
73	1	guacadmin	10.10.100.1	2025-12-23 10:15:54.351+00	\N
74	1	guacadmin	10.10.100.1	2025-12-23 10:55:48.878+00	\N
75	1	guacadmin	10.10.100.1	2025-12-23 11:57:05.714+00	\N
76	1	guacadmin	10.10.100.1	2025-12-23 11:57:05.874+00	\N
77	1	guacadmin	10.10.100.1	2025-12-23 11:57:07.992+00	\N
78	1	guacadmin	10.10.100.1	2025-12-23 11:57:21.684+00	\N
79	1	guacadmin	10.10.100.1	2025-12-23 11:57:22.433+00	\N
80	1	guacadmin	10.10.100.1	2025-12-23 11:57:23.846+00	\N
81	1	guacadmin	10.10.100.1	2025-12-23 11:57:30.489+00	\N
82	1	guacadmin	10.10.100.1	2025-12-23 11:57:31.582+00	\N
83	1	guacadmin	10.10.100.1	2025-12-23 12:24:47.98+00	\N
84	1	guacadmin	10.10.100.1	2025-12-23 12:24:49.665+00	\N
85	1	guacadmin	10.10.100.1	2025-12-23 12:24:51.61+00	\N
86	1	guacadmin	10.10.100.1	2025-12-23 12:24:55.059+00	\N
87	1	guacadmin	10.10.100.1	2025-12-23 12:25:10.28+00	\N
88	1	guacadmin	10.10.100.1	2025-12-23 12:25:14.027+00	\N
89	1	guacadmin	10.10.100.1	2025-12-23 12:26:57.729+00	\N
90	1	guacadmin	10.10.100.1	2025-12-23 12:26:59.369+00	\N
91	1	guacadmin	10.10.100.1	2025-12-23 12:27:01.833+00	\N
92	1	guacadmin	10.10.100.1	2025-12-23 12:27:03.045+00	\N
93	1	guacadmin	10.10.100.1	2025-12-23 12:30:32.836+00	\N
94	1	guacadmin	10.10.100.1	2025-12-23 12:30:34.071+00	\N
95	1	guacadmin	10.10.100.1	2025-12-23 12:30:36.419+00	\N
96	1	guacadmin	10.10.100.1	2025-12-23 12:30:38.096+00	\N
97	1	guacadmin	10.10.100.1	2025-12-23 12:30:39.634+00	\N
98	1	guacadmin	10.10.100.1	2025-12-23 12:30:42.274+00	\N
99	1	guacadmin	10.10.100.1	2025-12-23 12:30:55.406+00	\N
100	1	guacadmin	10.10.100.1	2025-12-23 12:31:05.035+00	\N
101	1	guacadmin	10.10.100.1	2025-12-23 12:31:08.332+00	\N
102	1	guacadmin	10.10.100.1	2025-12-23 12:35:29.119+00	\N
103	1	guacadmin	10.10.100.1	2025-12-23 12:35:30.338+00	\N
104	1	guacadmin	10.10.100.1	2025-12-23 12:36:38.187+00	\N
105	1	guacadmin	10.10.100.1	2025-12-23 12:36:39.029+00	\N
106	1	guacadmin	10.10.100.1	2025-12-23 12:36:41.305+00	\N
107	1	guacadmin	10.10.100.1	2025-12-23 12:36:42.83+00	\N
108	1	guacadmin	10.10.100.1	2025-12-23 12:36:43.784+00	\N
109	1	guacadmin	10.10.100.1	2025-12-23 12:37:43.642+00	\N
110	1	guacadmin	10.10.100.1	2025-12-23 12:37:45.084+00	\N
111	1	guacadmin	10.10.100.1	2025-12-23 12:41:29.859+00	\N
112	1	guacadmin	10.10.100.1	2025-12-23 12:44:08.405+00	\N
113	1	guacadmin	10.10.100.1	2025-12-23 12:48:12.946+00	\N
114	1	guacadmin	10.10.100.1	2025-12-23 12:48:29.362+00	\N
115	1	guacadmin	10.10.100.1	2025-12-23 12:52:37.62+00	\N
116	1	guacadmin	10.10.100.1	2025-12-23 13:02:50.591+00	\N
117	1	guacadmin	10.10.100.1	2025-12-23 13:09:51.224+00	2025-12-23 14:10:13.143+00
118	1	guacadmin	10.10.100.1	2025-12-23 19:01:23.996+00	\N
119	1	guacadmin	10.10.100.1	2025-12-23 19:01:25.8+00	\N
120	1	guacadmin	10.10.100.1	2025-12-23 19:01:27.197+00	\N
122	1	guacadmin	10.10.100.1	2025-12-23 19:28:53.383+00	\N
125	1	guacadmin	10.10.100.1	2025-12-23 19:37:50.433+00	\N
128	1	guacadmin	10.10.100.1	2025-12-23 19:38:06.571+00	\N
131	1	guacadmin	10.10.100.1	2025-12-23 19:46:46.333+00	\N
121	1	guacadmin	10.10.100.1	2025-12-23 19:01:37.401+00	\N
124	1	guacadmin	10.10.100.1	2025-12-23 19:34:14.881+00	\N
129	1	guacadmin	10.10.100.1	2025-12-23 19:38:08.041+00	\N
132	1	guacadmin	10.10.100.1	2025-12-23 19:46:47.186+00	\N
123	1	guacadmin	10.10.100.1	2025-12-23 19:34:12.719+00	\N
127	1	guacadmin	10.10.100.1	2025-12-23 19:37:54.791+00	\N
134	1	guacadmin	10.10.100.1	2025-12-23 19:46:52.409+00	\N
126	1	guacadmin	10.10.100.1	2025-12-23 19:37:52.324+00	\N
130	1	guacadmin	10.10.100.1	2025-12-23 19:38:09.858+00	\N
133	1	guacadmin	10.10.100.1	2025-12-23 19:46:50.563+00	\N
135	1	guacadmin	10.10.100.1	2025-12-23 19:46:55.884+00	\N
136	1	guacadmin	10.10.100.1	2025-12-23 19:47:39.353+00	\N
137	1	guacadmin	10.10.100.1	2025-12-23 19:47:45.618+00	\N
138	1	guacadmin	10.10.100.1	2025-12-23 19:47:47.221+00	\N
139	1	guacadmin	10.10.100.1	2025-12-23 19:49:11.204+00	\N
140	1	guacadmin	10.10.100.1	2025-12-23 19:49:12.496+00	\N
141	1	guacadmin	172.18.0.5	2026-01-07 09:52:44.995+00	\N
142	1	guacadmin	172.18.0.5	2026-01-07 09:52:45.059+00	2026-01-07 10:03:15.499+00
143	1	guacadmin	172.18.0.5	2026-01-07 10:04:49.55+00	\N
144	1	guacadmin	172.18.0.5	2026-01-07 10:04:49.612+00	2026-01-07 11:08:25.806+00
145	1	guacadmin	172.18.0.5	2026-01-08 07:39:48.113+00	\N
146	1	guacadmin	172.18.0.5	2026-01-08 07:39:48.149+00	\N
147	1	guacadmin	172.18.0.5	2026-01-08 07:39:54.707+00	2026-01-08 07:50:59.679+00
148	1	guacadmin	172.18.0.5	2026-01-08 09:01:28.929+00	\N
149	1	guacadmin	172.18.0.5	2026-01-08 09:01:28.996+00	\N
150	1	guacadmin	172.18.0.5	2026-01-08 09:10:33.159+00	\N
151	1	guacadmin	172.18.0.5	2026-01-08 09:10:34.8+00	\N
152	1	guacadmin	172.18.0.5	2026-01-08 09:10:35.929+00	\N
153	1	guacadmin	172.18.0.5	2026-01-08 09:11:05.443+00	\N
154	1	guacadmin	172.18.0.5	2026-01-08 09:11:10.4+00	\N
155	1	guacadmin	172.18.0.5	2026-01-08 09:11:11.635+00	\N
156	1	guacadmin	172.18.0.5	2026-01-08 09:38:27.445+00	\N
157	1	guacadmin	172.18.0.5	2026-01-08 09:38:33.289+00	\N
158	1	guacadmin	172.18.0.5	2026-01-08 09:38:34.592+00	\N
159	1	guacadmin	172.18.0.5	2026-01-08 09:38:37.794+00	\N
160	1	guacadmin	172.18.0.5	2026-01-08 09:38:50.225+00	\N
161	1	guacadmin	172.18.0.5	2026-01-08 09:38:56.648+00	\N
162	1	guacadmin	172.18.0.5	2026-01-08 09:38:57.732+00	\N
163	1	guacadmin	172.18.0.5	2026-01-08 09:38:59.424+00	\N
164	1	guacadmin	172.18.0.5	2026-01-08 09:39:20.389+00	\N
165	1	guacadmin	172.18.0.5	2026-01-08 09:39:24.17+00	\N
166	1	guacadmin	172.18.0.5	2026-01-08 09:39:25.141+00	\N
167	1	guacadmin	172.18.0.5	2026-01-08 09:39:26.813+00	\N
168	1	guacadmin	172.18.0.5	2026-01-08 09:39:36.326+00	\N
169	1	guacadmin	172.18.0.5	2026-01-08 09:39:38.35+00	\N
170	1	guacadmin	172.18.0.5	2026-01-08 09:40:08.984+00	\N
171	1	guacadmin	172.18.0.5	2026-01-08 09:40:13.131+00	\N
172	1	guacadmin	172.18.0.5	2026-01-14 11:18:56.853+00	\N
173	1	guacadmin	172.18.0.5	2026-01-14 11:18:56.92+00	\N
174	1	guacadmin	172.18.0.5	2026-01-14 11:20:34.718+00	\N
175	1	guacadmin	172.18.0.5	2026-01-14 11:21:32.682+00	\N
176	1	guacadmin	172.18.0.5	2026-01-14 11:27:26.681+00	\N
177	1	guacadmin	172.18.0.5	2026-01-14 11:30:20.627+00	\N
178	1	guacadmin	172.18.0.5	2026-01-14 11:43:33.071+00	\N
179	1	guacadmin	172.18.0.5	2026-01-14 11:57:44.446+00	\N
180	1	guacadmin	172.18.0.5	2026-01-14 12:18:58.86+00	\N
181	1	guacadmin	172.18.0.5	2026-01-14 13:17:49.243+00	\N
182	1	guacadmin	172.18.0.5	2026-01-14 13:17:59.554+00	\N
183	1	guacadmin	172.18.0.5	2026-01-14 13:25:22.023+00	\N
184	1	guacadmin	172.18.0.5	2026-01-14 13:38:24.939+00	\N
185	1	guacadmin	172.18.0.5	2026-01-14 13:51:08.476+00	\N
186	1	guacadmin	172.18.0.5	2026-01-14 13:53:02.883+00	\N
188	1	guacadmin	172.18.0.5	2026-01-14 14:53:36.57+00	\N
189	1	guacadmin	172.18.0.5	2026-01-14 14:53:36.614+00	\N
190	1	guacadmin	172.18.0.5	2026-01-14 15:09:24.25+00	\N
191	1	guacadmin	172.18.0.5	2026-01-14 15:09:56.127+00	\N
187	1	guacadmin	172.18.0.5	2026-01-14 14:27:54.329+00	2026-01-14 15:31:15.816+00
192	1	guacadmin	172.18.0.5	2026-01-14 15:27:09.554+00	2026-01-14 16:30:15.808+00
193	1	guacadmin	172.18.0.5	2026-01-15 07:13:56.502+00	\N
194	1	guacadmin	172.18.0.5	2026-01-15 07:13:56.598+00	\N
195	1	guacadmin	172.18.0.5	2026-01-15 07:14:51.962+00	\N
196	1	guacadmin	172.18.0.5	2026-01-15 07:16:45.141+00	\N
197	1	guacadmin	172.18.0.5	2026-01-15 07:34:04.398+00	\N
198	1	guacadmin	172.18.0.5	2026-01-15 07:37:04.727+00	\N
199	1	guacadmin	172.18.0.5	2026-01-15 08:19:37.343+00	\N
200	1	guacadmin	172.18.0.5	2026-01-15 08:27:07.963+00	\N
201	1	guacadmin	172.18.0.5	2026-01-15 08:31:17.855+00	\N
202	1	guacadmin	172.18.0.5	2026-01-15 08:38:50.16+00	\N
203	1	guacadmin	172.18.0.5	2026-01-15 08:38:50.449+00	\N
204	1	guacadmin	172.18.0.5	2026-01-15 08:38:51.757+00	\N
205	1	guacadmin	172.18.0.5	2026-01-15 08:39:03.771+00	\N
206	1	guacadmin	172.18.0.5	2026-01-15 08:39:04.017+00	\N
207	1	guacadmin	172.18.0.5	2026-01-15 08:43:51.706+00	\N
208	1	guacadmin	172.18.0.5	2026-01-15 08:49:33.011+00	\N
209	1	guacadmin	172.18.0.5	2026-01-15 08:51:27.131+00	\N
210	1	guacadmin	172.18.0.5	2026-01-15 09:42:41.798+00	\N
211	1	guacadmin	172.18.0.5	2026-01-15 09:44:44.665+00	\N
212	1	guacadmin	172.18.0.5	2026-01-15 09:59:51.394+00	\N
213	1	guacadmin	172.18.0.5	2026-01-15 10:40:26.02+00	\N
214	1	guacadmin	172.18.0.5	2026-01-15 10:40:26.02+00	\N
215	1	guacadmin	172.18.0.5	2026-01-15 10:40:26.03+00	\N
216	1	guacadmin	172.18.0.5	2026-01-15 10:40:26.03+00	\N
217	1	guacadmin	172.18.0.5	2026-01-15 11:01:12.72+00	\N
218	1	guacadmin	172.18.0.5	2026-01-15 11:01:13.085+00	\N
219	1	guacadmin	172.18.0.5	2026-01-15 11:01:14.618+00	\N
220	1	guacadmin	172.18.0.5	2026-01-15 11:01:28.783+00	\N
221	1	guacadmin	172.18.0.5	2026-01-15 11:06:44.868+00	\N
222	1	guacadmin	172.18.0.5	2026-01-15 11:15:56.366+00	\N
223	1	guacadmin	172.18.0.5	2026-01-15 11:15:56.366+00	\N
224	1	guacadmin	172.18.0.5	2026-01-15 11:27:00.144+00	\N
225	1	guacadmin	172.18.0.5	2026-01-15 11:32:14.223+00	\N
226	1	guacadmin	172.18.0.5	2026-01-15 11:34:30.039+00	2026-01-15 12:40:15.809+00
227	1	guacadmin	172.18.0.5	2026-01-16 05:59:05.471+00	\N
228	1	guacadmin	172.18.0.5	2026-01-16 05:59:05.496+00	\N
229	1	guacadmin	172.18.0.5	2026-01-16 06:13:13.297+00	\N
230	1	guacadmin	172.18.0.5	2026-01-16 06:53:20.377+00	\N
231	1	guacadmin	172.18.0.5	2026-01-16 06:59:39.661+00	\N
232	1	guacadmin	172.18.0.5	2026-01-16 08:35:14.928+00	2026-01-16 14:23:15.808+00
233	1	guacadmin	172.18.0.5	2026-01-16 15:44:28.459+00	\N
234	1	guacadmin	172.18.0.5	2026-01-16 15:44:28.488+00	\N
235	1	guacadmin	172.18.0.5	2026-01-16 16:23:28.643+00	\N
236	1	guacadmin	172.18.0.5	2026-01-16 17:07:43.958+00	\N
237	1	guacadmin	172.18.0.5	2026-01-16 17:10:29.136+00	\N
238	1	guacadmin	172.18.0.5	2026-01-16 17:15:08.95+00	\N
239	1	guacadmin	172.18.0.5	2026-01-16 17:15:09.025+00	\N
240	1	guacadmin	172.18.0.5	2026-01-16 17:15:09.079+00	\N
241	1	guacadmin	172.18.0.5	2026-01-16 17:23:44.923+00	\N
242	1	guacadmin	172.18.0.5	2026-01-16 17:23:44.926+00	\N
243	1	guacadmin	172.18.0.5	2026-01-16 17:24:15.376+00	\N
247	1	guacadmin	172.18.0.5	2026-01-16 17:25:23.122+00	\N
249	1	guacadmin	172.18.0.5	2026-01-16 20:08:29.087+00	\N
253	1	guacadmin	172.18.0.5	2026-01-16 20:13:10.45+00	\N
255	1	guacadmin	172.18.0.5	2026-01-16 20:14:20.21+00	\N
256	1	guacadmin	172.18.0.5	2026-01-16 20:14:54.532+00	\N
257	1	guacadmin	172.18.0.5	2026-01-16 20:37:04.226+00	2026-01-16 22:05:15.808+00
259	1	guacadmin	172.18.0.5	2026-01-18 19:59:44.233+00	\N
260	1	guacadmin	172.18.0.5	2026-01-18 19:59:51.343+00	\N
262	1	guacadmin	172.18.0.5	2026-01-18 20:00:02.11+00	\N
264	1	guacadmin	172.18.0.5	2026-01-18 20:00:25.476+00	\N
266	1	guacadmin	172.18.0.5	2026-01-18 20:00:28.031+00	\N
268	1	guacadmin	172.18.0.5	2026-01-18 20:00:57.121+00	\N
271	1	guacadmin	172.18.0.5	2026-01-18 20:01:16.948+00	\N
275	1	guacadmin	172.18.0.5	2026-01-18 20:02:19.04+00	\N
280	1	guacadmin	172.18.0.5	2026-01-18 20:02:36.226+00	\N
282	1	guacadmin	172.18.0.5	2026-01-18 20:06:25.224+00	\N
284	1	guacadmin	172.18.0.5	2026-01-18 20:06:27.005+00	\N
285	1	guacadmin	172.18.0.5	2026-01-18 20:06:56.213+00	\N
288	1	guacadmin	172.18.0.5	2026-01-18 20:07:00.232+00	\N
289	1	guacadmin	172.18.0.5	2026-01-18 20:07:02.184+00	\N
293	1	guacadmin	172.18.0.5	2026-01-18 20:10:31.594+00	\N
296	1	guacadmin	172.18.0.5	2026-01-18 20:10:35.057+00	\N
297	1	guacadmin	172.18.0.5	2026-01-18 20:10:36.78+00	\N
300	1	guacadmin	172.18.0.5	2026-01-18 20:11:02.215+00	\N
301	1	guacadmin	172.18.0.5	2026-01-18 20:11:03.588+00	\N
303	1	guacadmin	172.18.0.5	2026-01-18 20:11:06.858+00	\N
305	1	guacadmin	172.18.0.5	2026-01-18 20:11:09.999+00	\N
307	1	guacadmin	172.18.0.5	2026-01-18 20:11:11.754+00	\N
308	1	guacadmin	172.18.0.5	2026-01-18 20:11:13.697+00	\N
311	1	guacadmin	172.18.0.5	2026-01-18 20:11:18.732+00	\N
314	1	guacadmin	172.18.0.5	2026-01-18 20:11:37.564+00	\N
315	1	guacadmin	172.18.0.5	2026-01-18 20:11:38.775+00	\N
244	1	guacadmin	172.18.0.5	2026-01-16 17:24:15.77+00	\N
246	1	guacadmin	172.18.0.5	2026-01-16 17:25:06.48+00	\N
248	1	guacadmin	172.18.0.5	2026-01-16 17:30:57.185+00	2026-01-16 18:43:15.808+00
250	1	guacadmin	172.18.0.5	2026-01-16 20:08:29.126+00	\N
251	1	guacadmin	172.18.0.5	2026-01-16 20:08:30.601+00	\N
254	1	guacadmin	172.18.0.5	2026-01-16 20:13:10.477+00	\N
263	1	guacadmin	172.18.0.5	2026-01-18 20:00:21.953+00	\N
267	1	guacadmin	172.18.0.5	2026-01-18 20:00:55.176+00	\N
272	1	guacadmin	172.18.0.5	2026-01-18 20:01:20.465+00	\N
273	1	guacadmin	172.18.0.5	2026-01-18 20:01:38.142+00	\N
274	1	guacadmin	172.18.0.5	2026-01-18 20:01:41.515+00	\N
277	1	guacadmin	172.18.0.5	2026-01-18 20:02:24.419+00	\N
279	1	guacadmin	172.18.0.5	2026-01-18 20:02:33.893+00	\N
283	1	guacadmin	172.18.0.5	2026-01-18 20:06:26.428+00	\N
286	1	guacadmin	172.18.0.5	2026-01-18 20:06:56.242+00	\N
290	1	guacadmin	172.18.0.5	2026-01-18 20:07:32.095+00	\N
291	1	guacadmin	172.18.0.5	2026-01-18 20:07:41.97+00	\N
292	1	guacadmin	172.18.0.5	2026-01-18 20:10:30.152+00	\N
294	1	guacadmin	172.18.0.5	2026-01-18 20:10:32.124+00	\N
298	1	guacadmin	172.18.0.5	2026-01-18 20:10:39.425+00	\N
309	1	guacadmin	172.18.0.5	2026-01-18 20:11:16.169+00	\N
312	1	guacadmin	172.18.0.5	2026-01-18 20:11:23.529+00	\N
316	1	guacadmin	172.18.0.5	2026-01-18 20:11:40.443+00	\N
245	1	guacadmin	172.18.0.5	2026-01-16 17:24:17.812+00	\N
252	1	guacadmin	172.18.0.5	2026-01-16 20:12:58.624+00	2026-01-16 21:13:15.808+00
258	1	guacadmin	172.18.0.5	2026-01-18 19:59:44.2+00	\N
261	1	guacadmin	172.18.0.5	2026-01-18 19:59:52.547+00	\N
265	1	guacadmin	172.18.0.5	2026-01-18 20:00:26.706+00	\N
269	1	guacadmin	172.18.0.5	2026-01-18 20:00:59.5+00	\N
270	1	guacadmin	172.18.0.5	2026-01-18 20:01:13.092+00	\N
276	1	guacadmin	172.18.0.5	2026-01-18 20:02:21.705+00	\N
278	1	guacadmin	172.18.0.5	2026-01-18 20:02:33.853+00	\N
281	1	guacadmin	172.18.0.5	2026-01-18 20:02:36.316+00	\N
287	1	guacadmin	172.18.0.5	2026-01-18 20:06:58.887+00	\N
295	1	guacadmin	172.18.0.5	2026-01-18 20:10:32.616+00	\N
299	1	guacadmin	172.18.0.5	2026-01-18 20:10:55.065+00	\N
302	1	guacadmin	172.18.0.5	2026-01-18 20:11:04.681+00	\N
304	1	guacadmin	172.18.0.5	2026-01-18 20:11:09.8+00	\N
306	1	guacadmin	172.18.0.5	2026-01-18 20:11:11.396+00	\N
310	1	guacadmin	172.18.0.5	2026-01-18 20:11:17.289+00	\N
313	1	guacadmin	172.18.0.5	2026-01-18 20:11:35.517+00	\N
317	1	guacadmin	172.18.0.5	2026-01-18 20:11:50.944+00	\N
318	1	guacadmin	172.18.0.5	2026-01-18 20:11:55.326+00	\N
319	1	guacadmin	172.18.0.5	2026-01-18 20:11:56.788+00	\N
320	1	guacadmin	172.18.0.5	2026-01-18 20:12:02.452+00	\N
321	1	guacadmin	172.18.0.5	2026-01-18 20:12:03.582+00	\N
322	1	guacadmin	172.18.0.5	2026-01-18 20:12:04.215+00	\N
323	1	guacadmin	172.18.0.5	2026-01-18 20:12:04.44+00	\N
324	1	guacadmin	172.18.0.5	2026-01-18 20:12:04.723+00	\N
325	1	guacadmin	172.18.0.5	2026-01-18 20:12:05.488+00	\N
326	1	guacadmin	172.18.0.5	2026-01-18 20:12:05.887+00	\N
327	1	guacadmin	172.18.0.5	2026-01-18 20:12:06.265+00	\N
328	1	guacadmin	172.18.0.5	2026-01-18 20:12:06.731+00	\N
329	1	guacadmin	172.18.0.5	2026-01-18 20:12:08.352+00	\N
330	1	guacadmin	172.18.0.5	2026-01-18 20:23:14.961+00	\N
331	1	guacadmin	172.18.0.5	2026-01-18 20:29:05.594+00	\N
332	1	guacadmin	172.18.0.5	2026-01-18 20:29:22.473+00	\N
333	1	guacadmin	172.18.0.5	2026-01-18 20:29:25.057+00	\N
334	1	guacadmin	172.18.0.5	2026-01-18 20:29:27.471+00	\N
335	1	guacadmin	172.18.0.5	2026-01-18 20:29:36.853+00	\N
336	1	guacadmin	172.18.0.5	2026-01-18 20:29:39.257+00	\N
337	1	guacadmin	172.18.0.5	2026-01-18 20:29:40.666+00	\N
338	1	guacadmin	172.18.0.5	2026-01-18 20:29:41.821+00	\N
339	1	guacadmin	172.18.0.5	2026-01-18 20:29:44.779+00	\N
340	1	guacadmin	172.18.0.5	2026-01-18 20:29:47.58+00	\N
341	1	guacadmin	172.18.0.5	2026-01-18 20:29:47.679+00	\N
342	1	guacadmin	172.18.0.5	2026-01-18 20:29:48.894+00	2026-01-18 21:32:15.808+00
343	1	guacadmin	172.18.0.5	2026-01-20 07:15:54.316+00	\N
344	1	guacadmin	172.18.0.5	2026-01-20 07:15:54.337+00	\N
345	1	guacadmin	172.18.0.5	2026-01-20 07:15:57.022+00	\N
346	1	guacadmin	172.18.0.5	2026-01-20 07:17:24.471+00	\N
347	1	guacadmin	172.18.0.5	2026-01-20 07:17:28.665+00	\N
348	1	guacadmin	172.18.0.5	2026-01-20 07:17:30.319+00	\N
349	1	guacadmin	172.18.0.5	2026-01-20 07:17:33.59+00	\N
350	1	guacadmin	172.18.0.5	2026-01-20 07:17:44.872+00	\N
351	1	guacadmin	172.18.0.5	2026-01-20 07:17:47.179+00	\N
352	1	guacadmin	172.18.0.5	2026-01-20 07:17:48.263+00	\N
353	1	guacadmin	172.18.0.5	2026-01-20 07:17:50.693+00	\N
354	1	guacadmin	172.18.0.5	2026-01-20 07:17:50.928+00	\N
355	1	guacadmin	172.18.0.5	2026-01-20 07:17:52.342+00	\N
356	1	guacadmin	172.18.0.5	2026-01-20 07:18:07.519+00	\N
357	1	guacadmin	172.18.0.5	2026-01-20 07:18:21.309+00	\N
358	1	guacadmin	172.18.0.5	2026-01-20 07:18:22.996+00	\N
359	1	guacadmin	172.18.0.5	2026-01-20 07:18:23.95+00	\N
360	1	guacadmin	172.18.0.5	2026-01-20 07:18:28.369+00	\N
361	1	guacadmin	172.18.0.5	2026-01-20 07:18:32.571+00	\N
362	1	guacadmin	172.18.0.5	2026-01-20 07:18:34.631+00	\N
363	1	guacadmin	172.18.0.5	2026-01-20 07:18:34.814+00	\N
364	1	guacadmin	172.18.0.5	2026-01-20 07:18:35.928+00	\N
365	1	guacadmin	172.18.0.5	2026-01-20 07:18:51.104+00	\N
366	1	guacadmin	172.18.0.5	2026-01-20 07:19:06.281+00	\N
367	1	guacadmin	172.18.0.5	2026-01-20 07:19:21.454+00	\N
368	1	guacadmin	172.18.0.5	2026-01-20 07:19:36.64+00	\N
369	1	guacadmin	172.18.0.5	2026-01-20 07:19:51.821+00	\N
370	1	guacadmin	172.18.0.5	2026-01-20 07:20:14.403+00	\N
371	1	guacadmin	172.18.0.5	2026-01-20 07:20:17.181+00	\N
372	1	guacadmin	172.18.0.5	2026-01-20 07:20:19.078+00	\N
373	1	guacadmin	172.18.0.5	2026-01-20 07:20:30.313+00	\N
374	1	guacadmin	172.18.0.5	2026-01-20 07:20:47.584+00	\N
375	1	guacadmin	172.18.0.5	2026-01-20 07:20:49.863+00	\N
376	1	guacadmin	172.18.0.5	2026-01-20 07:20:55.203+00	\N
377	1	guacadmin	172.18.0.5	2026-01-20 07:20:56.965+00	\N
378	1	guacadmin	172.18.0.5	2026-01-20 07:21:06.737+00	\N
379	1	guacadmin	172.18.0.5	2026-01-20 07:21:11.421+00	\N
380	1	guacadmin	172.18.0.5	2026-01-20 07:21:27.444+00	\N
381	1	guacadmin	172.18.0.5	2026-01-20 07:21:43.567+00	\N
382	1	guacadmin	172.18.0.5	2026-01-20 07:21:58.901+00	\N
383	1	guacadmin	172.18.0.5	2026-01-20 07:39:42.355+00	\N
384	1	guacadmin	172.18.0.5	2026-01-20 08:09:08.859+00	\N
385	1	guacadmin	172.18.0.5	2026-01-20 08:43:52.292+00	\N
386	1	guacadmin	172.18.0.5	2026-01-20 08:43:55.672+00	\N
387	1	guacadmin	172.18.0.5	2026-01-20 09:44:55.449+00	\N
388	1	guacadmin	172.18.0.5	2026-01-20 09:45:14.92+00	\N
389	1	guacadmin	172.18.0.5	2026-01-20 09:45:21.582+00	\N
390	1	guacadmin	172.18.0.5	2026-01-20 09:45:24.366+00	\N
391	1	guacadmin	172.18.0.5	2026-01-20 09:45:32.391+00	\N
392	1	guacadmin	172.18.0.5	2026-01-20 09:45:38.919+00	\N
393	1	guacadmin	172.18.0.5	2026-01-20 09:46:00.817+00	\N
394	1	guacadmin	172.18.0.5	2026-01-20 09:46:25.903+00	2026-01-20 10:47:15.808+00
395	1	guacadmin	172.18.0.5	2026-01-20 12:30:43.392+00	\N
397	1	guacadmin	172.18.0.5	2026-01-20 12:33:52.167+00	\N
398	1	guacadmin	172.18.0.5	2026-01-20 12:33:52.196+00	\N
399	1	guacadmin	172.18.0.5	2026-01-20 14:02:08.634+00	\N
400	1	guacadmin	172.18.0.5	2026-01-20 14:02:24.735+00	\N
401	1	guacadmin	172.18.0.5	2026-01-20 14:02:40.723+00	\N
402	1	guacadmin	172.18.0.5	2026-01-20 14:02:56.744+00	\N
403	1	guacadmin	172.18.0.5	2026-01-20 14:02:56.759+00	\N
404	1	guacadmin	172.18.0.5	2026-01-20 14:03:00.586+00	\N
405	1	guacadmin	172.18.0.5	2026-01-20 14:03:03.108+00	\N
406	1	guacadmin	172.18.0.5	2026-01-20 14:04:39.821+00	\N
407	1	guacadmin	172.18.0.5	2026-01-20 14:05:34.662+00	\N
408	1	guacadmin	172.18.0.5	2026-01-20 14:05:53.71+00	\N
409	1	guacadmin	172.18.0.5	2026-01-20 14:06:12.722+00	\N
410	1	guacadmin	172.18.0.5	2026-01-20 14:06:31.726+00	\N
396	1	guacadmin	172.18.0.5	2026-01-20 12:30:43.431+00	2026-01-20 14:11:15.808+00
411	1	guacadmin	172.18.0.5	2026-01-20 14:21:48.17+00	\N
412	1	guacadmin	172.18.0.5	2026-01-20 14:22:05.956+00	\N
413	1	guacadmin	172.18.0.5	2026-01-20 14:22:07.187+00	\N
414	1	guacadmin	172.18.0.5	2026-01-20 14:22:17.426+00	\N
415	1	guacadmin	172.18.0.5	2026-01-20 14:22:19.695+00	\N
416	1	guacadmin	172.18.0.5	2026-01-20 14:22:20.963+00	\N
417	1	guacadmin	172.18.0.5	2026-01-20 14:22:39.916+00	\N
418	1	guacadmin	172.18.0.5	2026-01-20 14:22:45.453+00	\N
423	1	guacadmin	172.18.0.5	2026-01-20 14:23:05.909+00	\N
424	1	guacadmin	172.18.0.5	2026-01-20 14:45:58.482+00	\N
425	1	guacadmin	172.18.0.5	2026-01-20 14:52:05.117+00	\N
437	1	guacadmin	172.18.0.5	2026-01-20 18:17:19.848+00	\N
438	1	guacadmin	172.18.0.5	2026-01-20 18:17:30.309+00	\N
444	1	guacadmin	172.18.0.5	2026-01-20 18:17:57.236+00	\N
448	1	guacadmin	172.18.0.5	2026-01-20 18:18:28.728+00	\N
456	1	guacadmin	172.18.0.5	2026-01-20 18:35:02.815+00	\N
462	1	guacadmin	172.18.0.5	2026-01-20 18:35:47.178+00	\N
464	1	guacadmin	172.18.0.5	2026-01-20 18:35:53.06+00	\N
468	1	guacadmin	172.18.0.5	2026-01-20 18:35:55.132+00	\N
469	1	guacadmin	172.18.0.5	2026-01-20 18:44:37.186+00	\N
470	1	guacadmin	172.18.0.5	2026-01-20 18:45:17.849+00	\N
475	1	guacadmin	172.18.0.5	2026-01-20 19:01:30.619+00	\N
476	1	guacadmin	172.18.0.5	2026-01-20 19:03:07.713+00	\N
477	1	guacadmin	172.18.0.5	2026-01-20 19:15:58.756+00	\N
480	1	guacadmin	172.18.0.5	2026-01-20 19:21:35.848+00	\N
419	1	guacadmin	172.18.0.5	2026-01-20 14:22:48.653+00	\N
421	1	guacadmin	172.18.0.5	2026-01-20 14:22:49.898+00	\N
422	1	guacadmin	172.18.0.5	2026-01-20 14:23:05.898+00	\N
427	1	guacadmin	172.18.0.5	2026-01-20 14:52:27.911+00	2026-01-20 15:59:15.808+00
430	1	guacadmin	172.18.0.5	2026-01-20 18:15:46.269+00	\N
432	1	guacadmin	172.18.0.5	2026-01-20 18:17:00.384+00	\N
435	1	guacadmin	172.18.0.5	2026-01-20 18:17:05.884+00	\N
440	1	guacadmin	172.18.0.5	2026-01-20 18:17:31.761+00	\N
443	1	guacadmin	172.18.0.5	2026-01-20 18:17:55.344+00	\N
446	1	guacadmin	172.18.0.5	2026-01-20 18:18:10.269+00	\N
454	1	guacadmin	172.18.0.5	2026-01-20 18:35:00.76+00	\N
461	1	guacadmin	172.18.0.5	2026-01-20 18:35:35.159+00	\N
465	1	guacadmin	172.18.0.5	2026-01-20 18:35:53.249+00	\N
467	1	guacadmin	172.18.0.5	2026-01-20 18:35:54.716+00	\N
472	1	guacadmin	172.18.0.5	2026-01-20 18:46:01.261+00	\N
474	1	guacadmin	172.18.0.5	2026-01-20 19:01:28.993+00	\N
478	1	guacadmin	172.18.0.5	2026-01-20 19:16:00.838+00	\N
481	1	guacadmin	172.18.0.5	2026-01-20 19:24:52.15+00	2026-01-20 20:25:15.808+00
420	1	guacadmin	172.18.0.5	2026-01-20 14:22:48.87+00	\N
426	1	guacadmin	172.18.0.5	2026-01-20 14:52:24.123+00	\N
428	1	guacadmin	172.18.0.5	2026-01-20 18:15:43.388+00	\N
433	1	guacadmin	172.18.0.5	2026-01-20 18:17:00.514+00	\N
439	1	guacadmin	172.18.0.5	2026-01-20 18:17:31.552+00	\N
442	1	guacadmin	172.18.0.5	2026-01-20 18:17:53.92+00	\N
450	1	guacadmin	172.18.0.5	2026-01-20 18:18:29.782+00	\N
452	1	guacadmin	172.18.0.5	2026-01-20 18:18:31.396+00	\N
453	1	guacadmin	172.18.0.5	2026-01-20 18:18:48.033+00	\N
455	1	guacadmin	172.18.0.5	2026-01-20 18:35:01.761+00	\N
459	1	guacadmin	172.18.0.5	2026-01-20 18:35:30.999+00	\N
463	1	guacadmin	172.18.0.5	2026-01-20 18:35:52.062+00	\N
473	1	guacadmin	172.18.0.5	2026-01-20 19:01:27.162+00	\N
479	1	guacadmin	172.18.0.5	2026-01-20 19:16:35.187+00	\N
429	1	guacadmin	172.18.0.5	2026-01-20 18:15:43.414+00	\N
431	1	guacadmin	172.18.0.5	2026-01-20 18:16:58.485+00	\N
434	1	guacadmin	172.18.0.5	2026-01-20 18:17:04.689+00	\N
436	1	guacadmin	172.18.0.5	2026-01-20 18:17:07.1+00	\N
441	1	guacadmin	172.18.0.5	2026-01-20 18:17:33.116+00	\N
445	1	guacadmin	172.18.0.5	2026-01-20 18:18:08.844+00	\N
447	1	guacadmin	172.18.0.5	2026-01-20 18:18:23.611+00	\N
449	1	guacadmin	172.18.0.5	2026-01-20 18:18:29.569+00	\N
451	1	guacadmin	172.18.0.5	2026-01-20 18:18:30.875+00	\N
457	1	guacadmin	172.18.0.5	2026-01-20 18:35:18.679+00	\N
458	1	guacadmin	172.18.0.5	2026-01-20 18:35:18.834+00	\N
460	1	guacadmin	172.18.0.5	2026-01-20 18:35:32.777+00	\N
466	1	guacadmin	172.18.0.5	2026-01-20 18:35:54.233+00	\N
471	1	guacadmin	172.18.0.5	2026-01-20 18:45:29.839+00	\N
482	1	guacadmin	172.18.0.5	2026-01-23 11:20:11.406+00	\N
483	1	guacadmin	172.18.0.5	2026-01-23 11:20:11.462+00	\N
484	1	guacadmin	172.18.0.5	2026-01-23 11:24:45.91+00	\N
485	1	guacadmin	172.18.0.5	2026-01-23 11:25:06.162+00	\N
486	1	guacadmin	172.18.0.5	2026-01-23 11:25:11.641+00	\N
487	1	guacadmin	172.18.0.5	2026-01-23 11:25:12.246+00	\N
488	1	guacadmin	172.18.0.5	2026-01-23 11:25:12.792+00	\N
489	1	guacadmin	172.18.0.5	2026-01-23 11:25:21.943+00	\N
490	1	guacadmin	172.18.0.5	2026-01-23 11:25:22.589+00	\N
491	1	guacadmin	172.18.0.5	2026-01-23 11:25:24.63+00	\N
492	1	guacadmin	172.18.0.5	2026-01-23 11:25:40.446+00	\N
493	1	guacadmin	172.18.0.5	2026-01-23 11:25:56.153+00	\N
494	1	guacadmin	172.18.0.5	2026-01-23 11:26:01.551+00	\N
495	1	guacadmin	172.18.0.5	2026-01-23 11:26:04.947+00	\N
496	1	guacadmin	172.18.0.5	2026-01-23 11:28:39.399+00	\N
497	1	guacadmin	172.18.0.5	2026-01-23 11:28:42.63+00	\N
498	1	guacadmin	172.18.0.5	2026-01-23 11:28:45.359+00	\N
499	1	guacadmin	172.18.0.5	2026-01-23 11:28:47.26+00	\N
500	1	guacadmin	172.18.0.5	2026-01-23 11:28:49.962+00	\N
501	1	guacadmin	172.18.0.5	2026-01-23 11:29:00.956+00	\N
502	1	guacadmin	172.18.0.5	2026-01-23 11:29:03.111+00	\N
503	1	guacadmin	172.18.0.5	2026-01-23 11:29:04.722+00	\N
504	1	guacadmin	172.18.0.5	2026-02-19 12:35:40.378+00	\N
505	1	guacadmin	172.18.0.5	2026-02-19 12:35:47.355+00	\N
506	1	guacadmin	172.18.0.5	2026-02-19 12:35:47.746+00	\N
507	1	guacadmin	172.18.0.5	2026-02-19 12:35:51.918+00	\N
508	1	guacadmin	172.18.0.5	2026-02-19 12:36:07.622+00	\N
509	1	guacadmin	172.18.0.5	2026-02-19 12:42:58.769+00	\N
510	1	guacadmin	172.18.0.5	2026-02-19 12:42:58.96+00	\N
511	1	guacadmin	172.18.0.5	2026-02-19 12:43:01.257+00	\N
512	1	guacadmin	172.18.0.5	2026-02-19 12:43:05.143+00	\N
513	1	guacadmin	172.18.0.5	2026-02-19 12:43:05.787+00	\N
514	1	guacadmin	172.18.0.5	2026-02-19 12:43:16.448+00	\N
515	1	guacadmin	172.18.0.5	2026-02-19 12:43:21.067+00	\N
516	1	guacadmin	172.18.0.5	2026-02-19 12:43:21.23+00	\N
517	1	guacadmin	172.18.0.5	2026-02-19 12:44:16.573+00	\N
518	1	guacadmin	172.18.0.5	2026-02-19 12:44:16.87+00	\N
519	1	guacadmin	172.18.0.5	2026-02-19 12:44:19.005+00	\N
520	1	guacadmin	172.18.0.5	2026-02-19 12:44:21.651+00	\N
521	1	guacadmin	172.18.0.5	2026-02-19 12:44:21.742+00	\N
522	1	guacadmin	172.18.0.5	2026-02-19 12:44:22.757+00	\N
523	1	guacadmin	172.18.0.5	2026-02-19 12:44:22.936+00	\N
524	1	guacadmin	172.18.0.5	2026-02-19 12:44:23.076+00	\N
525	1	guacadmin	172.18.0.5	2026-02-19 12:44:39.212+00	\N
526	1	guacadmin	172.18.0.5	2026-02-19 12:44:55.331+00	\N
527	1	guacadmin	172.18.0.5	2026-02-19 12:45:11.311+00	\N
528	1	guacadmin	172.18.0.5	2026-02-19 12:45:40.108+00	\N
529	1	guacadmin	172.18.0.5	2026-02-19 12:45:40.607+00	\N
530	1	guacadmin	172.18.0.5	2026-02-19 12:45:45.101+00	\N
531	1	guacadmin	172.18.0.5	2026-02-19 12:45:46.559+00	\N
532	1	guacadmin	172.18.0.5	2026-02-19 12:45:47.683+00	\N
533	1	guacadmin	172.18.0.5	2026-02-19 12:46:08.703+00	\N
534	1	guacadmin	172.18.0.5	2026-02-19 12:46:10.475+00	\N
535	1	guacadmin	172.18.0.5	2026-02-19 12:46:11.67+00	\N
536	1	guacadmin	172.18.0.5	2026-02-19 12:46:13.704+00	\N
537	1	guacadmin	172.18.0.5	2026-02-19 12:46:15.554+00	\N
538	1	guacadmin	172.18.0.5	2026-02-19 12:46:16.952+00	2026-02-19 12:55:51.751+00
539	1	guacadmin	172.18.0.5	2026-02-19 13:02:30.127+00	\N
540	1	guacadmin	172.18.0.5	2026-02-19 13:02:30.352+00	\N
541	1	guacadmin	172.18.0.5	2026-02-19 13:04:43.992+00	\N
542	1	guacadmin	172.18.0.5	2026-02-19 13:04:48.237+00	\N
543	1	guacadmin	172.18.0.5	2026-02-19 13:04:49.769+00	\N
544	1	guacadmin	172.18.0.5	2026-02-19 13:04:51.29+00	\N
545	1	guacadmin	172.18.0.5	2026-02-19 13:05:07.485+00	\N
546	1	guacadmin	172.18.0.5	2026-02-19 13:05:30.798+00	\N
547	1	guacadmin	172.18.0.5	2026-02-19 13:06:38.134+00	\N
548	1	guacadmin	172.18.0.5	2026-02-19 13:06:38.638+00	\N
549	1	guacadmin	172.18.0.5	2026-02-19 13:06:40.217+00	\N
550	1	guacadmin	172.18.0.5	2026-02-19 13:06:48.166+00	\N
551	1	guacadmin	172.18.0.5	2026-02-19 13:06:56.45+00	\N
552	1	guacadmin	172.18.0.5	2026-02-19 13:07:12.436+00	\N
553	1	guacadmin	172.18.0.5	2026-02-19 13:07:28.44+00	\N
554	1	guacadmin	172.18.0.5	2026-02-19 13:07:44.859+00	\N
555	1	guacadmin	172.18.0.5	2026-02-19 13:10:14.734+00	\N
556	1	guacadmin	172.18.0.5	2026-02-19 13:18:38.737+00	\N
557	1	guacadmin	172.18.0.5	2026-02-19 13:18:47.683+00	\N
558	1	guacadmin	172.18.0.5	2026-02-19 13:19:03.474+00	\N
559	1	guacadmin	172.18.0.5	2026-02-19 13:19:19.468+00	\N
560	1	guacadmin	172.18.0.5	2026-02-19 13:19:35.467+00	\N
561	1	guacadmin	172.18.0.5	2026-02-19 13:20:38.372+00	\N
562	1	guacadmin	172.18.0.5	2026-02-19 13:26:42.062+00	\N
563	1	guacadmin	172.18.0.5	2026-02-19 13:29:53.091+00	\N
564	1	guacadmin	172.18.0.5	2026-02-19 13:29:53.308+00	\N
565	1	guacadmin	172.18.0.5	2026-02-19 13:29:55.348+00	\N
566	1	guacadmin	172.18.0.5	2026-02-19 13:29:57.096+00	\N
567	1	guacadmin	172.18.0.5	2026-02-19 13:29:58.356+00	\N
568	1	guacadmin	172.18.0.5	2026-02-19 13:30:00.02+00	\N
569	1	guacadmin	172.18.0.5	2026-02-19 13:30:58.537+00	\N
570	1	guacadmin	172.18.0.5	2026-02-19 13:31:01.105+00	\N
571	1	guacadmin	172.18.0.5	2026-02-19 13:31:02.286+00	\N
572	1	guacadmin	172.18.0.5	2026-02-19 13:31:02.388+00	\N
573	1	guacadmin	172.18.0.5	2026-02-19 13:31:03.772+00	\N
574	1	guacadmin	172.18.0.5	2026-02-19 13:31:03.924+00	\N
575	1	guacadmin	172.18.0.5	2026-02-19 13:31:04.062+00	\N
576	1	guacadmin	172.18.0.5	2026-02-19 13:31:04.502+00	\N
577	1	guacadmin	172.18.0.5	2026-02-19 13:31:25.892+00	\N
578	1	guacadmin	172.18.0.5	2026-02-19 13:31:26.98+00	\N
579	1	guacadmin	172.18.0.5	2026-02-19 13:31:28.604+00	\N
580	1	guacadmin	172.18.0.5	2026-02-19 13:31:38.395+00	\N
581	1	guacadmin	172.18.0.5	2026-02-19 13:31:43.205+00	\N
582	1	guacadmin	172.18.0.5	2026-02-19 13:31:44.56+00	\N
583	1	guacadmin	172.18.0.5	2026-02-19 13:31:44.659+00	\N
584	1	guacadmin	172.18.0.5	2026-02-19 13:31:45.484+00	\N
585	1	guacadmin	172.18.0.5	2026-02-19 13:31:45.64+00	\N
586	1	guacadmin	172.18.0.5	2026-02-19 13:31:45.834+00	\N
587	1	guacadmin	172.18.0.5	2026-02-19 13:31:46.607+00	\N
588	1	guacadmin	172.18.0.5	2026-02-19 13:32:30.142+00	\N
589	1	guacadmin	172.18.0.5	2026-02-19 13:32:31.379+00	\N
590	1	guacadmin	172.18.0.5	2026-02-19 13:32:32.58+00	\N
591	1	guacadmin	172.18.0.5	2026-02-19 13:32:43.647+00	\N
592	1	guacadmin	172.18.0.5	2026-02-19 13:32:47.172+00	\N
593	1	guacadmin	172.18.0.5	2026-02-19 13:32:49.615+00	\N
594	1	guacadmin	172.18.0.5	2026-02-19 13:32:50.693+00	\N
595	1	guacadmin	172.18.0.5	2026-02-19 13:32:52.543+00	\N
596	1	guacadmin	172.18.0.5	2026-02-19 13:32:54.279+00	\N
598	1	guacadmin	172.18.0.5	2026-02-19 13:32:55.263+00	\N
601	1	guacadmin	172.18.0.5	2026-02-19 13:33:11.394+00	\N
597	1	guacadmin	172.18.0.5	2026-02-19 13:32:54.369+00	\N
603	1	guacadmin	172.18.0.5	2026-02-19 13:33:27.393+00	\N
599	1	guacadmin	172.18.0.5	2026-02-19 13:32:55.42+00	\N
602	1	guacadmin	172.18.0.5	2026-02-19 13:33:27.385+00	\N
600	1	guacadmin	172.18.0.5	2026-02-19 13:33:11.388+00	\N
604	1	guacadmin	172.18.0.5	2026-02-19 13:33:58.142+00	\N
605	1	guacadmin	172.18.0.5	2026-02-19 13:34:11.509+00	\N
606	1	guacadmin	172.18.0.5	2026-02-19 13:34:11.708+00	\N
607	1	guacadmin	172.18.0.5	2026-02-19 13:34:12.739+00	\N
608	1	guacadmin	172.18.0.5	2026-02-19 13:34:14.498+00	\N
609	1	guacadmin	172.18.0.5	2026-02-19 13:34:17.164+00	\N
610	1	guacadmin	172.18.0.5	2026-02-19 13:34:18.285+00	\N
611	1	guacadmin	172.18.0.5	2026-02-19 13:34:59.014+00	\N
612	1	guacadmin	172.18.0.5	2026-02-19 13:35:03.379+00	\N
613	1	guacadmin	172.18.0.5	2026-02-19 13:35:04.499+00	\N
614	1	guacadmin	172.18.0.5	2026-02-19 13:35:04.603+00	\N
615	1	guacadmin	172.18.0.5	2026-02-19 13:35:05.493+00	\N
616	1	guacadmin	172.18.0.5	2026-02-19 13:35:21.396+00	\N
617	1	guacadmin	172.18.0.5	2026-02-19 13:35:37.381+00	\N
618	1	guacadmin	172.18.0.5	2026-02-19 13:35:53.313+00	\N
619	1	guacadmin	172.18.0.5	2026-02-19 13:38:14.711+00	\N
620	1	guacadmin	172.18.0.5	2026-02-19 13:38:14.717+00	\N
621	1	guacadmin	172.18.0.5	2026-02-19 13:39:50.16+00	\N
622	1	guacadmin	172.18.0.5	2026-02-19 13:44:58.215+00	\N
623	1	guacadmin	172.18.0.5	2026-02-19 13:45:45.813+00	\N
624	1	guacadmin	172.18.0.5	2026-02-19 13:51:02.447+00	\N
625	1	guacadmin	172.18.0.5	2026-02-19 13:51:13.003+00	\N
626	1	guacadmin	172.18.0.5	2026-02-19 13:51:19.646+00	\N
627	1	guacadmin	172.18.0.5	2026-02-19 13:51:29.009+00	\N
628	1	guacadmin	172.18.0.5	2026-02-19 13:56:18.796+00	\N
629	1	guacadmin	172.18.0.5	2026-02-19 14:02:51.829+00	\N
630	1	guacadmin	172.18.0.5	2026-02-19 14:02:52.026+00	\N
631	1	guacadmin	172.18.0.5	2026-02-19 14:02:54.341+00	\N
632	1	guacadmin	172.18.0.5	2026-02-19 14:03:48.852+00	\N
633	1	guacadmin	172.18.0.5	2026-02-19 14:03:49.964+00	\N
634	1	guacadmin	172.18.0.5	2026-02-19 14:03:51.492+00	\N
635	1	guacadmin	172.18.0.5	2026-02-19 14:04:00.683+00	\N
636	1	guacadmin	172.18.0.5	2026-02-19 14:04:04.125+00	\N
637	1	guacadmin	172.18.0.5	2026-02-19 14:04:05.744+00	\N
638	1	guacadmin	172.18.0.5	2026-02-19 14:04:05.843+00	\N
639	1	guacadmin	172.18.0.5	2026-02-19 14:04:21.308+00	\N
640	1	guacadmin	172.18.0.5	2026-02-19 14:04:21.315+00	\N
641	1	guacadmin	172.18.0.5	2026-02-19 14:04:37.394+00	\N
642	1	guacadmin	172.18.0.5	2026-02-19 14:04:53.39+00	\N
643	1	guacadmin	172.18.0.5	2026-02-19 14:07:14.672+00	\N
644	1	guacadmin	172.18.0.5	2026-02-19 14:08:54.392+00	\N
645	1	guacadmin	172.18.0.5	2026-02-19 14:09:10.4+00	\N
646	1	guacadmin	172.18.0.5	2026-02-19 14:09:10.409+00	\N
647	1	guacadmin	172.18.0.5	2026-02-19 14:09:26.424+00	\N
648	1	guacadmin	172.18.0.5	2026-02-19 14:09:26.432+00	\N
649	1	guacadmin	172.18.0.5	2026-02-19 14:09:42.423+00	2026-02-19 15:14:01.875+00
650	1	guacadmin	172.18.0.5	2026-02-20 05:57:46.17+00	\N
651	1	guacadmin	172.18.0.5	2026-02-20 05:57:46.197+00	\N
652	1	guacadmin	172.18.0.5	2026-02-20 05:57:46.326+00	\N
653	1	guacadmin	172.18.0.5	2026-02-20 05:58:02.048+00	\N
654	1	guacadmin	172.18.0.5	2026-02-20 05:58:02.361+00	\N
655	1	guacadmin	172.18.0.5	2026-02-20 05:58:11.728+00	\N
656	1	guacadmin	172.18.0.5	2026-02-20 05:58:27.331+00	\N
657	1	guacadmin	172.18.0.5	2026-02-20 05:58:29.357+00	\N
658	1	guacadmin	172.18.0.5	2026-02-20 05:58:37.17+00	\N
659	1	guacadmin	172.18.0.5	2026-02-20 05:58:37.473+00	\N
660	1	guacadmin	172.18.0.5	2026-02-20 05:58:52.817+00	\N
661	1	guacadmin	172.18.0.5	2026-02-20 05:58:54.12+00	\N
662	1	guacadmin	172.18.0.5	2026-02-20 05:58:56.072+00	\N
663	1	guacadmin	172.18.0.5	2026-02-20 05:58:57.152+00	\N
664	1	guacadmin	172.18.0.5	2026-02-20 05:58:58.925+00	\N
665	1	guacadmin	172.18.0.5	2026-02-20 05:59:04.277+00	\N
666	1	guacadmin	172.18.0.5	2026-02-20 05:59:06.038+00	\N
667	1	guacadmin	172.18.0.5	2026-02-20 05:59:07.379+00	\N
668	1	guacadmin	172.18.0.5	2026-02-20 05:59:07.579+00	\N
669	1	guacadmin	172.18.0.5	2026-02-20 05:59:08.776+00	\N
670	1	guacadmin	172.18.0.5	2026-02-20 05:59:24.334+00	\N
671	1	guacadmin	172.18.0.5	2026-02-20 05:59:34.43+00	\N
672	1	guacadmin	172.18.0.5	2026-02-20 05:59:36.12+00	\N
673	1	guacadmin	172.18.0.5	2026-02-20 05:59:37.393+00	\N
674	1	guacadmin	172.18.0.5	2026-02-20 05:59:38.715+00	\N
675	1	guacadmin	172.18.0.5	2026-02-20 05:59:50.827+00	\N
676	1	guacadmin	172.18.0.5	2026-02-20 05:59:55.325+00	\N
677	1	guacadmin	172.18.0.5	2026-02-20 05:59:56.933+00	\N
678	1	guacadmin	172.18.0.5	2026-02-20 05:59:57.117+00	\N
679	1	guacadmin	172.18.0.5	2026-02-20 05:59:58.254+00	\N
680	1	guacadmin	172.18.0.5	2026-02-20 05:59:58.675+00	\N
681	1	guacadmin	172.18.0.5	2026-02-20 06:00:39.013+00	\N
682	1	guacadmin	172.18.0.5	2026-02-20 06:00:40.389+00	\N
683	1	guacadmin	172.18.0.5	2026-02-20 06:00:41.63+00	\N
684	1	guacadmin	172.18.0.5	2026-02-20 06:00:52.585+00	\N
685	1	guacadmin	172.18.0.5	2026-02-20 06:00:57.112+00	\N
686	1	guacadmin	172.18.0.5	2026-02-20 06:00:58.931+00	\N
687	1	guacadmin	172.18.0.5	2026-02-20 06:00:59.125+00	\N
688	1	guacadmin	172.18.0.5	2026-02-20 06:01:00.206+00	\N
689	1	guacadmin	172.18.0.5	2026-02-20 06:01:16.317+00	\N
690	1	guacadmin	172.18.0.5	2026-02-20 06:01:32.331+00	\N
691	1	guacadmin	172.18.0.5	2026-02-20 06:01:48.329+00	\N
692	1	guacadmin	172.18.0.5	2026-02-20 06:02:04.333+00	\N
693	1	guacadmin	172.18.0.5	2026-02-20 06:02:51.326+00	\N
694	1	guacadmin	172.18.0.5	2026-02-20 06:03:17.254+00	\N
695	1	guacadmin	172.18.0.5	2026-02-20 06:03:43.266+00	\N
696	1	guacadmin	172.18.0.5	2026-02-20 06:11:39.268+00	\N
697	1	guacadmin	172.18.0.5	2026-02-20 06:11:56.367+00	\N
698	1	guacadmin	172.18.0.5	2026-02-20 06:12:12.326+00	\N
699	1	guacadmin	172.18.0.5	2026-02-20 06:12:28.326+00	\N
700	1	guacadmin	172.18.0.5	2026-02-20 06:12:59.238+00	\N
701	1	guacadmin	172.18.0.5	2026-02-20 06:13:00.373+00	\N
702	1	guacadmin	172.18.0.5	2026-02-20 06:13:04.646+00	\N
703	1	guacadmin	172.18.0.5	2026-02-20 06:13:13.564+00	\N
704	1	guacadmin	172.18.0.5	2026-02-20 06:13:16.27+00	\N
705	1	guacadmin	172.18.0.5	2026-02-20 06:13:17.445+00	\N
706	1	guacadmin	172.18.0.5	2026-02-20 06:13:18.394+00	\N
707	1	guacadmin	172.18.0.5	2026-02-20 06:13:24.439+00	\N
708	1	guacadmin	172.18.0.5	2026-02-20 06:13:25.285+00	\N
709	1	guacadmin	172.18.0.5	2026-02-20 06:13:26.332+00	\N
710	1	guacadmin	172.18.0.5	2026-02-20 06:13:34.701+00	\N
711	1	guacadmin	172.18.0.5	2026-02-20 06:13:37.119+00	\N
712	1	guacadmin	172.18.0.5	2026-02-20 06:25:20.407+00	\N
713	1	guacadmin	172.18.0.5	2026-02-20 06:55:37.98+00	\N
714	1	guacadmin	172.18.0.5	2026-02-20 07:23:55.07+00	\N
715	1	guacadmin	172.18.0.5	2026-02-20 07:24:08.188+00	\N
716	1	guacadmin	172.18.0.5	2026-02-20 07:24:08.324+00	\N
717	1	guacadmin	172.18.0.5	2026-02-20 07:24:28.686+00	\N
718	1	guacadmin	172.18.0.5	2026-02-20 07:24:30.305+00	\N
719	1	guacadmin	172.18.0.5	2026-02-20 07:24:31.318+00	\N
720	1	guacadmin	172.18.0.5	2026-02-20 07:24:34.784+00	\N
721	1	guacadmin	172.18.0.5	2026-02-20 07:24:46.254+00	\N
722	1	guacadmin	172.18.0.5	2026-02-20 07:24:47.683+00	\N
723	1	guacadmin	172.18.0.5	2026-02-20 07:24:48.971+00	\N
724	1	guacadmin	172.18.0.5	2026-02-20 07:24:57.775+00	\N
725	1	guacadmin	172.18.0.5	2026-02-20 07:24:58.045+00	\N
726	1	guacadmin	172.18.0.5	2026-02-20 07:25:01.643+00	\N
727	1	guacadmin	172.18.0.5	2026-02-20 07:25:03.744+00	\N
729	1	guacadmin	172.18.0.5	2026-02-20 07:25:06.811+00	\N
738	1	guacadmin	172.18.0.5	2026-02-20 07:25:54.546+00	\N
741	1	guacadmin	172.18.0.5	2026-02-20 07:26:07.509+00	\N
744	1	guacadmin	172.18.0.5	2026-02-20 07:27:01.162+00	\N
748	1	guacadmin	172.18.0.5	2026-02-20 07:27:48.298+00	\N
728	1	guacadmin	172.18.0.5	2026-02-20 07:25:04.832+00	\N
730	1	guacadmin	172.18.0.5	2026-02-20 07:25:16.69+00	\N
731	1	guacadmin	172.18.0.5	2026-02-20 07:25:27.699+00	\N
732	1	guacadmin	172.18.0.5	2026-02-20 07:25:30.544+00	\N
733	1	guacadmin	172.18.0.5	2026-02-20 07:25:32.02+00	\N
734	1	guacadmin	172.18.0.5	2026-02-20 07:25:49.419+00	\N
735	1	guacadmin	172.18.0.5	2026-02-20 07:25:49.675+00	\N
736	1	guacadmin	172.18.0.5	2026-02-20 07:25:51.489+00	\N
737	1	guacadmin	172.18.0.5	2026-02-20 07:25:53.541+00	\N
739	1	guacadmin	172.18.0.5	2026-02-20 07:25:55.495+00	\N
740	1	guacadmin	172.18.0.5	2026-02-20 07:26:06.605+00	\N
742	1	guacadmin	172.18.0.5	2026-02-20 07:26:09.972+00	\N
743	1	guacadmin	172.18.0.5	2026-02-20 07:26:21.526+00	\N
745	1	guacadmin	172.18.0.5	2026-02-20 07:27:03.747+00	\N
746	1	guacadmin	172.18.0.5	2026-02-20 07:27:12.053+00	\N
747	1	guacadmin	172.18.0.5	2026-02-20 07:27:46.969+00	\N
749	1	guacadmin	172.18.0.4	2026-03-17 07:42:32.021+00	\N
750	1	guacadmin	172.18.0.4	2026-03-17 07:42:35.838+00	2026-03-17 07:46:48.13+00
751	1	guacadmin	172.18.0.5	2026-03-17 08:13:23.169+00	\N
752	1	guacadmin	172.18.0.5	2026-03-17 08:13:33.398+00	\N
753	1	guacadmin	172.18.0.5	2026-03-17 08:13:34.472+00	\N
754	1	guacadmin	172.18.0.5	2026-03-17 08:13:38.629+00	\N
755	1	guacadmin	172.18.0.5	2026-03-17 08:14:06.438+00	\N
756	1	guacadmin	172.18.0.5	2026-03-17 08:14:07.908+00	\N
757	1	guacadmin	172.18.0.5	2026-03-17 08:14:09.198+00	\N
758	1	guacadmin	172.18.0.5	2026-03-17 08:14:10.732+00	\N
759	1	guacadmin	172.18.0.5	2026-03-17 08:14:18.003+00	\N
760	1	guacadmin	172.18.0.5	2026-03-17 08:14:19.224+00	\N
761	1	guacadmin	172.18.0.5	2026-03-17 08:14:22.003+00	\N
762	1	guacadmin	172.18.0.5	2026-03-17 08:14:29.491+00	\N
763	1	guacadmin	172.18.0.5	2026-03-17 08:14:30.88+00	\N
764	1	guacadmin	172.18.0.5	2026-03-17 08:14:33.363+00	\N
765	1	guacadmin	172.18.0.5	2026-03-17 08:14:42.28+00	\N
766	1	guacadmin	172.18.0.5	2026-03-17 08:14:44.287+00	\N
767	1	guacadmin	172.18.0.5	2026-03-17 08:14:47.602+00	\N
768	1	guacadmin	172.18.0.5	2026-03-17 08:14:55.329+00	\N
769	1	guacadmin	172.18.0.5	2026-03-17 08:14:57.343+00	\N
770	1	guacadmin	172.18.0.5	2026-03-17 08:14:58.68+00	\N
771	1	guacadmin	172.18.0.5	2026-03-17 08:16:39.874+00	\N
772	1	guacadmin	172.18.0.5	2026-03-17 08:16:41.879+00	\N
773	1	guacadmin	172.18.0.5	2026-03-17 08:17:36.163+00	\N
774	1	guacadmin	172.18.0.5	2026-03-17 08:17:37.656+00	\N
775	1	guacadmin	172.18.0.5	2026-03-17 08:17:40.705+00	\N
776	1	guacadmin	172.18.0.5	2026-03-17 08:17:48.2+00	\N
777	1	guacadmin	172.18.0.5	2026-03-17 08:17:55.017+00	\N
778	1	guacadmin	172.18.0.5	2026-03-17 08:17:57.995+00	\N
779	1	guacadmin	172.18.0.5	2026-03-17 08:18:01.533+00	\N
780	1	guacadmin	172.18.0.5	2026-03-17 08:18:19.558+00	\N
781	1	guacadmin	172.18.0.5	2026-03-17 08:18:21.5+00	\N
782	1	guacadmin	172.18.0.5	2026-03-17 08:18:37.562+00	\N
783	1	guacadmin	172.18.0.5	2026-03-17 08:18:55.557+00	\N
784	1	guacadmin	172.18.0.5	2026-03-17 08:19:10.545+00	\N
785	1	guacadmin	172.18.0.5	2026-03-17 08:19:11.736+00	\N
786	1	guacadmin	172.18.0.5	2026-03-17 08:19:12.854+00	\N
787	1	guacadmin	172.18.0.5	2026-03-17 08:19:16.92+00	\N
788	1	guacadmin	172.18.0.5	2026-03-17 08:19:18.384+00	\N
789	1	guacadmin	172.18.0.5	2026-03-17 08:20:53.695+00	\N
790	1	guacadmin	172.18.0.5	2026-03-17 08:20:56.263+00	\N
791	1	guacadmin	172.18.0.5	2026-03-17 08:20:58.206+00	\N
792	1	guacadmin	172.18.0.5	2026-03-17 08:21:09.717+00	\N
793	1	guacadmin	172.18.0.5	2026-03-17 08:21:11.585+00	\N
794	1	guacadmin	172.18.0.5	2026-03-17 08:21:18.122+00	\N
795	1	guacadmin	172.18.0.5	2026-03-17 08:21:19.748+00	\N
796	1	guacadmin	172.18.0.5	2026-03-17 08:21:29.225+00	\N
797	1	guacadmin	172.18.0.5	2026-03-17 08:21:30.329+00	\N
798	1	guacadmin	172.18.0.5	2026-03-17 08:21:35.56+00	\N
799	1	guacadmin	172.18.0.5	2026-03-17 08:22:26.66+00	\N
800	1	guacadmin	172.18.0.5	2026-03-17 08:22:28.755+00	\N
801	1	guacadmin	172.18.0.2	2026-03-17 11:12:39.466+00	\N
802	1	guacadmin	172.18.0.2	2026-03-17 11:12:46.546+00	\N
803	1	guacadmin	172.18.0.2	2026-03-17 11:41:56.539+00	\N
804	1	guacadmin	172.18.0.2	2026-03-17 11:42:02.727+00	\N
805	1	guacadmin	172.18.0.2	2026-03-17 11:42:04.514+00	\N
806	1	guacadmin	172.18.0.2	2026-03-17 11:42:06.771+00	\N
807	1	guacadmin	172.18.0.2	2026-03-17 11:42:08.022+00	\N
808	1	guacadmin	172.18.0.2	2026-03-17 11:42:09.723+00	\N
809	1	guacadmin	172.18.0.2	2026-03-17 11:42:14.531+00	\N
810	1	guacadmin	172.18.0.2	2026-03-17 11:42:16.979+00	\N
811	1	guacadmin	172.18.0.2	2026-03-17 11:42:25.718+00	\N
812	1	guacadmin	172.18.0.2	2026-03-17 11:42:27.476+00	\N
813	1	guacadmin	172.18.0.2	2026-03-17 11:42:36.671+00	\N
814	1	guacadmin	172.18.0.2	2026-03-17 11:42:42.037+00	\N
815	1	guacadmin	172.18.0.2	2026-03-17 11:42:45.169+00	\N
816	1	guacadmin	172.18.0.2	2026-03-17 11:53:34.436+00	\N
817	1	guacadmin	172.18.0.2	2026-03-17 12:03:35.442+00	\N
818	1	guacadmin	172.18.0.2	2026-03-17 12:03:37.952+00	\N
819	1	guacadmin	172.18.0.2	2026-03-17 12:03:55.819+00	\N
820	1	guacadmin	172.18.0.2	2026-03-17 12:03:58.486+00	\N
821	1	guacadmin	172.18.0.2	2026-03-17 12:04:04.941+00	\N
822	1	guacadmin	172.18.0.2	2026-03-17 12:04:06.495+00	\N
823	1	guacadmin	172.18.0.2	2026-03-17 12:04:07.865+00	\N
824	1	guacadmin	172.18.0.2	2026-03-17 12:04:15.19+00	\N
825	1	guacadmin	172.18.0.2	2026-03-17 12:04:18.88+00	\N
826	1	guacadmin	172.18.0.2	2026-03-17 12:05:01.057+00	\N
827	1	guacadmin	172.18.0.2	2026-03-17 12:05:04.821+00	\N
828	1	guacadmin	172.18.0.2	2026-03-17 12:21:28.392+00	\N
829	1	guacadmin	172.18.0.2	2026-03-17 12:27:29.855+00	\N
830	1	guacadmin	172.18.0.2	2026-03-17 12:27:29.82+00	\N
831	1	guacadmin	172.18.0.2	2026-03-17 12:27:29.855+00	\N
832	1	guacadmin	172.18.0.2	2026-03-17 12:27:29.875+00	\N
833	1	guacadmin	172.18.0.2	2026-03-17 12:27:29.903+00	\N
834	1	guacadmin	172.18.0.2	2026-03-17 12:27:29.909+00	\N
835	1	guacadmin	172.18.0.2	2026-03-17 12:27:29.876+00	\N
836	1	guacadmin	172.18.0.2	2026-03-17 12:27:29.927+00	\N
837	1	guacadmin	172.18.0.2	2026-03-17 12:27:29.942+00	\N
840	1	guacadmin	172.18.0.2	2026-03-17 12:29:42.339+00	\N
849	1	guacadmin	172.18.0.2	2026-03-17 13:27:28.283+00	\N
857	1	guacadmin	172.18.0.2	2026-03-17 13:30:50.175+00	\N
861	1	guacadmin	172.18.0.2	2026-03-17 13:34:55.346+00	\N
865	1	guacadmin	172.18.0.2	2026-03-17 14:25:20.701+00	\N
866	1	guacadmin	172.18.0.2	2026-03-17 14:40:21.412+00	\N
873	1	guacadmin	172.18.0.2	2026-03-18 09:00:02.771+00	\N
838	1	guacadmin	172.18.0.2	2026-03-17 12:27:29.953+00	\N
850	1	guacadmin	172.18.0.2	2026-03-17 13:27:49.113+00	\N
854	1	guacadmin	172.18.0.2	2026-03-17 13:29:49.906+00	\N
858	1	guacadmin	172.18.0.2	2026-03-17 13:31:09.127+00	\N
863	1	guacadmin	172.18.0.2	2026-03-17 14:22:13.676+00	\N
869	1	guacadmin	172.18.0.2	2026-03-18 08:08:52.746+00	\N
874	1	guacadmin	172.18.0.2	2026-03-18 09:02:07.758+00	\N
839	1	guacadmin	172.18.0.2	2026-03-17 12:27:29.961+00	\N
842	1	guacadmin	172.18.0.2	2026-03-17 12:40:46.489+00	\N
844	1	guacadmin	172.18.0.2	2026-03-17 12:52:28.824+00	\N
848	1	guacadmin	172.18.0.2	2026-03-17 13:27:00.274+00	\N
851	1	guacadmin	172.18.0.2	2026-03-17 13:28:46.606+00	\N
855	1	guacadmin	172.18.0.2	2026-03-17 13:30:10.888+00	\N
860	1	guacadmin	172.18.0.2	2026-03-17 13:31:59.801+00	\N
870	1	guacadmin	172.18.0.2	2026-03-18 08:09:11.62+00	\N
841	1	guacadmin	172.18.0.2	2026-03-17 12:30:40.034+00	\N
846	1	guacadmin	172.18.0.2	2026-03-17 13:10:18.951+00	\N
847	1	guacadmin	172.18.0.2	2026-03-17 13:13:30.312+00	\N
852	1	guacadmin	172.18.0.2	2026-03-17 13:29:07.908+00	\N
856	1	guacadmin	172.18.0.2	2026-03-17 13:30:31.876+00	\N
859	1	guacadmin	172.18.0.2	2026-03-17 13:31:26.811+00	\N
862	1	guacadmin	172.18.0.2	2026-03-17 14:14:21.205+00	\N
867	1	guacadmin	172.18.0.2	2026-03-17 14:40:25.566+00	2026-03-17 15:41:32.205+00
872	1	guacadmin	172.18.0.2	2026-03-18 08:49:19.819+00	\N
875	1	guacadmin	172.18.0.2	2026-03-18 09:02:15.076+00	\N
843	1	guacadmin	172.18.0.2	2026-03-17 12:52:28.824+00	\N
845	1	guacadmin	172.18.0.2	2026-03-17 12:53:17.588+00	\N
853	1	guacadmin	172.18.0.2	2026-03-17 13:29:28.901+00	\N
864	1	guacadmin	172.18.0.2	2026-03-17 14:22:38.501+00	\N
868	1	guacadmin	172.18.0.2	2026-03-18 08:08:42.513+00	\N
871	1	guacadmin	172.18.0.2	2026-03-18 08:17:48.433+00	\N
876	1	guacadmin	172.18.0.5	2026-04-18 06:42:25.918+00	2026-04-18 07:43:11.227+00
877	1	guacadmin	172.18.0.5	2026-04-18 11:07:11.484+00	\N
878	1	guacadmin	172.18.0.5	2026-04-18 11:07:22.252+00	\N
879	1	guacadmin	172.18.0.5	2026-04-18 11:07:33.924+00	\N
880	1	guacadmin	172.18.0.5	2026-04-18 11:07:38.911+00	\N
881	1	guacadmin	172.18.0.5	2026-04-18 11:07:43.163+00	\N
882	1	guacadmin	172.18.0.5	2026-04-18 11:07:54.21+00	\N
883	1	guacadmin	172.18.0.5	2026-04-18 11:07:56.07+00	\N
884	1	guacadmin	172.18.0.5	2026-04-18 11:07:57.553+00	\N
885	1	guacadmin	172.18.0.5	2026-04-18 11:08:10.98+00	\N
886	1	guacadmin	172.18.0.5	2026-04-18 11:08:16.034+00	\N
887	1	guacadmin	172.18.0.5	2026-04-18 11:08:29.301+00	\N
888	1	guacadmin	172.18.0.2	2026-05-08 06:09:26.866+00	\N
889	1	guacadmin	172.18.0.2	2026-05-08 06:09:27.421+00	\N
890	1	guacadmin	172.18.0.2	2026-05-08 06:09:27.446+00	\N
891	1	guacadmin	172.18.0.2	2026-05-08 06:09:28.537+00	\N
892	1	guacadmin	172.18.0.2	2026-05-08 06:09:29.928+00	\N
893	1	guacadmin	172.18.0.2	2026-05-08 06:09:30.138+00	\N
894	1	guacadmin	172.18.0.2	2026-05-08 06:09:33.851+00	\N
895	1	guacadmin	172.18.0.2	2026-05-08 06:09:39.155+00	\N
896	1	guacadmin	172.18.0.2	2026-05-08 06:09:40.855+00	\N
897	1	guacadmin	172.18.0.2	2026-05-08 06:09:43.895+00	\N
898	1	guacadmin	172.18.0.2	2026-05-08 06:09:45.887+00	\N
899	1	guacadmin	172.18.0.2	2026-05-08 06:09:52.086+00	\N
900	1	guacadmin	172.18.0.2	2026-05-08 06:09:52.178+00	\N
901	1	guacadmin	172.18.0.2	2026-05-08 06:09:53.252+00	\N
902	1	guacadmin	172.18.0.2	2026-05-08 06:09:53.512+00	\N
903	1	guacadmin	172.18.0.2	2026-05-08 06:09:59.88+00	\N
904	1	guacadmin	172.18.0.2	2026-05-08 06:10:01.882+00	\N
905	1	guacadmin	172.18.0.2	2026-05-08 06:10:08.879+00	\N
906	1	guacadmin	172.18.0.2	2026-05-08 06:10:15.873+00	\N
907	1	guacadmin	172.18.0.2	2026-05-08 06:10:17.873+00	\N
908	1	guacadmin	172.18.0.2	2026-05-08 06:10:24.883+00	\N
909	1	guacadmin	172.18.0.2	2026-05-08 06:10:32.886+00	\N
910	1	guacadmin	172.18.0.2	2026-05-08 06:10:33.888+00	\N
911	1	guacadmin	172.18.0.2	2026-05-08 06:33:40.046+00	\N
912	1	guacadmin	172.18.0.2	2026-05-08 06:34:25.275+00	\N
913	1	guacadmin	172.18.0.2	2026-05-08 06:34:30.429+00	\N
914	1	guacadmin	172.18.0.2	2026-05-08 06:34:32.51+00	\N
915	1	guacadmin	172.18.0.2	2026-05-08 06:34:33.995+00	\N
916	1	guacadmin	172.18.0.2	2026-05-08 06:36:27.239+00	\N
917	1	guacadmin	172.18.0.2	2026-05-08 06:36:29.729+00	\N
918	1	guacadmin	172.18.0.2	2026-05-08 06:36:30.622+00	\N
919	1	guacadmin	172.18.0.2	2026-05-08 06:36:32.656+00	\N
920	1	guacadmin	172.18.0.2	2026-05-08 06:36:34.142+00	\N
921	1	guacadmin	172.18.0.2	2026-05-08 06:36:35.159+00	\N
922	1	guacadmin	172.18.0.2	2026-05-08 06:36:38.349+00	\N
923	1	guacadmin	172.18.0.2	2026-05-08 06:36:50.873+00	\N
924	1	guacadmin	172.18.0.2	2026-05-08 06:36:55.061+00	\N
925	1	guacadmin	172.18.0.2	2026-05-08 06:36:57.02+00	\N
926	1	guacadmin	172.18.0.2	2026-05-08 06:36:59.722+00	\N
927	1	guacadmin	172.18.0.2	2026-05-08 06:37:01.599+00	\N
928	1	guacadmin	172.18.0.2	2026-05-08 06:37:03.46+00	\N
929	1	guacadmin	172.18.0.2	2026-05-08 06:37:03.549+00	\N
930	1	guacadmin	172.18.0.2	2026-05-08 06:37:08.387+00	\N
931	1	guacadmin	172.18.0.2	2026-05-08 06:37:10.472+00	\N
932	1	guacadmin	172.18.0.2	2026-05-08 06:37:11.847+00	\N
933	1	guacadmin	172.18.0.2	2026-05-08 06:37:12.916+00	\N
934	1	guacadmin	172.18.0.2	2026-05-08 06:37:15.659+00	\N
935	1	guacadmin	172.18.0.2	2026-05-08 06:37:23.814+00	\N
936	1	guacadmin	172.18.0.2	2026-05-08 06:37:26.318+00	\N
937	1	guacadmin	172.18.0.2	2026-05-08 06:37:28.723+00	\N
938	1	guacadmin	172.18.0.2	2026-05-08 06:37:35.431+00	\N
939	1	guacadmin	172.18.0.2	2026-05-08 06:37:38.094+00	\N
940	1	guacadmin	172.18.0.2	2026-05-08 06:37:40.065+00	\N
941	1	guacadmin	172.18.0.2	2026-05-08 06:37:46.517+00	\N
942	1	guacadmin	172.18.0.2	2026-05-08 06:37:48.112+00	\N
943	1	guacadmin	172.18.0.2	2026-05-08 06:37:50.713+00	\N
944	1	guacadmin	172.18.0.2	2026-05-08 06:37:56.529+00	\N
\.


--
-- Data for Name: guacamole_user_password_history; Type: TABLE DATA; Schema: public; Owner: guacamole_user
--

COPY public.guacamole_user_password_history (password_history_id, user_id, password_hash, password_salt, password_date) FROM stdin;
\.


--
-- Data for Name: guacamole_user_permission; Type: TABLE DATA; Schema: public; Owner: guacamole_user
--

COPY public.guacamole_user_permission (entity_id, affected_user_id, permission) FROM stdin;
1	1	READ
1	1	UPDATE
1	1	ADMINISTER
\.


--
-- Name: guacamole_connection_connection_id_seq; Type: SEQUENCE SET; Schema: public; Owner: guacamole_user
--

SELECT pg_catalog.setval('public.guacamole_connection_connection_id_seq', 24, true);


--
-- Name: guacamole_connection_group_connection_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: guacamole_user
--

SELECT pg_catalog.setval('public.guacamole_connection_group_connection_group_id_seq', 1, false);


--
-- Name: guacamole_connection_history_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: guacamole_user
--

SELECT pg_catalog.setval('public.guacamole_connection_history_history_id_seq', 384, true);


--
-- Name: guacamole_entity_entity_id_seq; Type: SEQUENCE SET; Schema: public; Owner: guacamole_user
--

SELECT pg_catalog.setval('public.guacamole_entity_entity_id_seq', 1, true);


--
-- Name: guacamole_sharing_profile_sharing_profile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: guacamole_user
--

SELECT pg_catalog.setval('public.guacamole_sharing_profile_sharing_profile_id_seq', 1, false);


--
-- Name: guacamole_user_group_user_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: guacamole_user
--

SELECT pg_catalog.setval('public.guacamole_user_group_user_group_id_seq', 1, false);


--
-- Name: guacamole_user_history_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: guacamole_user
--

SELECT pg_catalog.setval('public.guacamole_user_history_history_id_seq', 944, true);


--
-- Name: guacamole_user_password_history_password_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: guacamole_user
--

SELECT pg_catalog.setval('public.guacamole_user_password_history_password_history_id_seq', 1, false);


--
-- Name: guacamole_user_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: guacamole_user
--

SELECT pg_catalog.setval('public.guacamole_user_user_id_seq', 1, true);


--
-- Name: guacamole_connection_group connection_group_name_parent; Type: CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_connection_group
    ADD CONSTRAINT connection_group_name_parent UNIQUE (connection_group_name, parent_id);


--
-- Name: guacamole_connection connection_name_parent; Type: CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_connection
    ADD CONSTRAINT connection_name_parent UNIQUE (connection_name, parent_id);


--
-- Name: guacamole_connection_attribute guacamole_connection_attribute_pkey; Type: CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_connection_attribute
    ADD CONSTRAINT guacamole_connection_attribute_pkey PRIMARY KEY (connection_id, attribute_name);


--
-- Name: guacamole_connection_group_attribute guacamole_connection_group_attribute_pkey; Type: CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_connection_group_attribute
    ADD CONSTRAINT guacamole_connection_group_attribute_pkey PRIMARY KEY (connection_group_id, attribute_name);


--
-- Name: guacamole_connection_group_permission guacamole_connection_group_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_connection_group_permission
    ADD CONSTRAINT guacamole_connection_group_permission_pkey PRIMARY KEY (entity_id, connection_group_id, permission);


--
-- Name: guacamole_connection_group guacamole_connection_group_pkey; Type: CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_connection_group
    ADD CONSTRAINT guacamole_connection_group_pkey PRIMARY KEY (connection_group_id);


--
-- Name: guacamole_connection_history guacamole_connection_history_pkey; Type: CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_connection_history
    ADD CONSTRAINT guacamole_connection_history_pkey PRIMARY KEY (history_id);


--
-- Name: guacamole_connection_parameter guacamole_connection_parameter_pkey; Type: CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_connection_parameter
    ADD CONSTRAINT guacamole_connection_parameter_pkey PRIMARY KEY (connection_id, parameter_name);


--
-- Name: guacamole_connection_permission guacamole_connection_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_connection_permission
    ADD CONSTRAINT guacamole_connection_permission_pkey PRIMARY KEY (entity_id, connection_id, permission);


--
-- Name: guacamole_connection guacamole_connection_pkey; Type: CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_connection
    ADD CONSTRAINT guacamole_connection_pkey PRIMARY KEY (connection_id);


--
-- Name: guacamole_entity guacamole_entity_name_scope; Type: CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_entity
    ADD CONSTRAINT guacamole_entity_name_scope UNIQUE (type, name);


--
-- Name: guacamole_entity guacamole_entity_pkey; Type: CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_entity
    ADD CONSTRAINT guacamole_entity_pkey PRIMARY KEY (entity_id);


--
-- Name: guacamole_sharing_profile_attribute guacamole_sharing_profile_attribute_pkey; Type: CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_sharing_profile_attribute
    ADD CONSTRAINT guacamole_sharing_profile_attribute_pkey PRIMARY KEY (sharing_profile_id, attribute_name);


--
-- Name: guacamole_sharing_profile_parameter guacamole_sharing_profile_parameter_pkey; Type: CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_sharing_profile_parameter
    ADD CONSTRAINT guacamole_sharing_profile_parameter_pkey PRIMARY KEY (sharing_profile_id, parameter_name);


--
-- Name: guacamole_sharing_profile_permission guacamole_sharing_profile_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_sharing_profile_permission
    ADD CONSTRAINT guacamole_sharing_profile_permission_pkey PRIMARY KEY (entity_id, sharing_profile_id, permission);


--
-- Name: guacamole_sharing_profile guacamole_sharing_profile_pkey; Type: CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_sharing_profile
    ADD CONSTRAINT guacamole_sharing_profile_pkey PRIMARY KEY (sharing_profile_id);


--
-- Name: guacamole_system_permission guacamole_system_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_system_permission
    ADD CONSTRAINT guacamole_system_permission_pkey PRIMARY KEY (entity_id, permission);


--
-- Name: guacamole_user_attribute guacamole_user_attribute_pkey; Type: CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_user_attribute
    ADD CONSTRAINT guacamole_user_attribute_pkey PRIMARY KEY (user_id, attribute_name);


--
-- Name: guacamole_user_group_attribute guacamole_user_group_attribute_pkey; Type: CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_user_group_attribute
    ADD CONSTRAINT guacamole_user_group_attribute_pkey PRIMARY KEY (user_group_id, attribute_name);


--
-- Name: guacamole_user_group_member guacamole_user_group_member_pkey; Type: CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_user_group_member
    ADD CONSTRAINT guacamole_user_group_member_pkey PRIMARY KEY (user_group_id, member_entity_id);


--
-- Name: guacamole_user_group_permission guacamole_user_group_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_user_group_permission
    ADD CONSTRAINT guacamole_user_group_permission_pkey PRIMARY KEY (entity_id, affected_user_group_id, permission);


--
-- Name: guacamole_user_group guacamole_user_group_pkey; Type: CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_user_group
    ADD CONSTRAINT guacamole_user_group_pkey PRIMARY KEY (user_group_id);


--
-- Name: guacamole_user_group guacamole_user_group_single_entity; Type: CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_user_group
    ADD CONSTRAINT guacamole_user_group_single_entity UNIQUE (entity_id);


--
-- Name: guacamole_user_history guacamole_user_history_pkey; Type: CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_user_history
    ADD CONSTRAINT guacamole_user_history_pkey PRIMARY KEY (history_id);


--
-- Name: guacamole_user_password_history guacamole_user_password_history_pkey; Type: CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_user_password_history
    ADD CONSTRAINT guacamole_user_password_history_pkey PRIMARY KEY (password_history_id);


--
-- Name: guacamole_user_permission guacamole_user_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_user_permission
    ADD CONSTRAINT guacamole_user_permission_pkey PRIMARY KEY (entity_id, affected_user_id, permission);


--
-- Name: guacamole_user guacamole_user_pkey; Type: CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_user
    ADD CONSTRAINT guacamole_user_pkey PRIMARY KEY (user_id);


--
-- Name: guacamole_user guacamole_user_single_entity; Type: CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_user
    ADD CONSTRAINT guacamole_user_single_entity UNIQUE (entity_id);


--
-- Name: guacamole_sharing_profile sharing_profile_name_primary; Type: CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_sharing_profile
    ADD CONSTRAINT sharing_profile_name_primary UNIQUE (sharing_profile_name, primary_connection_id);


--
-- Name: guacamole_connection_attribute_connection_id; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_connection_attribute_connection_id ON public.guacamole_connection_attribute USING btree (connection_id);


--
-- Name: guacamole_connection_group_attribute_connection_group_id; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_connection_group_attribute_connection_group_id ON public.guacamole_connection_group_attribute USING btree (connection_group_id);


--
-- Name: guacamole_connection_group_parent_id; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_connection_group_parent_id ON public.guacamole_connection_group USING btree (parent_id);


--
-- Name: guacamole_connection_group_permission_connection_group_id; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_connection_group_permission_connection_group_id ON public.guacamole_connection_group_permission USING btree (connection_group_id);


--
-- Name: guacamole_connection_group_permission_entity_id; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_connection_group_permission_entity_id ON public.guacamole_connection_group_permission USING btree (entity_id);


--
-- Name: guacamole_connection_history_connection_id; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_connection_history_connection_id ON public.guacamole_connection_history USING btree (connection_id);


--
-- Name: guacamole_connection_history_connection_id_start_date; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_connection_history_connection_id_start_date ON public.guacamole_connection_history USING btree (connection_id, start_date);


--
-- Name: guacamole_connection_history_end_date; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_connection_history_end_date ON public.guacamole_connection_history USING btree (end_date);


--
-- Name: guacamole_connection_history_sharing_profile_id; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_connection_history_sharing_profile_id ON public.guacamole_connection_history USING btree (sharing_profile_id);


--
-- Name: guacamole_connection_history_start_date; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_connection_history_start_date ON public.guacamole_connection_history USING btree (start_date);


--
-- Name: guacamole_connection_history_user_id; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_connection_history_user_id ON public.guacamole_connection_history USING btree (user_id);


--
-- Name: guacamole_connection_parameter_connection_id; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_connection_parameter_connection_id ON public.guacamole_connection_parameter USING btree (connection_id);


--
-- Name: guacamole_connection_parent_id; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_connection_parent_id ON public.guacamole_connection USING btree (parent_id);


--
-- Name: guacamole_connection_permission_connection_id; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_connection_permission_connection_id ON public.guacamole_connection_permission USING btree (connection_id);


--
-- Name: guacamole_connection_permission_entity_id; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_connection_permission_entity_id ON public.guacamole_connection_permission USING btree (entity_id);


--
-- Name: guacamole_sharing_profile_attribute_sharing_profile_id; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_sharing_profile_attribute_sharing_profile_id ON public.guacamole_sharing_profile_attribute USING btree (sharing_profile_id);


--
-- Name: guacamole_sharing_profile_parameter_sharing_profile_id; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_sharing_profile_parameter_sharing_profile_id ON public.guacamole_sharing_profile_parameter USING btree (sharing_profile_id);


--
-- Name: guacamole_sharing_profile_permission_entity_id; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_sharing_profile_permission_entity_id ON public.guacamole_sharing_profile_permission USING btree (entity_id);


--
-- Name: guacamole_sharing_profile_permission_sharing_profile_id; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_sharing_profile_permission_sharing_profile_id ON public.guacamole_sharing_profile_permission USING btree (sharing_profile_id);


--
-- Name: guacamole_sharing_profile_primary_connection_id; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_sharing_profile_primary_connection_id ON public.guacamole_sharing_profile USING btree (primary_connection_id);


--
-- Name: guacamole_system_permission_entity_id; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_system_permission_entity_id ON public.guacamole_system_permission USING btree (entity_id);


--
-- Name: guacamole_user_attribute_user_id; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_user_attribute_user_id ON public.guacamole_user_attribute USING btree (user_id);


--
-- Name: guacamole_user_group_attribute_user_group_id; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_user_group_attribute_user_group_id ON public.guacamole_user_group_attribute USING btree (user_group_id);


--
-- Name: guacamole_user_group_permission_affected_user_group_id; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_user_group_permission_affected_user_group_id ON public.guacamole_user_group_permission USING btree (affected_user_group_id);


--
-- Name: guacamole_user_group_permission_entity_id; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_user_group_permission_entity_id ON public.guacamole_user_group_permission USING btree (entity_id);


--
-- Name: guacamole_user_history_end_date; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_user_history_end_date ON public.guacamole_user_history USING btree (end_date);


--
-- Name: guacamole_user_history_start_date; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_user_history_start_date ON public.guacamole_user_history USING btree (start_date);


--
-- Name: guacamole_user_history_user_id; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_user_history_user_id ON public.guacamole_user_history USING btree (user_id);


--
-- Name: guacamole_user_history_user_id_start_date; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_user_history_user_id_start_date ON public.guacamole_user_history USING btree (user_id, start_date);


--
-- Name: guacamole_user_password_history_user_id; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_user_password_history_user_id ON public.guacamole_user_password_history USING btree (user_id);


--
-- Name: guacamole_user_permission_affected_user_id; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_user_permission_affected_user_id ON public.guacamole_user_permission USING btree (affected_user_id);


--
-- Name: guacamole_user_permission_entity_id; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_user_permission_entity_id ON public.guacamole_user_permission USING btree (entity_id);


--
-- Name: guacamole_connection_attribute guacamole_connection_attribute_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_connection_attribute
    ADD CONSTRAINT guacamole_connection_attribute_ibfk_1 FOREIGN KEY (connection_id) REFERENCES public.guacamole_connection(connection_id) ON DELETE CASCADE;


--
-- Name: guacamole_connection_group_attribute guacamole_connection_group_attribute_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_connection_group_attribute
    ADD CONSTRAINT guacamole_connection_group_attribute_ibfk_1 FOREIGN KEY (connection_group_id) REFERENCES public.guacamole_connection_group(connection_group_id) ON DELETE CASCADE;


--
-- Name: guacamole_connection_group guacamole_connection_group_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_connection_group
    ADD CONSTRAINT guacamole_connection_group_ibfk_1 FOREIGN KEY (parent_id) REFERENCES public.guacamole_connection_group(connection_group_id) ON DELETE CASCADE;


--
-- Name: guacamole_connection_group_permission guacamole_connection_group_permission_entity; Type: FK CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_connection_group_permission
    ADD CONSTRAINT guacamole_connection_group_permission_entity FOREIGN KEY (entity_id) REFERENCES public.guacamole_entity(entity_id) ON DELETE CASCADE;


--
-- Name: guacamole_connection_group_permission guacamole_connection_group_permission_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_connection_group_permission
    ADD CONSTRAINT guacamole_connection_group_permission_ibfk_1 FOREIGN KEY (connection_group_id) REFERENCES public.guacamole_connection_group(connection_group_id) ON DELETE CASCADE;


--
-- Name: guacamole_connection_history guacamole_connection_history_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_connection_history
    ADD CONSTRAINT guacamole_connection_history_ibfk_1 FOREIGN KEY (user_id) REFERENCES public.guacamole_user(user_id) ON DELETE SET NULL;


--
-- Name: guacamole_connection_history guacamole_connection_history_ibfk_2; Type: FK CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_connection_history
    ADD CONSTRAINT guacamole_connection_history_ibfk_2 FOREIGN KEY (connection_id) REFERENCES public.guacamole_connection(connection_id) ON DELETE SET NULL;


--
-- Name: guacamole_connection_history guacamole_connection_history_ibfk_3; Type: FK CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_connection_history
    ADD CONSTRAINT guacamole_connection_history_ibfk_3 FOREIGN KEY (sharing_profile_id) REFERENCES public.guacamole_sharing_profile(sharing_profile_id) ON DELETE SET NULL;


--
-- Name: guacamole_connection guacamole_connection_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_connection
    ADD CONSTRAINT guacamole_connection_ibfk_1 FOREIGN KEY (parent_id) REFERENCES public.guacamole_connection_group(connection_group_id) ON DELETE CASCADE;


--
-- Name: guacamole_connection_parameter guacamole_connection_parameter_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_connection_parameter
    ADD CONSTRAINT guacamole_connection_parameter_ibfk_1 FOREIGN KEY (connection_id) REFERENCES public.guacamole_connection(connection_id) ON DELETE CASCADE;


--
-- Name: guacamole_connection_permission guacamole_connection_permission_entity; Type: FK CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_connection_permission
    ADD CONSTRAINT guacamole_connection_permission_entity FOREIGN KEY (entity_id) REFERENCES public.guacamole_entity(entity_id) ON DELETE CASCADE;


--
-- Name: guacamole_connection_permission guacamole_connection_permission_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_connection_permission
    ADD CONSTRAINT guacamole_connection_permission_ibfk_1 FOREIGN KEY (connection_id) REFERENCES public.guacamole_connection(connection_id) ON DELETE CASCADE;


--
-- Name: guacamole_sharing_profile_attribute guacamole_sharing_profile_attribute_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_sharing_profile_attribute
    ADD CONSTRAINT guacamole_sharing_profile_attribute_ibfk_1 FOREIGN KEY (sharing_profile_id) REFERENCES public.guacamole_sharing_profile(sharing_profile_id) ON DELETE CASCADE;


--
-- Name: guacamole_sharing_profile guacamole_sharing_profile_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_sharing_profile
    ADD CONSTRAINT guacamole_sharing_profile_ibfk_1 FOREIGN KEY (primary_connection_id) REFERENCES public.guacamole_connection(connection_id) ON DELETE CASCADE;


--
-- Name: guacamole_sharing_profile_parameter guacamole_sharing_profile_parameter_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_sharing_profile_parameter
    ADD CONSTRAINT guacamole_sharing_profile_parameter_ibfk_1 FOREIGN KEY (sharing_profile_id) REFERENCES public.guacamole_sharing_profile(sharing_profile_id) ON DELETE CASCADE;


--
-- Name: guacamole_sharing_profile_permission guacamole_sharing_profile_permission_entity; Type: FK CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_sharing_profile_permission
    ADD CONSTRAINT guacamole_sharing_profile_permission_entity FOREIGN KEY (entity_id) REFERENCES public.guacamole_entity(entity_id) ON DELETE CASCADE;


--
-- Name: guacamole_sharing_profile_permission guacamole_sharing_profile_permission_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_sharing_profile_permission
    ADD CONSTRAINT guacamole_sharing_profile_permission_ibfk_1 FOREIGN KEY (sharing_profile_id) REFERENCES public.guacamole_sharing_profile(sharing_profile_id) ON DELETE CASCADE;


--
-- Name: guacamole_system_permission guacamole_system_permission_entity; Type: FK CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_system_permission
    ADD CONSTRAINT guacamole_system_permission_entity FOREIGN KEY (entity_id) REFERENCES public.guacamole_entity(entity_id) ON DELETE CASCADE;


--
-- Name: guacamole_user_attribute guacamole_user_attribute_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_user_attribute
    ADD CONSTRAINT guacamole_user_attribute_ibfk_1 FOREIGN KEY (user_id) REFERENCES public.guacamole_user(user_id) ON DELETE CASCADE;


--
-- Name: guacamole_user guacamole_user_entity; Type: FK CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_user
    ADD CONSTRAINT guacamole_user_entity FOREIGN KEY (entity_id) REFERENCES public.guacamole_entity(entity_id) ON DELETE CASCADE;


--
-- Name: guacamole_user_group_attribute guacamole_user_group_attribute_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_user_group_attribute
    ADD CONSTRAINT guacamole_user_group_attribute_ibfk_1 FOREIGN KEY (user_group_id) REFERENCES public.guacamole_user_group(user_group_id) ON DELETE CASCADE;


--
-- Name: guacamole_user_group guacamole_user_group_entity; Type: FK CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_user_group
    ADD CONSTRAINT guacamole_user_group_entity FOREIGN KEY (entity_id) REFERENCES public.guacamole_entity(entity_id) ON DELETE CASCADE;


--
-- Name: guacamole_user_group_member guacamole_user_group_member_entity; Type: FK CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_user_group_member
    ADD CONSTRAINT guacamole_user_group_member_entity FOREIGN KEY (member_entity_id) REFERENCES public.guacamole_entity(entity_id) ON DELETE CASCADE;


--
-- Name: guacamole_user_group_member guacamole_user_group_member_parent; Type: FK CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_user_group_member
    ADD CONSTRAINT guacamole_user_group_member_parent FOREIGN KEY (user_group_id) REFERENCES public.guacamole_user_group(user_group_id) ON DELETE CASCADE;


--
-- Name: guacamole_user_group_permission guacamole_user_group_permission_affected_user_group; Type: FK CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_user_group_permission
    ADD CONSTRAINT guacamole_user_group_permission_affected_user_group FOREIGN KEY (affected_user_group_id) REFERENCES public.guacamole_user_group(user_group_id) ON DELETE CASCADE;


--
-- Name: guacamole_user_group_permission guacamole_user_group_permission_entity; Type: FK CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_user_group_permission
    ADD CONSTRAINT guacamole_user_group_permission_entity FOREIGN KEY (entity_id) REFERENCES public.guacamole_entity(entity_id) ON DELETE CASCADE;


--
-- Name: guacamole_user_history guacamole_user_history_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_user_history
    ADD CONSTRAINT guacamole_user_history_ibfk_1 FOREIGN KEY (user_id) REFERENCES public.guacamole_user(user_id) ON DELETE SET NULL;


--
-- Name: guacamole_user_password_history guacamole_user_password_history_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_user_password_history
    ADD CONSTRAINT guacamole_user_password_history_ibfk_1 FOREIGN KEY (user_id) REFERENCES public.guacamole_user(user_id) ON DELETE CASCADE;


--
-- Name: guacamole_user_permission guacamole_user_permission_entity; Type: FK CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_user_permission
    ADD CONSTRAINT guacamole_user_permission_entity FOREIGN KEY (entity_id) REFERENCES public.guacamole_entity(entity_id) ON DELETE CASCADE;


--
-- Name: guacamole_user_permission guacamole_user_permission_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_user_permission
    ADD CONSTRAINT guacamole_user_permission_ibfk_1 FOREIGN KEY (affected_user_id) REFERENCES public.guacamole_user(user_id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

