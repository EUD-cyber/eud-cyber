--
-- PostgreSQL database dump
--

-- Dumped from database version 15.2
-- Dumped by pg_dump version 15.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: guacamole_connection_group_type; Type: TYPE; Schema: public; Owner: guacamole_user
--

CREATE TYPE public.guacamole_connection_group_type AS ENUM (
    'ORGANIZATIONAL',
    'BALANCING'
);


ALTER TYPE public.guacamole_connection_group_type OWNER TO guacamole_user;

--
-- Name: guacamole_entity_type; Type: TYPE; Schema: public; Owner: guacamole_user
--

CREATE TYPE public.guacamole_entity_type AS ENUM (
    'USER',
    'USER_GROUP'
);


ALTER TYPE public.guacamole_entity_type OWNER TO guacamole_user;

--
-- Name: guacamole_object_permission_type; Type: TYPE; Schema: public; Owner: guacamole_user
--

CREATE TYPE public.guacamole_object_permission_type AS ENUM (
    'READ',
    'UPDATE',
    'DELETE',
    'ADMINISTER'
);


ALTER TYPE public.guacamole_object_permission_type OWNER TO guacamole_user;

--
-- Name: guacamole_proxy_encryption_method; Type: TYPE; Schema: public; Owner: guacamole_user
--

CREATE TYPE public.guacamole_proxy_encryption_method AS ENUM (
    'NONE',
    'SSL'
);


ALTER TYPE public.guacamole_proxy_encryption_method OWNER TO guacamole_user;

--
-- Name: guacamole_system_permission_type; Type: TYPE; Schema: public; Owner: guacamole_user
--

CREATE TYPE public.guacamole_system_permission_type AS ENUM (
    'CREATE_CONNECTION',
    'CREATE_CONNECTION_GROUP',
    'CREATE_SHARING_PROFILE',
    'CREATE_USER',
    'CREATE_USER_GROUP',
    'AUDIT',
    'ADMINISTER'
);


ALTER TYPE public.guacamole_system_permission_type OWNER TO guacamole_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: guacamole_connection; Type: TABLE; Schema: public; Owner: guacamole_user
--

CREATE TABLE public.guacamole_connection (
    connection_id integer NOT NULL,
    connection_name character varying(128) NOT NULL,
    parent_id integer,
    protocol character varying(32) NOT NULL,
    max_connections integer,
    max_connections_per_user integer,
    connection_weight integer,
    failover_only boolean DEFAULT false NOT NULL,
    proxy_port integer,
    proxy_hostname character varying(512),
    proxy_encryption_method public.guacamole_proxy_encryption_method
);


ALTER TABLE public.guacamole_connection OWNER TO guacamole_user;

--
-- Name: guacamole_connection_attribute; Type: TABLE; Schema: public; Owner: guacamole_user
--

CREATE TABLE public.guacamole_connection_attribute (
    connection_id integer NOT NULL,
    attribute_name character varying(128) NOT NULL,
    attribute_value character varying(4096) NOT NULL
);


ALTER TABLE public.guacamole_connection_attribute OWNER TO guacamole_user;

--
-- Name: guacamole_connection_connection_id_seq; Type: SEQUENCE; Schema: public; Owner: guacamole_user
--

CREATE SEQUENCE public.guacamole_connection_connection_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.guacamole_connection_connection_id_seq OWNER TO guacamole_user;

--
-- Name: guacamole_connection_connection_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: guacamole_user
--

ALTER SEQUENCE public.guacamole_connection_connection_id_seq OWNED BY public.guacamole_connection.connection_id;


--
-- Name: guacamole_connection_group; Type: TABLE; Schema: public; Owner: guacamole_user
--

CREATE TABLE public.guacamole_connection_group (
    connection_group_id integer NOT NULL,
    parent_id integer,
    connection_group_name character varying(128) NOT NULL,
    type public.guacamole_connection_group_type DEFAULT 'ORGANIZATIONAL'::public.guacamole_connection_group_type NOT NULL,
    max_connections integer,
    max_connections_per_user integer,
    enable_session_affinity boolean DEFAULT false NOT NULL
);


ALTER TABLE public.guacamole_connection_group OWNER TO guacamole_user;

--
-- Name: guacamole_connection_group_attribute; Type: TABLE; Schema: public; Owner: guacamole_user
--

CREATE TABLE public.guacamole_connection_group_attribute (
    connection_group_id integer NOT NULL,
    attribute_name character varying(128) NOT NULL,
    attribute_value character varying(4096) NOT NULL
);


ALTER TABLE public.guacamole_connection_group_attribute OWNER TO guacamole_user;

--
-- Name: guacamole_connection_group_connection_group_id_seq; Type: SEQUENCE; Schema: public; Owner: guacamole_user
--

CREATE SEQUENCE public.guacamole_connection_group_connection_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.guacamole_connection_group_connection_group_id_seq OWNER TO guacamole_user;

--
-- Name: guacamole_connection_group_connection_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: guacamole_user
--

ALTER SEQUENCE public.guacamole_connection_group_connection_group_id_seq OWNED BY public.guacamole_connection_group.connection_group_id;


--
-- Name: guacamole_connection_group_permission; Type: TABLE; Schema: public; Owner: guacamole_user
--

CREATE TABLE public.guacamole_connection_group_permission (
    entity_id integer NOT NULL,
    connection_group_id integer NOT NULL,
    permission public.guacamole_object_permission_type NOT NULL
);


ALTER TABLE public.guacamole_connection_group_permission OWNER TO guacamole_user;

--
-- Name: guacamole_connection_history; Type: TABLE; Schema: public; Owner: guacamole_user
--

CREATE TABLE public.guacamole_connection_history (
    history_id integer NOT NULL,
    user_id integer,
    username character varying(128) NOT NULL,
    remote_host character varying(256) DEFAULT NULL::character varying,
    connection_id integer,
    connection_name character varying(128) NOT NULL,
    sharing_profile_id integer,
    sharing_profile_name character varying(128) DEFAULT NULL::character varying,
    start_date timestamp with time zone NOT NULL,
    end_date timestamp with time zone
);


ALTER TABLE public.guacamole_connection_history OWNER TO guacamole_user;

--
-- Name: guacamole_connection_history_history_id_seq; Type: SEQUENCE; Schema: public; Owner: guacamole_user
--

CREATE SEQUENCE public.guacamole_connection_history_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.guacamole_connection_history_history_id_seq OWNER TO guacamole_user;

--
-- Name: guacamole_connection_history_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: guacamole_user
--

ALTER SEQUENCE public.guacamole_connection_history_history_id_seq OWNED BY public.guacamole_connection_history.history_id;


--
-- Name: guacamole_connection_parameter; Type: TABLE; Schema: public; Owner: guacamole_user
--

CREATE TABLE public.guacamole_connection_parameter (
    connection_id integer NOT NULL,
    parameter_name character varying(128) NOT NULL,
    parameter_value character varying(4096) NOT NULL
);


ALTER TABLE public.guacamole_connection_parameter OWNER TO guacamole_user;

--
-- Name: guacamole_connection_permission; Type: TABLE; Schema: public; Owner: guacamole_user
--

CREATE TABLE public.guacamole_connection_permission (
    entity_id integer NOT NULL,
    connection_id integer NOT NULL,
    permission public.guacamole_object_permission_type NOT NULL
);


ALTER TABLE public.guacamole_connection_permission OWNER TO guacamole_user;

--
-- Name: guacamole_entity; Type: TABLE; Schema: public; Owner: guacamole_user
--

CREATE TABLE public.guacamole_entity (
    entity_id integer NOT NULL,
    name character varying(128) NOT NULL,
    type public.guacamole_entity_type NOT NULL
);


ALTER TABLE public.guacamole_entity OWNER TO guacamole_user;

--
-- Name: guacamole_entity_entity_id_seq; Type: SEQUENCE; Schema: public; Owner: guacamole_user
--

CREATE SEQUENCE public.guacamole_entity_entity_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.guacamole_entity_entity_id_seq OWNER TO guacamole_user;

--
-- Name: guacamole_entity_entity_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: guacamole_user
--

ALTER SEQUENCE public.guacamole_entity_entity_id_seq OWNED BY public.guacamole_entity.entity_id;


--
-- Name: guacamole_sharing_profile; Type: TABLE; Schema: public; Owner: guacamole_user
--

CREATE TABLE public.guacamole_sharing_profile (
    sharing_profile_id integer NOT NULL,
    sharing_profile_name character varying(128) NOT NULL,
    primary_connection_id integer NOT NULL
);


ALTER TABLE public.guacamole_sharing_profile OWNER TO guacamole_user;

--
-- Name: guacamole_sharing_profile_attribute; Type: TABLE; Schema: public; Owner: guacamole_user
--

CREATE TABLE public.guacamole_sharing_profile_attribute (
    sharing_profile_id integer NOT NULL,
    attribute_name character varying(128) NOT NULL,
    attribute_value character varying(4096) NOT NULL
);


ALTER TABLE public.guacamole_sharing_profile_attribute OWNER TO guacamole_user;

--
-- Name: guacamole_sharing_profile_parameter; Type: TABLE; Schema: public; Owner: guacamole_user
--

CREATE TABLE public.guacamole_sharing_profile_parameter (
    sharing_profile_id integer NOT NULL,
    parameter_name character varying(128) NOT NULL,
    parameter_value character varying(4096) NOT NULL
);


ALTER TABLE public.guacamole_sharing_profile_parameter OWNER TO guacamole_user;

--
-- Name: guacamole_sharing_profile_permission; Type: TABLE; Schema: public; Owner: guacamole_user
--

CREATE TABLE public.guacamole_sharing_profile_permission (
    entity_id integer NOT NULL,
    sharing_profile_id integer NOT NULL,
    permission public.guacamole_object_permission_type NOT NULL
);


ALTER TABLE public.guacamole_sharing_profile_permission OWNER TO guacamole_user;

--
-- Name: guacamole_sharing_profile_sharing_profile_id_seq; Type: SEQUENCE; Schema: public; Owner: guacamole_user
--

CREATE SEQUENCE public.guacamole_sharing_profile_sharing_profile_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.guacamole_sharing_profile_sharing_profile_id_seq OWNER TO guacamole_user;

--
-- Name: guacamole_sharing_profile_sharing_profile_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: guacamole_user
--

ALTER SEQUENCE public.guacamole_sharing_profile_sharing_profile_id_seq OWNED BY public.guacamole_sharing_profile.sharing_profile_id;


--
-- Name: guacamole_system_permission; Type: TABLE; Schema: public; Owner: guacamole_user
--

CREATE TABLE public.guacamole_system_permission (
    entity_id integer NOT NULL,
    permission public.guacamole_system_permission_type NOT NULL
);


ALTER TABLE public.guacamole_system_permission OWNER TO guacamole_user;

--
-- Name: guacamole_user; Type: TABLE; Schema: public; Owner: guacamole_user
--

CREATE TABLE public.guacamole_user (
    user_id integer NOT NULL,
    entity_id integer NOT NULL,
    password_hash bytea NOT NULL,
    password_salt bytea,
    password_date timestamp with time zone NOT NULL,
    disabled boolean DEFAULT false NOT NULL,
    expired boolean DEFAULT false NOT NULL,
    access_window_start time without time zone,
    access_window_end time without time zone,
    valid_from date,
    valid_until date,
    timezone character varying(64),
    full_name character varying(256),
    email_address character varying(256),
    organization character varying(256),
    organizational_role character varying(256)
);


ALTER TABLE public.guacamole_user OWNER TO guacamole_user;

--
-- Name: guacamole_user_attribute; Type: TABLE; Schema: public; Owner: guacamole_user
--

CREATE TABLE public.guacamole_user_attribute (
    user_id integer NOT NULL,
    attribute_name character varying(128) NOT NULL,
    attribute_value character varying(4096) NOT NULL
);


ALTER TABLE public.guacamole_user_attribute OWNER TO guacamole_user;

--
-- Name: guacamole_user_group; Type: TABLE; Schema: public; Owner: guacamole_user
--

CREATE TABLE public.guacamole_user_group (
    user_group_id integer NOT NULL,
    entity_id integer NOT NULL,
    disabled boolean DEFAULT false NOT NULL
);


ALTER TABLE public.guacamole_user_group OWNER TO guacamole_user;

--
-- Name: guacamole_user_group_attribute; Type: TABLE; Schema: public; Owner: guacamole_user
--

CREATE TABLE public.guacamole_user_group_attribute (
    user_group_id integer NOT NULL,
    attribute_name character varying(128) NOT NULL,
    attribute_value character varying(4096) NOT NULL
);


ALTER TABLE public.guacamole_user_group_attribute OWNER TO guacamole_user;

--
-- Name: guacamole_user_group_member; Type: TABLE; Schema: public; Owner: guacamole_user
--

CREATE TABLE public.guacamole_user_group_member (
    user_group_id integer NOT NULL,
    member_entity_id integer NOT NULL
);


ALTER TABLE public.guacamole_user_group_member OWNER TO guacamole_user;

--
-- Name: guacamole_user_group_permission; Type: TABLE; Schema: public; Owner: guacamole_user
--

CREATE TABLE public.guacamole_user_group_permission (
    entity_id integer NOT NULL,
    affected_user_group_id integer NOT NULL,
    permission public.guacamole_object_permission_type NOT NULL
);


ALTER TABLE public.guacamole_user_group_permission OWNER TO guacamole_user;

--
-- Name: guacamole_user_group_user_group_id_seq; Type: SEQUENCE; Schema: public; Owner: guacamole_user
--

CREATE SEQUENCE public.guacamole_user_group_user_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.guacamole_user_group_user_group_id_seq OWNER TO guacamole_user;

--
-- Name: guacamole_user_group_user_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: guacamole_user
--

ALTER SEQUENCE public.guacamole_user_group_user_group_id_seq OWNED BY public.guacamole_user_group.user_group_id;


--
-- Name: guacamole_user_history; Type: TABLE; Schema: public; Owner: guacamole_user
--

CREATE TABLE public.guacamole_user_history (
    history_id integer NOT NULL,
    user_id integer,
    username character varying(128) NOT NULL,
    remote_host character varying(256) DEFAULT NULL::character varying,
    start_date timestamp with time zone NOT NULL,
    end_date timestamp with time zone
);


ALTER TABLE public.guacamole_user_history OWNER TO guacamole_user;

--
-- Name: guacamole_user_history_history_id_seq; Type: SEQUENCE; Schema: public; Owner: guacamole_user
--

CREATE SEQUENCE public.guacamole_user_history_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.guacamole_user_history_history_id_seq OWNER TO guacamole_user;

--
-- Name: guacamole_user_history_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: guacamole_user
--

ALTER SEQUENCE public.guacamole_user_history_history_id_seq OWNED BY public.guacamole_user_history.history_id;


--
-- Name: guacamole_user_password_history; Type: TABLE; Schema: public; Owner: guacamole_user
--

CREATE TABLE public.guacamole_user_password_history (
    password_history_id integer NOT NULL,
    user_id integer NOT NULL,
    password_hash bytea NOT NULL,
    password_salt bytea,
    password_date timestamp with time zone NOT NULL
);


ALTER TABLE public.guacamole_user_password_history OWNER TO guacamole_user;

--
-- Name: guacamole_user_password_history_password_history_id_seq; Type: SEQUENCE; Schema: public; Owner: guacamole_user
--

CREATE SEQUENCE public.guacamole_user_password_history_password_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.guacamole_user_password_history_password_history_id_seq OWNER TO guacamole_user;

--
-- Name: guacamole_user_password_history_password_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: guacamole_user
--

ALTER SEQUENCE public.guacamole_user_password_history_password_history_id_seq OWNED BY public.guacamole_user_password_history.password_history_id;


--
-- Name: guacamole_user_permission; Type: TABLE; Schema: public; Owner: guacamole_user
--

CREATE TABLE public.guacamole_user_permission (
    entity_id integer NOT NULL,
    affected_user_id integer NOT NULL,
    permission public.guacamole_object_permission_type NOT NULL
);


ALTER TABLE public.guacamole_user_permission OWNER TO guacamole_user;

--
-- Name: guacamole_user_user_id_seq; Type: SEQUENCE; Schema: public; Owner: guacamole_user
--

CREATE SEQUENCE public.guacamole_user_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.guacamole_user_user_id_seq OWNER TO guacamole_user;

--
-- Name: guacamole_user_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: guacamole_user
--

ALTER SEQUENCE public.guacamole_user_user_id_seq OWNED BY public.guacamole_user.user_id;


--
-- Name: guacamole_connection connection_id; Type: DEFAULT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_connection ALTER COLUMN connection_id SET DEFAULT nextval('public.guacamole_connection_connection_id_seq'::regclass);


--
-- Name: guacamole_connection_group connection_group_id; Type: DEFAULT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_connection_group ALTER COLUMN connection_group_id SET DEFAULT nextval('public.guacamole_connection_group_connection_group_id_seq'::regclass);


--
-- Name: guacamole_connection_history history_id; Type: DEFAULT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_connection_history ALTER COLUMN history_id SET DEFAULT nextval('public.guacamole_connection_history_history_id_seq'::regclass);


--
-- Name: guacamole_entity entity_id; Type: DEFAULT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_entity ALTER COLUMN entity_id SET DEFAULT nextval('public.guacamole_entity_entity_id_seq'::regclass);


--
-- Name: guacamole_sharing_profile sharing_profile_id; Type: DEFAULT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_sharing_profile ALTER COLUMN sharing_profile_id SET DEFAULT nextval('public.guacamole_sharing_profile_sharing_profile_id_seq'::regclass);


--
-- Name: guacamole_user user_id; Type: DEFAULT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_user ALTER COLUMN user_id SET DEFAULT nextval('public.guacamole_user_user_id_seq'::regclass);


--
-- Name: guacamole_user_group user_group_id; Type: DEFAULT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_user_group ALTER COLUMN user_group_id SET DEFAULT nextval('public.guacamole_user_group_user_group_id_seq'::regclass);


--
-- Name: guacamole_user_history history_id; Type: DEFAULT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_user_history ALTER COLUMN history_id SET DEFAULT nextval('public.guacamole_user_history_history_id_seq'::regclass);


--
-- Name: guacamole_user_password_history password_history_id; Type: DEFAULT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_user_password_history ALTER COLUMN password_history_id SET DEFAULT nextval('public.guacamole_user_password_history_password_history_id_seq'::regclass);


--
-- Data for Name: guacamole_connection; Type: TABLE DATA; Schema: public; Owner: guacamole_user
--

COPY public.guacamole_connection (connection_id, connection_name, parent_id, protocol, max_connections, max_connections_per_user, connection_weight, failover_only, proxy_port, proxy_hostname, proxy_encryption_method) FROM stdin;
1	VULNSRV01	\N	ssh	\N	\N	\N	f	\N	\N	\N
2	KALI01	\N	ssh	\N	\N	\N	f	\N	\N	\N
5	VULNSRV02	\N	ssh	\N	\N	\N	f	\N	\N	\N
6	KALI01-VNC	\N	vnc	\N	\N	\N	f	\N	\N	\N
7	WIN2025	\N	rdp	\N	\N	\N	f	\N	\N	\N
4	WAZUH	\N	ssh	\N	\N	\N	f	\N	\N	\N
8	OPNSENSE	\N	ssh	\N	\N	\N	f	\N	\N	\N
\.


--
-- Data for Name: guacamole_connection_attribute; Type: TABLE DATA; Schema: public; Owner: guacamole_user
--

COPY public.guacamole_connection_attribute (connection_id, attribute_name, attribute_value) FROM stdin;
\.


--
-- Data for Name: guacamole_connection_group; Type: TABLE DATA; Schema: public; Owner: guacamole_user
--

COPY public.guacamole_connection_group (connection_group_id, parent_id, connection_group_name, type, max_connections, max_connections_per_user, enable_session_affinity) FROM stdin;
\.


--
-- Data for Name: guacamole_connection_group_attribute; Type: TABLE DATA; Schema: public; Owner: guacamole_user
--

COPY public.guacamole_connection_group_attribute (connection_group_id, attribute_name, attribute_value) FROM stdin;
\.


--
-- Data for Name: guacamole_connection_group_permission; Type: TABLE DATA; Schema: public; Owner: guacamole_user
--

COPY public.guacamole_connection_group_permission (entity_id, connection_group_id, permission) FROM stdin;
\.


--
-- Data for Name: guacamole_connection_history; Type: TABLE DATA; Schema: public; Owner: guacamole_user
--

COPY public.guacamole_connection_history (history_id, user_id, username, remote_host, connection_id, connection_name, sharing_profile_id, sharing_profile_name, start_date, end_date) FROM stdin;
1	1	guacadmin	10.10.100.1	1	VULNSRV01	\N	\N	2025-12-23 09:54:37.943+00	2025-12-23 09:54:38.095+00
2	1	guacadmin	10.10.100.1	1	VULNSRV01	\N	\N	2025-12-23 09:54:39.987+00	2025-12-23 09:54:40.031+00
3	1	guacadmin	10.10.100.1	1	VULNSRV01	\N	\N	2025-12-23 09:58:27.989+00	2025-12-23 09:58:28.402+00
4	1	guacadmin	10.10.100.1	1	VULNSRV01	\N	\N	2025-12-23 09:58:29.801+00	2025-12-23 09:58:29.943+00
5	1	guacadmin	10.10.100.1	1	VULNSRV01	\N	\N	2025-12-23 09:58:31.674+00	2025-12-23 09:58:31.808+00
6	1	guacadmin	10.10.100.1	1	VULNSRV01	\N	\N	2025-12-23 10:03:07.655+00	2025-12-23 10:03:07.837+00
7	1	guacadmin	10.10.100.1	1	VULNSRV01	\N	\N	2025-12-23 10:03:10.087+00	2025-12-23 10:03:10.214+00
8	1	guacadmin	10.10.100.1	1	VULNSRV01	\N	\N	2025-12-23 10:07:31.083+00	2025-12-23 10:07:31.309+00
9	1	guacadmin	10.10.100.1	1	VULNSRV01	\N	\N	2025-12-23 10:07:33.035+00	2025-12-23 10:07:33.168+00
10	1	guacadmin	10.10.100.1	1	VULNSRV01	\N	\N	2025-12-23 10:08:58.922+00	2025-12-23 10:12:06.647+00
11	1	guacadmin	10.10.100.1	2	KALI01	\N	\N	2025-12-23 10:14:52.55+00	2025-12-23 10:14:59.079+00
14	1	guacadmin	10.10.100.1	2	KALI01	\N	\N	2025-12-23 10:15:51.479+00	2025-12-23 10:21:18.361+00
15	1	guacadmin	10.10.100.1	2	KALI01	\N	\N	2025-12-23 11:57:08.172+00	2025-12-23 11:57:21.62+00
16	1	guacadmin	10.10.100.1	1	VULNSRV01	\N	\N	2025-12-23 11:57:23.939+00	2025-12-23 11:57:30.424+00
17	1	guacadmin	10.10.100.1	4	WAZUH	\N	\N	2025-12-23 12:27:03.127+00	2025-12-23 12:30:32.764+00
12	1	guacadmin	10.10.100.1	\N	KALI01_VNC	\N	\N	2025-12-23 10:15:46.761+00	2025-12-23 10:15:46.842+00
13	1	guacadmin	10.10.100.1	\N	KALI01_VNC	\N	\N	2025-12-23 10:15:48.121+00	2025-12-23 10:15:48.151+00
18	1	guacadmin	10.10.100.1	2	KALI01	\N	\N	2025-12-23 12:35:30.41+00	2025-12-23 12:36:38.142+00
19	1	guacadmin	10.10.100.1	2	KALI01	\N	\N	2025-12-23 12:37:45.155+00	2025-12-23 12:41:29.815+00
20	1	guacadmin	10.10.100.1	2	KALI01	\N	\N	2025-12-23 12:42:32.707+00	2025-12-23 12:44:08.313+00
21	1	guacadmin	10.10.100.1	2	KALI01	\N	\N	2025-12-23 12:44:31.614+00	2025-12-23 12:48:12.895+00
22	1	guacadmin	10.10.100.1	2	KALI01	\N	\N	2025-12-23 12:48:27.201+00	2025-12-23 12:48:29.355+00
23	1	guacadmin	10.10.100.1	2	KALI01	\N	\N	2025-12-23 12:48:32.914+00	2025-12-23 12:51:44.848+00
24	1	guacadmin	10.10.100.1	2	KALI01	\N	\N	2025-12-23 12:56:40.734+00	2025-12-23 13:02:50.466+00
25	1	guacadmin	10.10.100.1	2	KALI01	\N	\N	2025-12-23 13:04:38.66+00	2025-12-23 13:09:51.153+00
26	1	guacadmin	10.10.100.1	2	KALI01	\N	\N	2025-12-23 19:01:27.308+00	2025-12-23 19:01:37.392+00
27	1	guacadmin	10.10.100.1	2	KALI01	\N	\N	2025-12-23 19:01:40.415+00	2025-12-23 19:28:53.316+00
28	1	guacadmin	10.10.100.1	4	WAZUH	\N	\N	2025-12-23 19:34:14.965+00	2025-12-23 19:37:50.38+00
29	1	guacadmin	10.10.100.1	4	WAZUH	\N	\N	2025-12-23 19:37:54.863+00	2025-12-23 19:38:06.537+00
30	1	guacadmin	10.10.100.1	2	KALI01	\N	\N	2025-12-23 19:38:09.952+00	2025-12-23 19:46:46.285+00
31	1	guacadmin	10.10.100.1	6	KALI01-VNC	\N	\N	2025-12-23 19:47:47.3+00	2025-12-23 19:49:11.136+00
32	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-01-07 09:52:45.401+00	2026-01-07 10:03:15.203+00
33	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-01-07 10:04:49.929+00	2026-01-07 10:07:45.555+00
34	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-01-08 07:39:48.239+00	2026-01-08 07:39:54.65+00
36	1	guacadmin	172.18.0.5	2	KALI01	\N	\N	2026-01-08 09:39:25.243+00	2026-01-08 09:39:26.774+00
41	1	guacadmin	172.18.0.5	4	WAZUH	\N	\N	2026-01-08 09:39:59.806+00	2026-01-08 09:40:06.343+00
40	1	guacadmin	172.18.0.5	5	VULNSRV02	\N	\N	2026-01-08 09:39:55.398+00	2026-01-08 09:40:07.364+00
39	1	guacadmin	172.18.0.5	1	VULNSRV01	\N	\N	2026-01-08 09:39:50.694+00	2026-01-08 09:40:08.187+00
35	1	guacadmin	172.18.0.5	7	WIN2025	\N	\N	2026-01-08 09:11:11.755+00	2026-01-08 09:40:08.874+00
38	1	guacadmin	172.18.0.5	8	OPNSENSE	\N	\N	2026-01-08 09:39:46.079+00	2026-01-08 09:40:08.961+00
37	1	guacadmin	172.18.0.5	6	KALI01-VNC	\N	\N	2026-01-08 09:39:38.431+00	2026-01-08 09:40:09.771+00
42	1	guacadmin	172.18.0.5	7	WIN2025	\N	\N	2026-01-08 09:40:04.672+00	2026-01-08 09:40:21.013+00
\.


--
-- Data for Name: guacamole_connection_parameter; Type: TABLE DATA; Schema: public; Owner: guacamole_user
--

COPY public.guacamole_connection_parameter (connection_id, parameter_name, parameter_value) FROM stdin;
1	hostname	172.20.0.10
1	password	Password1!
1	private-key	-----BEGIN OPENSSH PRIVATE KEY-----\nb3BlbnNzaC1rZXktdjEAAAAABG5vbmUAAAAEbm9uZQAAAAAAAAABAAAAMwAAAAtzc2gtZW\nQyNTUxOQAAACCvYBMYLqeFDQN70YggSnQivfiHVSm6LL1xA6U646hlVgAAAJjTsP1107D9\ndQAAAAtzc2gtZWQyNTUxOQAAACCvYBMYLqeFDQN70YggSnQivfiHVSm6LL1xA6U646hlVg\nAAAEDyK1objn0FHhfvALav18559QQ/3wxDxl/T4B3x5E+w2K9gExgup4UNA3vRiCBKdCK9\n+IdVKbosvXEDpTrjqGVWAAAAEHNoYXJlZC1hZG1pbi1rZXkBAgMEBQ==\n-----END OPENSSH PRIVATE KEY-----
1	port	22
1	username	ubuntu
2	hostname	172.20.0.11
2	private-key	-----BEGIN OPENSSH PRIVATE KEY-----\nb3BlbnNzaC1rZXktdjEAAAAABG5vbmUAAAAEbm9uZQAAAAAAAAABAAAAMwAAAAtzc2gtZW\nQyNTUxOQAAACCvYBMYLqeFDQN70YggSnQivfiHVSm6LL1xA6U646hlVgAAAJjTsP1107D9\ndQAAAAtzc2gtZWQyNTUxOQAAACCvYBMYLqeFDQN70YggSnQivfiHVSm6LL1xA6U646hlVg\nAAAEDyK1objn0FHhfvALav18559QQ/3wxDxl/T4B3x5E+w2K9gExgup4UNA3vRiCBKdCK9\n+IdVKbosvXEDpTrjqGVWAAAAEHNoYXJlZC1hZG1pbi1rZXkBAgMEBQ==\n-----END OPENSSH PRIVATE KEY-----
2	port	22
2	username	kali
5	hostname	172.20.0.21
5	password	Password1!
5	private-key	-----BEGIN OPENSSH PRIVATE KEY-----\nb3BlbnNzaC1rZXktdjEAAAAABG5vbmUAAAAEbm9uZQAAAAAAAAABAAAAMwAAAAtzc2gtZW\nQyNTUxOQAAACCvYBMYLqeFDQN70YggSnQivfiHVSm6LL1xA6U646hlVgAAAJjTsP1107D9\ndQAAAAtzc2gtZWQyNTUxOQAAACCvYBMYLqeFDQN70YggSnQivfiHVSm6LL1xA6U646hlVg\nAAAEDyK1objn0FHhfvALav18559QQ/3wxDxl/T4B3x5E+w2K9gExgup4UNA3vRiCBKdCK9\n+IdVKbosvXEDpTrjqGVWAAAAEHNoYXJlZC1hZG1pbi1rZXkBAgMEBQ==\n-----END OPENSSH PRIVATE KEY-----
5	port	22
5	username	ubuntu
6	hostname	172.20.0.11
6	password	password
6	port	5901
6	username	root
7	hostname	172.20.0.22
7	password	Password1!
7	port	3389
7	ignore-cert	true
7	username	administrator
4	hostname	172.20.0.20
4	password	wazuh
4	port	22
4	username	wazuh-user
8	hostname	172.20.0.2
8	password	opnsense
8	port	22
8	username	root
\.


--
-- Data for Name: guacamole_connection_permission; Type: TABLE DATA; Schema: public; Owner: guacamole_user
--

COPY public.guacamole_connection_permission (entity_id, connection_id, permission) FROM stdin;
1	1	READ
1	1	UPDATE
1	1	DELETE
1	1	ADMINISTER
1	2	READ
1	2	UPDATE
1	2	DELETE
1	2	ADMINISTER
1	4	READ
1	4	UPDATE
1	4	DELETE
1	4	ADMINISTER
1	5	READ
1	5	UPDATE
1	5	DELETE
1	5	ADMINISTER
1	6	READ
1	6	UPDATE
1	6	DELETE
1	6	ADMINISTER
1	7	READ
1	7	UPDATE
1	7	DELETE
1	7	ADMINISTER
1	8	READ
1	8	UPDATE
1	8	DELETE
1	8	ADMINISTER
\.


--
-- Data for Name: guacamole_entity; Type: TABLE DATA; Schema: public; Owner: guacamole_user
--

COPY public.guacamole_entity (entity_id, name, type) FROM stdin;
1	guacadmin	USER
\.


--
-- Data for Name: guacamole_sharing_profile; Type: TABLE DATA; Schema: public; Owner: guacamole_user
--

COPY public.guacamole_sharing_profile (sharing_profile_id, sharing_profile_name, primary_connection_id) FROM stdin;
\.


--
-- Data for Name: guacamole_sharing_profile_attribute; Type: TABLE DATA; Schema: public; Owner: guacamole_user
--

COPY public.guacamole_sharing_profile_attribute (sharing_profile_id, attribute_name, attribute_value) FROM stdin;
\.


--
-- Data for Name: guacamole_sharing_profile_parameter; Type: TABLE DATA; Schema: public; Owner: guacamole_user
--

COPY public.guacamole_sharing_profile_parameter (sharing_profile_id, parameter_name, parameter_value) FROM stdin;
\.


--
-- Data for Name: guacamole_sharing_profile_permission; Type: TABLE DATA; Schema: public; Owner: guacamole_user
--

COPY public.guacamole_sharing_profile_permission (entity_id, sharing_profile_id, permission) FROM stdin;
\.


--
-- Data for Name: guacamole_system_permission; Type: TABLE DATA; Schema: public; Owner: guacamole_user
--

COPY public.guacamole_system_permission (entity_id, permission) FROM stdin;
1	CREATE_CONNECTION
1	CREATE_CONNECTION_GROUP
1	CREATE_SHARING_PROFILE
1	CREATE_USER
1	CREATE_USER_GROUP
1	ADMINISTER
\.


--
-- Data for Name: guacamole_user; Type: TABLE DATA; Schema: public; Owner: guacamole_user
--

COPY public.guacamole_user (user_id, entity_id, password_hash, password_salt, password_date, disabled, expired, access_window_start, access_window_end, valid_from, valid_until, timezone, full_name, email_address, organization, organizational_role) FROM stdin;
1	1	\\xca458a7d494e3be824f5e1e175a1556c0f8eef2c2d7df3633bec4a29c4411960	\\xfe24adc5e11e2b25288d1704abe67a79e342ecc26064ce69c5b3177795a82264	2025-12-23 09:40:40.909986+00	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: guacamole_user_attribute; Type: TABLE DATA; Schema: public; Owner: guacamole_user
--

COPY public.guacamole_user_attribute (user_id, attribute_name, attribute_value) FROM stdin;
\.


--
-- Data for Name: guacamole_user_group; Type: TABLE DATA; Schema: public; Owner: guacamole_user
--

COPY public.guacamole_user_group (user_group_id, entity_id, disabled) FROM stdin;
\.


--
-- Data for Name: guacamole_user_group_attribute; Type: TABLE DATA; Schema: public; Owner: guacamole_user
--

COPY public.guacamole_user_group_attribute (user_group_id, attribute_name, attribute_value) FROM stdin;
\.


--
-- Data for Name: guacamole_user_group_member; Type: TABLE DATA; Schema: public; Owner: guacamole_user
--

COPY public.guacamole_user_group_member (user_group_id, member_entity_id) FROM stdin;
\.


--
-- Data for Name: guacamole_user_group_permission; Type: TABLE DATA; Schema: public; Owner: guacamole_user
--

COPY public.guacamole_user_group_permission (entity_id, affected_user_group_id, permission) FROM stdin;
\.


--
-- Data for Name: guacamole_user_history; Type: TABLE DATA; Schema: public; Owner: guacamole_user
--

COPY public.guacamole_user_history (history_id, user_id, username, remote_host, start_date, end_date) FROM stdin;
1	1	guacadmin	10.10.100.1	2025-12-23 09:42:42.644+00	\N
2	1	guacadmin	10.10.100.1	2025-12-23 09:42:42.719+00	2025-12-23 09:42:48.208+00
3	1	guacadmin	10.10.100.1	2025-12-23 09:42:55.805+00	\N
4	1	guacadmin	10.10.100.1	2025-12-23 09:42:55.846+00	\N
5	1	guacadmin	10.10.100.1	2025-12-23 09:43:00.175+00	\N
6	1	guacadmin	10.10.100.1	2025-12-23 09:43:05.269+00	\N
7	1	guacadmin	10.10.100.1	2025-12-23 09:53:06.255+00	\N
8	1	guacadmin	10.10.100.1	2025-12-23 09:54:29.854+00	\N
9	1	guacadmin	10.10.100.1	2025-12-23 09:54:33.077+00	\N
10	1	guacadmin	10.10.100.1	2025-12-23 09:54:36.476+00	\N
11	1	guacadmin	10.10.100.1	2025-12-23 09:54:37.799+00	\N
12	1	guacadmin	10.10.100.1	2025-12-23 09:54:38.102+00	\N
13	1	guacadmin	10.10.100.1	2025-12-23 09:54:38.138+00	\N
14	1	guacadmin	10.10.100.1	2025-12-23 09:54:40.046+00	\N
15	1	guacadmin	10.10.100.1	2025-12-23 09:54:41.591+00	\N
16	1	guacadmin	10.10.100.1	2025-12-23 09:54:44.967+00	\N
17	1	guacadmin	10.10.100.1	2025-12-23 09:56:48.434+00	\N
18	1	guacadmin	10.10.100.1	2025-12-23 09:56:49.395+00	\N
19	1	guacadmin	10.10.100.1	2025-12-23 09:56:56.957+00	\N
20	1	guacadmin	10.10.100.1	2025-12-23 09:56:58.039+00	\N
21	1	guacadmin	10.10.100.1	2025-12-23 09:56:58.892+00	\N
22	1	guacadmin	10.10.100.1	2025-12-23 09:57:00.106+00	\N
23	1	guacadmin	10.10.100.1	2025-12-23 09:57:01.4+00	\N
24	1	guacadmin	10.10.100.1	2025-12-23 09:57:01.925+00	\N
25	1	guacadmin	10.10.100.1	2025-12-23 09:57:02.844+00	\N
26	1	guacadmin	10.10.100.1	2025-12-23 09:58:22.936+00	\N
27	1	guacadmin	10.10.100.1	2025-12-23 09:58:26.452+00	\N
28	1	guacadmin	10.10.100.1	2025-12-23 09:58:27.893+00	\N
29	1	guacadmin	10.10.100.1	2025-12-23 09:58:28.413+00	\N
30	1	guacadmin	10.10.100.1	2025-12-23 09:58:29.954+00	\N
31	1	guacadmin	10.10.100.1	2025-12-23 09:58:31.819+00	2025-12-23 09:58:33.432+00
32	1	guacadmin	10.10.100.1	2025-12-23 09:58:40.92+00	\N
33	1	guacadmin	10.10.100.1	2025-12-23 09:58:40.955+00	\N
34	1	guacadmin	10.10.100.1	2025-12-23 09:58:55.262+00	\N
35	1	guacadmin	10.10.100.1	2025-12-23 10:03:06.402+00	\N
36	1	guacadmin	10.10.100.1	2025-12-23 10:03:07.586+00	\N
37	1	guacadmin	10.10.100.1	2025-12-23 10:03:07.848+00	\N
38	1	guacadmin	10.10.100.1	2025-12-23 10:03:10.222+00	\N
39	1	guacadmin	10.10.100.1	2025-12-23 10:03:10.743+00	\N
40	1	guacadmin	10.10.100.1	2025-12-23 10:07:31.028+00	\N
41	1	guacadmin	10.10.100.1	2025-12-23 10:07:31.319+00	\N
42	1	guacadmin	10.10.100.1	2025-12-23 10:07:33.18+00	\N
43	1	guacadmin	10.10.100.1	2025-12-23 10:07:34.468+00	\N
44	1	guacadmin	10.10.100.1	2025-12-23 10:08:35.672+00	\N
45	1	guacadmin	10.10.100.1	2025-12-23 10:08:38.017+00	\N
46	1	guacadmin	10.10.100.1	2025-12-23 10:08:39.023+00	\N
47	1	guacadmin	10.10.100.1	2025-12-23 10:08:53.248+00	\N
48	1	guacadmin	10.10.100.1	2025-12-23 10:08:57.745+00	\N
49	1	guacadmin	10.10.100.1	2025-12-23 10:08:58.868+00	\N
50	1	guacadmin	10.10.100.1	2025-12-23 10:12:00.27+00	\N
51	1	guacadmin	10.10.100.1	2025-12-23 10:12:03.523+00	\N
52	1	guacadmin	10.10.100.1	2025-12-23 10:12:04.77+00	\N
53	1	guacadmin	10.10.100.1	2025-12-23 10:12:08.184+00	\N
54	1	guacadmin	10.10.100.1	2025-12-23 10:13:59.365+00	\N
55	1	guacadmin	10.10.100.1	2025-12-23 10:14:01.373+00	\N
56	1	guacadmin	10.10.100.1	2025-12-23 10:14:04.605+00	\N
57	1	guacadmin	10.10.100.1	2025-12-23 10:14:06.968+00	\N
58	1	guacadmin	10.10.100.1	2025-12-23 10:14:48.799+00	\N
59	1	guacadmin	10.10.100.1	2025-12-23 10:14:51.35+00	\N
60	1	guacadmin	10.10.100.1	2025-12-23 10:14:52.495+00	\N
61	1	guacadmin	10.10.100.1	2025-12-23 10:14:57.051+00	\N
62	1	guacadmin	10.10.100.1	2025-12-23 10:15:01.69+00	\N
63	1	guacadmin	10.10.100.1	2025-12-23 10:15:03.16+00	\N
64	1	guacadmin	10.10.100.1	2025-12-23 10:15:04.604+00	\N
65	1	guacadmin	10.10.100.1	2025-12-23 10:15:07.271+00	\N
66	1	guacadmin	10.10.100.1	2025-12-23 10:15:42.561+00	\N
67	1	guacadmin	10.10.100.1	2025-12-23 10:15:45.368+00	\N
68	1	guacadmin	10.10.100.1	2025-12-23 10:15:46.703+00	\N
69	1	guacadmin	10.10.100.1	2025-12-23 10:15:46.849+00	\N
70	1	guacadmin	10.10.100.1	2025-12-23 10:15:48.158+00	\N
71	1	guacadmin	10.10.100.1	2025-12-23 10:15:48.633+00	\N
72	1	guacadmin	10.10.100.1	2025-12-23 10:15:51.428+00	\N
73	1	guacadmin	10.10.100.1	2025-12-23 10:15:54.351+00	\N
74	1	guacadmin	10.10.100.1	2025-12-23 10:55:48.878+00	\N
75	1	guacadmin	10.10.100.1	2025-12-23 11:57:05.714+00	\N
76	1	guacadmin	10.10.100.1	2025-12-23 11:57:05.874+00	\N
77	1	guacadmin	10.10.100.1	2025-12-23 11:57:07.992+00	\N
78	1	guacadmin	10.10.100.1	2025-12-23 11:57:21.684+00	\N
79	1	guacadmin	10.10.100.1	2025-12-23 11:57:22.433+00	\N
80	1	guacadmin	10.10.100.1	2025-12-23 11:57:23.846+00	\N
81	1	guacadmin	10.10.100.1	2025-12-23 11:57:30.489+00	\N
82	1	guacadmin	10.10.100.1	2025-12-23 11:57:31.582+00	\N
83	1	guacadmin	10.10.100.1	2025-12-23 12:24:47.98+00	\N
84	1	guacadmin	10.10.100.1	2025-12-23 12:24:49.665+00	\N
85	1	guacadmin	10.10.100.1	2025-12-23 12:24:51.61+00	\N
86	1	guacadmin	10.10.100.1	2025-12-23 12:24:55.059+00	\N
87	1	guacadmin	10.10.100.1	2025-12-23 12:25:10.28+00	\N
88	1	guacadmin	10.10.100.1	2025-12-23 12:25:14.027+00	\N
89	1	guacadmin	10.10.100.1	2025-12-23 12:26:57.729+00	\N
90	1	guacadmin	10.10.100.1	2025-12-23 12:26:59.369+00	\N
91	1	guacadmin	10.10.100.1	2025-12-23 12:27:01.833+00	\N
92	1	guacadmin	10.10.100.1	2025-12-23 12:27:03.045+00	\N
93	1	guacadmin	10.10.100.1	2025-12-23 12:30:32.836+00	\N
94	1	guacadmin	10.10.100.1	2025-12-23 12:30:34.071+00	\N
95	1	guacadmin	10.10.100.1	2025-12-23 12:30:36.419+00	\N
96	1	guacadmin	10.10.100.1	2025-12-23 12:30:38.096+00	\N
97	1	guacadmin	10.10.100.1	2025-12-23 12:30:39.634+00	\N
98	1	guacadmin	10.10.100.1	2025-12-23 12:30:42.274+00	\N
99	1	guacadmin	10.10.100.1	2025-12-23 12:30:55.406+00	\N
100	1	guacadmin	10.10.100.1	2025-12-23 12:31:05.035+00	\N
101	1	guacadmin	10.10.100.1	2025-12-23 12:31:08.332+00	\N
102	1	guacadmin	10.10.100.1	2025-12-23 12:35:29.119+00	\N
103	1	guacadmin	10.10.100.1	2025-12-23 12:35:30.338+00	\N
104	1	guacadmin	10.10.100.1	2025-12-23 12:36:38.187+00	\N
105	1	guacadmin	10.10.100.1	2025-12-23 12:36:39.029+00	\N
106	1	guacadmin	10.10.100.1	2025-12-23 12:36:41.305+00	\N
107	1	guacadmin	10.10.100.1	2025-12-23 12:36:42.83+00	\N
108	1	guacadmin	10.10.100.1	2025-12-23 12:36:43.784+00	\N
109	1	guacadmin	10.10.100.1	2025-12-23 12:37:43.642+00	\N
110	1	guacadmin	10.10.100.1	2025-12-23 12:37:45.084+00	\N
111	1	guacadmin	10.10.100.1	2025-12-23 12:41:29.859+00	\N
112	1	guacadmin	10.10.100.1	2025-12-23 12:44:08.405+00	\N
113	1	guacadmin	10.10.100.1	2025-12-23 12:48:12.946+00	\N
114	1	guacadmin	10.10.100.1	2025-12-23 12:48:29.362+00	\N
115	1	guacadmin	10.10.100.1	2025-12-23 12:52:37.62+00	\N
116	1	guacadmin	10.10.100.1	2025-12-23 13:02:50.591+00	\N
117	1	guacadmin	10.10.100.1	2025-12-23 13:09:51.224+00	2025-12-23 14:10:13.143+00
118	1	guacadmin	10.10.100.1	2025-12-23 19:01:23.996+00	\N
119	1	guacadmin	10.10.100.1	2025-12-23 19:01:25.8+00	\N
120	1	guacadmin	10.10.100.1	2025-12-23 19:01:27.197+00	\N
122	1	guacadmin	10.10.100.1	2025-12-23 19:28:53.383+00	\N
125	1	guacadmin	10.10.100.1	2025-12-23 19:37:50.433+00	\N
128	1	guacadmin	10.10.100.1	2025-12-23 19:38:06.571+00	\N
131	1	guacadmin	10.10.100.1	2025-12-23 19:46:46.333+00	\N
121	1	guacadmin	10.10.100.1	2025-12-23 19:01:37.401+00	\N
124	1	guacadmin	10.10.100.1	2025-12-23 19:34:14.881+00	\N
129	1	guacadmin	10.10.100.1	2025-12-23 19:38:08.041+00	\N
132	1	guacadmin	10.10.100.1	2025-12-23 19:46:47.186+00	\N
123	1	guacadmin	10.10.100.1	2025-12-23 19:34:12.719+00	\N
127	1	guacadmin	10.10.100.1	2025-12-23 19:37:54.791+00	\N
134	1	guacadmin	10.10.100.1	2025-12-23 19:46:52.409+00	\N
126	1	guacadmin	10.10.100.1	2025-12-23 19:37:52.324+00	\N
130	1	guacadmin	10.10.100.1	2025-12-23 19:38:09.858+00	\N
133	1	guacadmin	10.10.100.1	2025-12-23 19:46:50.563+00	\N
135	1	guacadmin	10.10.100.1	2025-12-23 19:46:55.884+00	\N
136	1	guacadmin	10.10.100.1	2025-12-23 19:47:39.353+00	\N
137	1	guacadmin	10.10.100.1	2025-12-23 19:47:45.618+00	\N
138	1	guacadmin	10.10.100.1	2025-12-23 19:47:47.221+00	\N
139	1	guacadmin	10.10.100.1	2025-12-23 19:49:11.204+00	\N
140	1	guacadmin	10.10.100.1	2025-12-23 19:49:12.496+00	\N
141	1	guacadmin	172.18.0.5	2026-01-07 09:52:44.995+00	\N
142	1	guacadmin	172.18.0.5	2026-01-07 09:52:45.059+00	2026-01-07 10:03:15.499+00
143	1	guacadmin	172.18.0.5	2026-01-07 10:04:49.55+00	\N
144	1	guacadmin	172.18.0.5	2026-01-07 10:04:49.612+00	2026-01-07 11:08:25.806+00
145	1	guacadmin	172.18.0.5	2026-01-08 07:39:48.113+00	\N
146	1	guacadmin	172.18.0.5	2026-01-08 07:39:48.149+00	\N
147	1	guacadmin	172.18.0.5	2026-01-08 07:39:54.707+00	2026-01-08 07:50:59.679+00
148	1	guacadmin	172.18.0.5	2026-01-08 09:01:28.929+00	\N
149	1	guacadmin	172.18.0.5	2026-01-08 09:01:28.996+00	\N
150	1	guacadmin	172.18.0.5	2026-01-08 09:10:33.159+00	\N
151	1	guacadmin	172.18.0.5	2026-01-08 09:10:34.8+00	\N
152	1	guacadmin	172.18.0.5	2026-01-08 09:10:35.929+00	\N
153	1	guacadmin	172.18.0.5	2026-01-08 09:11:05.443+00	\N
154	1	guacadmin	172.18.0.5	2026-01-08 09:11:10.4+00	\N
155	1	guacadmin	172.18.0.5	2026-01-08 09:11:11.635+00	\N
156	1	guacadmin	172.18.0.5	2026-01-08 09:38:27.445+00	\N
157	1	guacadmin	172.18.0.5	2026-01-08 09:38:33.289+00	\N
158	1	guacadmin	172.18.0.5	2026-01-08 09:38:34.592+00	\N
159	1	guacadmin	172.18.0.5	2026-01-08 09:38:37.794+00	\N
160	1	guacadmin	172.18.0.5	2026-01-08 09:38:50.225+00	\N
161	1	guacadmin	172.18.0.5	2026-01-08 09:38:56.648+00	\N
162	1	guacadmin	172.18.0.5	2026-01-08 09:38:57.732+00	\N
163	1	guacadmin	172.18.0.5	2026-01-08 09:38:59.424+00	\N
164	1	guacadmin	172.18.0.5	2026-01-08 09:39:20.389+00	\N
165	1	guacadmin	172.18.0.5	2026-01-08 09:39:24.17+00	\N
166	1	guacadmin	172.18.0.5	2026-01-08 09:39:25.141+00	\N
167	1	guacadmin	172.18.0.5	2026-01-08 09:39:26.813+00	\N
168	1	guacadmin	172.18.0.5	2026-01-08 09:39:36.326+00	\N
169	1	guacadmin	172.18.0.5	2026-01-08 09:39:38.35+00	\N
170	1	guacadmin	172.18.0.5	2026-01-08 09:40:08.984+00	\N
171	1	guacadmin	172.18.0.5	2026-01-08 09:40:13.131+00	\N
\.


--
-- Data for Name: guacamole_user_password_history; Type: TABLE DATA; Schema: public; Owner: guacamole_user
--

COPY public.guacamole_user_password_history (password_history_id, user_id, password_hash, password_salt, password_date) FROM stdin;
\.


--
-- Data for Name: guacamole_user_permission; Type: TABLE DATA; Schema: public; Owner: guacamole_user
--

COPY public.guacamole_user_permission (entity_id, affected_user_id, permission) FROM stdin;
1	1	READ
1	1	UPDATE
1	1	ADMINISTER
\.


--
-- Name: guacamole_connection_connection_id_seq; Type: SEQUENCE SET; Schema: public; Owner: guacamole_user
--

SELECT pg_catalog.setval('public.guacamole_connection_connection_id_seq', 8, true);


--
-- Name: guacamole_connection_group_connection_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: guacamole_user
--

SELECT pg_catalog.setval('public.guacamole_connection_group_connection_group_id_seq', 1, false);


--
-- Name: guacamole_connection_history_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: guacamole_user
--

SELECT pg_catalog.setval('public.guacamole_connection_history_history_id_seq', 42, true);


--
-- Name: guacamole_entity_entity_id_seq; Type: SEQUENCE SET; Schema: public; Owner: guacamole_user
--

SELECT pg_catalog.setval('public.guacamole_entity_entity_id_seq', 1, true);


--
-- Name: guacamole_sharing_profile_sharing_profile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: guacamole_user
--

SELECT pg_catalog.setval('public.guacamole_sharing_profile_sharing_profile_id_seq', 1, false);


--
-- Name: guacamole_user_group_user_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: guacamole_user
--

SELECT pg_catalog.setval('public.guacamole_user_group_user_group_id_seq', 1, false);


--
-- Name: guacamole_user_history_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: guacamole_user
--

SELECT pg_catalog.setval('public.guacamole_user_history_history_id_seq', 171, true);


--
-- Name: guacamole_user_password_history_password_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: guacamole_user
--

SELECT pg_catalog.setval('public.guacamole_user_password_history_password_history_id_seq', 1, false);


--
-- Name: guacamole_user_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: guacamole_user
--

SELECT pg_catalog.setval('public.guacamole_user_user_id_seq', 1, true);


--
-- Name: guacamole_connection_group connection_group_name_parent; Type: CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_connection_group
    ADD CONSTRAINT connection_group_name_parent UNIQUE (connection_group_name, parent_id);


--
-- Name: guacamole_connection connection_name_parent; Type: CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_connection
    ADD CONSTRAINT connection_name_parent UNIQUE (connection_name, parent_id);


--
-- Name: guacamole_connection_attribute guacamole_connection_attribute_pkey; Type: CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_connection_attribute
    ADD CONSTRAINT guacamole_connection_attribute_pkey PRIMARY KEY (connection_id, attribute_name);


--
-- Name: guacamole_connection_group_attribute guacamole_connection_group_attribute_pkey; Type: CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_connection_group_attribute
    ADD CONSTRAINT guacamole_connection_group_attribute_pkey PRIMARY KEY (connection_group_id, attribute_name);


--
-- Name: guacamole_connection_group_permission guacamole_connection_group_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_connection_group_permission
    ADD CONSTRAINT guacamole_connection_group_permission_pkey PRIMARY KEY (entity_id, connection_group_id, permission);


--
-- Name: guacamole_connection_group guacamole_connection_group_pkey; Type: CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_connection_group
    ADD CONSTRAINT guacamole_connection_group_pkey PRIMARY KEY (connection_group_id);


--
-- Name: guacamole_connection_history guacamole_connection_history_pkey; Type: CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_connection_history
    ADD CONSTRAINT guacamole_connection_history_pkey PRIMARY KEY (history_id);


--
-- Name: guacamole_connection_parameter guacamole_connection_parameter_pkey; Type: CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_connection_parameter
    ADD CONSTRAINT guacamole_connection_parameter_pkey PRIMARY KEY (connection_id, parameter_name);


--
-- Name: guacamole_connection_permission guacamole_connection_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_connection_permission
    ADD CONSTRAINT guacamole_connection_permission_pkey PRIMARY KEY (entity_id, connection_id, permission);


--
-- Name: guacamole_connection guacamole_connection_pkey; Type: CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_connection
    ADD CONSTRAINT guacamole_connection_pkey PRIMARY KEY (connection_id);


--
-- Name: guacamole_entity guacamole_entity_name_scope; Type: CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_entity
    ADD CONSTRAINT guacamole_entity_name_scope UNIQUE (type, name);


--
-- Name: guacamole_entity guacamole_entity_pkey; Type: CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_entity
    ADD CONSTRAINT guacamole_entity_pkey PRIMARY KEY (entity_id);


--
-- Name: guacamole_sharing_profile_attribute guacamole_sharing_profile_attribute_pkey; Type: CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_sharing_profile_attribute
    ADD CONSTRAINT guacamole_sharing_profile_attribute_pkey PRIMARY KEY (sharing_profile_id, attribute_name);


--
-- Name: guacamole_sharing_profile_parameter guacamole_sharing_profile_parameter_pkey; Type: CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_sharing_profile_parameter
    ADD CONSTRAINT guacamole_sharing_profile_parameter_pkey PRIMARY KEY (sharing_profile_id, parameter_name);


--
-- Name: guacamole_sharing_profile_permission guacamole_sharing_profile_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_sharing_profile_permission
    ADD CONSTRAINT guacamole_sharing_profile_permission_pkey PRIMARY KEY (entity_id, sharing_profile_id, permission);


--
-- Name: guacamole_sharing_profile guacamole_sharing_profile_pkey; Type: CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_sharing_profile
    ADD CONSTRAINT guacamole_sharing_profile_pkey PRIMARY KEY (sharing_profile_id);


--
-- Name: guacamole_system_permission guacamole_system_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_system_permission
    ADD CONSTRAINT guacamole_system_permission_pkey PRIMARY KEY (entity_id, permission);


--
-- Name: guacamole_user_attribute guacamole_user_attribute_pkey; Type: CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_user_attribute
    ADD CONSTRAINT guacamole_user_attribute_pkey PRIMARY KEY (user_id, attribute_name);


--
-- Name: guacamole_user_group_attribute guacamole_user_group_attribute_pkey; Type: CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_user_group_attribute
    ADD CONSTRAINT guacamole_user_group_attribute_pkey PRIMARY KEY (user_group_id, attribute_name);


--
-- Name: guacamole_user_group_member guacamole_user_group_member_pkey; Type: CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_user_group_member
    ADD CONSTRAINT guacamole_user_group_member_pkey PRIMARY KEY (user_group_id, member_entity_id);


--
-- Name: guacamole_user_group_permission guacamole_user_group_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_user_group_permission
    ADD CONSTRAINT guacamole_user_group_permission_pkey PRIMARY KEY (entity_id, affected_user_group_id, permission);


--
-- Name: guacamole_user_group guacamole_user_group_pkey; Type: CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_user_group
    ADD CONSTRAINT guacamole_user_group_pkey PRIMARY KEY (user_group_id);


--
-- Name: guacamole_user_group guacamole_user_group_single_entity; Type: CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_user_group
    ADD CONSTRAINT guacamole_user_group_single_entity UNIQUE (entity_id);


--
-- Name: guacamole_user_history guacamole_user_history_pkey; Type: CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_user_history
    ADD CONSTRAINT guacamole_user_history_pkey PRIMARY KEY (history_id);


--
-- Name: guacamole_user_password_history guacamole_user_password_history_pkey; Type: CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_user_password_history
    ADD CONSTRAINT guacamole_user_password_history_pkey PRIMARY KEY (password_history_id);


--
-- Name: guacamole_user_permission guacamole_user_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_user_permission
    ADD CONSTRAINT guacamole_user_permission_pkey PRIMARY KEY (entity_id, affected_user_id, permission);


--
-- Name: guacamole_user guacamole_user_pkey; Type: CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_user
    ADD CONSTRAINT guacamole_user_pkey PRIMARY KEY (user_id);


--
-- Name: guacamole_user guacamole_user_single_entity; Type: CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_user
    ADD CONSTRAINT guacamole_user_single_entity UNIQUE (entity_id);


--
-- Name: guacamole_sharing_profile sharing_profile_name_primary; Type: CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_sharing_profile
    ADD CONSTRAINT sharing_profile_name_primary UNIQUE (sharing_profile_name, primary_connection_id);


--
-- Name: guacamole_connection_attribute_connection_id; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_connection_attribute_connection_id ON public.guacamole_connection_attribute USING btree (connection_id);


--
-- Name: guacamole_connection_group_attribute_connection_group_id; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_connection_group_attribute_connection_group_id ON public.guacamole_connection_group_attribute USING btree (connection_group_id);


--
-- Name: guacamole_connection_group_parent_id; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_connection_group_parent_id ON public.guacamole_connection_group USING btree (parent_id);


--
-- Name: guacamole_connection_group_permission_connection_group_id; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_connection_group_permission_connection_group_id ON public.guacamole_connection_group_permission USING btree (connection_group_id);


--
-- Name: guacamole_connection_group_permission_entity_id; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_connection_group_permission_entity_id ON public.guacamole_connection_group_permission USING btree (entity_id);


--
-- Name: guacamole_connection_history_connection_id; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_connection_history_connection_id ON public.guacamole_connection_history USING btree (connection_id);


--
-- Name: guacamole_connection_history_connection_id_start_date; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_connection_history_connection_id_start_date ON public.guacamole_connection_history USING btree (connection_id, start_date);


--
-- Name: guacamole_connection_history_end_date; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_connection_history_end_date ON public.guacamole_connection_history USING btree (end_date);


--
-- Name: guacamole_connection_history_sharing_profile_id; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_connection_history_sharing_profile_id ON public.guacamole_connection_history USING btree (sharing_profile_id);


--
-- Name: guacamole_connection_history_start_date; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_connection_history_start_date ON public.guacamole_connection_history USING btree (start_date);


--
-- Name: guacamole_connection_history_user_id; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_connection_history_user_id ON public.guacamole_connection_history USING btree (user_id);


--
-- Name: guacamole_connection_parameter_connection_id; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_connection_parameter_connection_id ON public.guacamole_connection_parameter USING btree (connection_id);


--
-- Name: guacamole_connection_parent_id; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_connection_parent_id ON public.guacamole_connection USING btree (parent_id);


--
-- Name: guacamole_connection_permission_connection_id; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_connection_permission_connection_id ON public.guacamole_connection_permission USING btree (connection_id);


--
-- Name: guacamole_connection_permission_entity_id; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_connection_permission_entity_id ON public.guacamole_connection_permission USING btree (entity_id);


--
-- Name: guacamole_sharing_profile_attribute_sharing_profile_id; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_sharing_profile_attribute_sharing_profile_id ON public.guacamole_sharing_profile_attribute USING btree (sharing_profile_id);


--
-- Name: guacamole_sharing_profile_parameter_sharing_profile_id; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_sharing_profile_parameter_sharing_profile_id ON public.guacamole_sharing_profile_parameter USING btree (sharing_profile_id);


--
-- Name: guacamole_sharing_profile_permission_entity_id; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_sharing_profile_permission_entity_id ON public.guacamole_sharing_profile_permission USING btree (entity_id);


--
-- Name: guacamole_sharing_profile_permission_sharing_profile_id; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_sharing_profile_permission_sharing_profile_id ON public.guacamole_sharing_profile_permission USING btree (sharing_profile_id);


--
-- Name: guacamole_sharing_profile_primary_connection_id; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_sharing_profile_primary_connection_id ON public.guacamole_sharing_profile USING btree (primary_connection_id);


--
-- Name: guacamole_system_permission_entity_id; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_system_permission_entity_id ON public.guacamole_system_permission USING btree (entity_id);


--
-- Name: guacamole_user_attribute_user_id; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_user_attribute_user_id ON public.guacamole_user_attribute USING btree (user_id);


--
-- Name: guacamole_user_group_attribute_user_group_id; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_user_group_attribute_user_group_id ON public.guacamole_user_group_attribute USING btree (user_group_id);


--
-- Name: guacamole_user_group_permission_affected_user_group_id; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_user_group_permission_affected_user_group_id ON public.guacamole_user_group_permission USING btree (affected_user_group_id);


--
-- Name: guacamole_user_group_permission_entity_id; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_user_group_permission_entity_id ON public.guacamole_user_group_permission USING btree (entity_id);


--
-- Name: guacamole_user_history_end_date; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_user_history_end_date ON public.guacamole_user_history USING btree (end_date);


--
-- Name: guacamole_user_history_start_date; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_user_history_start_date ON public.guacamole_user_history USING btree (start_date);


--
-- Name: guacamole_user_history_user_id; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_user_history_user_id ON public.guacamole_user_history USING btree (user_id);


--
-- Name: guacamole_user_history_user_id_start_date; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_user_history_user_id_start_date ON public.guacamole_user_history USING btree (user_id, start_date);


--
-- Name: guacamole_user_password_history_user_id; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_user_password_history_user_id ON public.guacamole_user_password_history USING btree (user_id);


--
-- Name: guacamole_user_permission_affected_user_id; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_user_permission_affected_user_id ON public.guacamole_user_permission USING btree (affected_user_id);


--
-- Name: guacamole_user_permission_entity_id; Type: INDEX; Schema: public; Owner: guacamole_user
--

CREATE INDEX guacamole_user_permission_entity_id ON public.guacamole_user_permission USING btree (entity_id);


--
-- Name: guacamole_connection_attribute guacamole_connection_attribute_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_connection_attribute
    ADD CONSTRAINT guacamole_connection_attribute_ibfk_1 FOREIGN KEY (connection_id) REFERENCES public.guacamole_connection(connection_id) ON DELETE CASCADE;


--
-- Name: guacamole_connection_group_attribute guacamole_connection_group_attribute_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_connection_group_attribute
    ADD CONSTRAINT guacamole_connection_group_attribute_ibfk_1 FOREIGN KEY (connection_group_id) REFERENCES public.guacamole_connection_group(connection_group_id) ON DELETE CASCADE;


--
-- Name: guacamole_connection_group guacamole_connection_group_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_connection_group
    ADD CONSTRAINT guacamole_connection_group_ibfk_1 FOREIGN KEY (parent_id) REFERENCES public.guacamole_connection_group(connection_group_id) ON DELETE CASCADE;


--
-- Name: guacamole_connection_group_permission guacamole_connection_group_permission_entity; Type: FK CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_connection_group_permission
    ADD CONSTRAINT guacamole_connection_group_permission_entity FOREIGN KEY (entity_id) REFERENCES public.guacamole_entity(entity_id) ON DELETE CASCADE;


--
-- Name: guacamole_connection_group_permission guacamole_connection_group_permission_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_connection_group_permission
    ADD CONSTRAINT guacamole_connection_group_permission_ibfk_1 FOREIGN KEY (connection_group_id) REFERENCES public.guacamole_connection_group(connection_group_id) ON DELETE CASCADE;


--
-- Name: guacamole_connection_history guacamole_connection_history_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_connection_history
    ADD CONSTRAINT guacamole_connection_history_ibfk_1 FOREIGN KEY (user_id) REFERENCES public.guacamole_user(user_id) ON DELETE SET NULL;


--
-- Name: guacamole_connection_history guacamole_connection_history_ibfk_2; Type: FK CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_connection_history
    ADD CONSTRAINT guacamole_connection_history_ibfk_2 FOREIGN KEY (connection_id) REFERENCES public.guacamole_connection(connection_id) ON DELETE SET NULL;


--
-- Name: guacamole_connection_history guacamole_connection_history_ibfk_3; Type: FK CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_connection_history
    ADD CONSTRAINT guacamole_connection_history_ibfk_3 FOREIGN KEY (sharing_profile_id) REFERENCES public.guacamole_sharing_profile(sharing_profile_id) ON DELETE SET NULL;


--
-- Name: guacamole_connection guacamole_connection_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_connection
    ADD CONSTRAINT guacamole_connection_ibfk_1 FOREIGN KEY (parent_id) REFERENCES public.guacamole_connection_group(connection_group_id) ON DELETE CASCADE;


--
-- Name: guacamole_connection_parameter guacamole_connection_parameter_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_connection_parameter
    ADD CONSTRAINT guacamole_connection_parameter_ibfk_1 FOREIGN KEY (connection_id) REFERENCES public.guacamole_connection(connection_id) ON DELETE CASCADE;


--
-- Name: guacamole_connection_permission guacamole_connection_permission_entity; Type: FK CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_connection_permission
    ADD CONSTRAINT guacamole_connection_permission_entity FOREIGN KEY (entity_id) REFERENCES public.guacamole_entity(entity_id) ON DELETE CASCADE;


--
-- Name: guacamole_connection_permission guacamole_connection_permission_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_connection_permission
    ADD CONSTRAINT guacamole_connection_permission_ibfk_1 FOREIGN KEY (connection_id) REFERENCES public.guacamole_connection(connection_id) ON DELETE CASCADE;


--
-- Name: guacamole_sharing_profile_attribute guacamole_sharing_profile_attribute_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_sharing_profile_attribute
    ADD CONSTRAINT guacamole_sharing_profile_attribute_ibfk_1 FOREIGN KEY (sharing_profile_id) REFERENCES public.guacamole_sharing_profile(sharing_profile_id) ON DELETE CASCADE;


--
-- Name: guacamole_sharing_profile guacamole_sharing_profile_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_sharing_profile
    ADD CONSTRAINT guacamole_sharing_profile_ibfk_1 FOREIGN KEY (primary_connection_id) REFERENCES public.guacamole_connection(connection_id) ON DELETE CASCADE;


--
-- Name: guacamole_sharing_profile_parameter guacamole_sharing_profile_parameter_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_sharing_profile_parameter
    ADD CONSTRAINT guacamole_sharing_profile_parameter_ibfk_1 FOREIGN KEY (sharing_profile_id) REFERENCES public.guacamole_sharing_profile(sharing_profile_id) ON DELETE CASCADE;


--
-- Name: guacamole_sharing_profile_permission guacamole_sharing_profile_permission_entity; Type: FK CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_sharing_profile_permission
    ADD CONSTRAINT guacamole_sharing_profile_permission_entity FOREIGN KEY (entity_id) REFERENCES public.guacamole_entity(entity_id) ON DELETE CASCADE;


--
-- Name: guacamole_sharing_profile_permission guacamole_sharing_profile_permission_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_sharing_profile_permission
    ADD CONSTRAINT guacamole_sharing_profile_permission_ibfk_1 FOREIGN KEY (sharing_profile_id) REFERENCES public.guacamole_sharing_profile(sharing_profile_id) ON DELETE CASCADE;


--
-- Name: guacamole_system_permission guacamole_system_permission_entity; Type: FK CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_system_permission
    ADD CONSTRAINT guacamole_system_permission_entity FOREIGN KEY (entity_id) REFERENCES public.guacamole_entity(entity_id) ON DELETE CASCADE;


--
-- Name: guacamole_user_attribute guacamole_user_attribute_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_user_attribute
    ADD CONSTRAINT guacamole_user_attribute_ibfk_1 FOREIGN KEY (user_id) REFERENCES public.guacamole_user(user_id) ON DELETE CASCADE;


--
-- Name: guacamole_user guacamole_user_entity; Type: FK CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_user
    ADD CONSTRAINT guacamole_user_entity FOREIGN KEY (entity_id) REFERENCES public.guacamole_entity(entity_id) ON DELETE CASCADE;


--
-- Name: guacamole_user_group_attribute guacamole_user_group_attribute_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_user_group_attribute
    ADD CONSTRAINT guacamole_user_group_attribute_ibfk_1 FOREIGN KEY (user_group_id) REFERENCES public.guacamole_user_group(user_group_id) ON DELETE CASCADE;


--
-- Name: guacamole_user_group guacamole_user_group_entity; Type: FK CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_user_group
    ADD CONSTRAINT guacamole_user_group_entity FOREIGN KEY (entity_id) REFERENCES public.guacamole_entity(entity_id) ON DELETE CASCADE;


--
-- Name: guacamole_user_group_member guacamole_user_group_member_entity; Type: FK CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_user_group_member
    ADD CONSTRAINT guacamole_user_group_member_entity FOREIGN KEY (member_entity_id) REFERENCES public.guacamole_entity(entity_id) ON DELETE CASCADE;


--
-- Name: guacamole_user_group_member guacamole_user_group_member_parent; Type: FK CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_user_group_member
    ADD CONSTRAINT guacamole_user_group_member_parent FOREIGN KEY (user_group_id) REFERENCES public.guacamole_user_group(user_group_id) ON DELETE CASCADE;


--
-- Name: guacamole_user_group_permission guacamole_user_group_permission_affected_user_group; Type: FK CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_user_group_permission
    ADD CONSTRAINT guacamole_user_group_permission_affected_user_group FOREIGN KEY (affected_user_group_id) REFERENCES public.guacamole_user_group(user_group_id) ON DELETE CASCADE;


--
-- Name: guacamole_user_group_permission guacamole_user_group_permission_entity; Type: FK CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_user_group_permission
    ADD CONSTRAINT guacamole_user_group_permission_entity FOREIGN KEY (entity_id) REFERENCES public.guacamole_entity(entity_id) ON DELETE CASCADE;


--
-- Name: guacamole_user_history guacamole_user_history_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_user_history
    ADD CONSTRAINT guacamole_user_history_ibfk_1 FOREIGN KEY (user_id) REFERENCES public.guacamole_user(user_id) ON DELETE SET NULL;


--
-- Name: guacamole_user_password_history guacamole_user_password_history_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_user_password_history
    ADD CONSTRAINT guacamole_user_password_history_ibfk_1 FOREIGN KEY (user_id) REFERENCES public.guacamole_user(user_id) ON DELETE CASCADE;


--
-- Name: guacamole_user_permission guacamole_user_permission_entity; Type: FK CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_user_permission
    ADD CONSTRAINT guacamole_user_permission_entity FOREIGN KEY (entity_id) REFERENCES public.guacamole_entity(entity_id) ON DELETE CASCADE;


--
-- Name: guacamole_user_permission guacamole_user_permission_ibfk_1; Type: FK CONSTRAINT; Schema: public; Owner: guacamole_user
--

ALTER TABLE ONLY public.guacamole_user_permission
    ADD CONSTRAINT guacamole_user_permission_ibfk_1 FOREIGN KEY (affected_user_id) REFERENCES public.guacamole_user(user_id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

